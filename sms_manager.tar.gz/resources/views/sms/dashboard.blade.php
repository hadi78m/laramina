@extends('layouts.mclsApp')

@section('content')
    <x-elements.sidebar>
        <x-sidebars.sms />
    </x-elements.sidebar>

    <div class="container mx-auto px-4 py-8">
        <!-- هدر -->
        <div class="mb-8">
            <h1 class="text-3xl font-bold text-gray-900">داشبورد مدیریت پیامک</h1>
            <p class="text-gray-600 mt-2">آمار و گزارشات سیستم ارسال پیامک</p>
        </div>
        @role('SuperAdmin')
        <!-- آمار اصلی -->
        <div class="grid grid-cols-1 md:grid-cols-5 lg:grid-cols-5 gap-6 mb-8">
            <!-- تعداد کاربران -->
            <div class="bg-gradient-to-br from-blue-500 to-blue-600 text-white rounded-xl shadow-lg p-6">
                <div class="flex items-center justify-between">
                    <div>
                        <p class="text-blue-100 text-sm mb-1">تعداد کاربران</p>
                        <h2 id="stat-total-users" class="text-3xl font-bold">0</h2>
                    </div>
                    <div class="bg-blue-400 bg-opacity-30 w-14 h-14 rounded-full flex items-center justify-center">
                        <i class="fas fa-users text-2xl"></i>
                    </div>
                </div>
            </div>

            <!-- پیام‌های ارسالی -->
            <div class="bg-gradient-to-br from-green-500 to-emerald-600 text-white rounded-xl shadow-lg p-6">
                <div class="flex items-center justify-between">
                    <div>
                        <p class="text-green-100 text-sm mb-1">پیام‌های ارسالی</p>
                        <h2 id="stat-total-messages" class="text-3xl font-bold">0</h2>
                    </div>
                    <div class="bg-green-400 bg-opacity-30 w-14 h-14 rounded-full flex items-center justify-center">
                        <i class="fas fa-envelope text-2xl"></i>
                    </div>
                </div>
            </div>

            <!-- پیام‌های مسدودی -->
            <div class="bg-gradient-to-br from-red-500 to-pink-600 text-white rounded-xl shadow-lg p-6">
                <div class="flex items-center justify-between">
                    <div>
                        <p class="text-red-100 text-sm mb-1">پیام‌های مسدودی</p>
                        <h2 id="stat-blocked-messages" class="text-3xl font-bold">0</h2>
                    </div>
                    <div class="bg-red-400 bg-opacity-30 w-14 h-14 rounded-full flex items-center justify-center">
                        <i class="fas fa-ban text-2xl"></i>
                    </div>
                </div>
            </div>

            <!-- کلمات غیرمجاز -->
            <div class="bg-gradient-to-br from-orange-500 to-amber-600 text-white rounded-xl shadow-lg p-6">
                <div class="flex items-center justify-between">
                    <div>
                        <p class="text-orange-100 text-sm mb-1">کلمات غیرمجاز</p>
                        <h2 id="stat-blocked-words" class="text-3xl font-bold">0</h2>
                    </div>
                    <div class="bg-orange-400 bg-opacity-30 w-14 h-14 rounded-full flex items-center justify-center">
                        <i class="fas fa-exclamation-triangle text-2xl"></i>
                    </div>
                </div>
            </div>

            <!-- بیشترین ارسال کننده -->
            <div class="bg-gradient-to-br from-purple-500 to-indigo-600 text-white rounded-xl shadow-lg p-6">
                <div class="flex items-center justify-between">
                    <div>
                        <p class="text-purple-100 text-sm mb-1">بیشترین ارسال</p>
                        <h2 id="stat-top-sender-count" class="text-2xl font-bold">0</h2>
                        <p id="stat-top-sender-name" class="text-purple-100 text-xs mt-1">-</p>
                    </div>
                    <div class="bg-purple-400 bg-opacity-30 w-14 h-14 rounded-full flex items-center justify-center">
                        <i class="fas fa-trophy text-2xl"></i>
                    </div>
                </div>
            </div>
        </div>

        <!-- نمودار و اطلاعات بیشتر -->
        <div class="grid grid-cols-1 lg:grid-cols-2 gap-8">
            <!-- کارت بیشترین ارسال کننده -->
            <div class="bg-white rounded-xl shadow-lg p-6">
                <h3 class="text-lg font-bold text-gray-800 mb-4 flex items-center gap-2">
                    <i class="fas fa-crown text-yellow-500"></i>
                    بیشترین ارسال کننده پیامک
                </h3>
                <div id="top-sender-details" class="text-center py-8">
                    <div class="flex justify-center mb-4">
                        <div
                            class="w-20 h-20 bg-gradient-to-br from-purple-500 to-indigo-600 rounded-full flex items-center justify-center text-white text-2xl font-bold">
                            <i class="fas fa-user"></i>
                        </div>
                    </div>
                    <h4 id="top-sender-name" class="text-xl font-bold text-gray-900">-</h4>
                    <p id="top-sender-username" class="text-gray-600 mb-2">-</p>
                    <div class="bg-gray-100 rounded-lg p-3 inline-block">
                        <span class="text-sm text-gray-600">تعداد پیام: </span>
                        <span id="top-sender-messages" class="font-bold text-purple-600">0</span>
                    </div>
                </div>
            </div>

            <!-- آمار هفتگی -->
            <div class="bg-white rounded-xl shadow-lg p-6">
                <h3 class="text-lg font-bold text-gray-800 mb-4 flex items-center gap-2">
                    <i class="fas fa-chart-bar text-blue-500"></i>
                    آمار هفتگی پیام‌ها
                </h3>
                <div id="weekly-stats" class="space-y-3">
                    <!-- با جاوااسکریپت پر می‌شود -->
                </div>
            </div>
        </div>
        @endrole
        <!-- لینک‌های سریع -->
        <div class="mt-8 grid grid-cols-1 md:grid-cols-3 gap-4">
            <a href="{{ route('sms.messages.index') }}"
                class="bg-white rounded-xl shadow-lg p-6 hover:shadow-xl transition-shadow border-l-4 border-blue-500">
                <div class="flex items-center gap-4">
                    <div class="bg-blue-100 p-3 rounded-lg">
                        <i class="fas fa-envelope text-blue-600 text-xl"></i>
                    </div>
                    <div>
                        <h4 class="font-bold text-gray-900">مدیریت پیام‌ها</h4>
                        <p class="text-gray-600 text-sm">مشاهده و مدیریت تمام پیام‌ها</p>
                    </div>
                </div>
            </a>

            <a href="{{ route('sms.credentials.index') }}"
                class="bg-white rounded-xl shadow-lg p-6 hover:shadow-xl transition-shadow border-l-4 border-green-500">
                <div class="flex items-center gap-4">
                    <div class="bg-green-100 p-3 rounded-lg">
                        <i class="fas fa-key text-green-600 text-xl"></i>
                    </div>
                    <div>
                        <h4 class="font-bold text-gray-900">اعتبارنامه‌ها</h4>
                        <p class="text-gray-600 text-sm">مدیریت حساب‌های پیامکی</p>
                    </div>
                </div>
            </a>

            <a href="{{ route('sms.blocked-words.index') }}"
                class="bg-white rounded-xl shadow-lg p-6 hover:shadow-xl transition-shadow border-l-4 border-red-500">
                <div class="flex items-center gap-4">
                    <div class="bg-red-100 p-3 rounded-lg">
                        <i class="fas fa-ban text-red-600 text-xl"></i>
                    </div>
                    <div>
                        <h4 class="font-bold text-gray-900">کلمات غیرمجاز</h4>
                        <p class="text-gray-600 text-sm">مدیریت فیلتر محتوا</p>
                    </div>
                </div>
            </a>
        </div>
    </div>
@endsection

@section('scripts')
    <script>
        $(document).ready(function () {
            loadDashboardStats();
        });

        function loadDashboardStats() {
            $.ajax({
                url: '{{ route("dashboard.stats") }}',
                method: 'GET',
                success: function (response) {
                    if (response.success) {
                        const stats = response.data;

                        // آمار اصلی
                        $('#stat-total-users').text(stats.total_users.toLocaleString());
                        $('#stat-total-messages').text(stats.total_messages.toLocaleString());
                        $('#stat-blocked-messages').text(stats.blocked_messages.toLocaleString());
                        $('#stat-blocked-words').text(stats.blocked_words_count.toLocaleString());

                        // بیشترین ارسال کننده
                        if (stats.top_sender) {
                            $('#stat-top-sender-count').text(stats.top_sender.message_count.toLocaleString());
                            $('#stat-top-sender-name').text(stats.top_sender.name);

                            $('#top-sender-name').text(stats.top_sender.name);
                            $('#top-sender-username').text(stats.top_sender.username);
                            $('#top-sender-messages').text(stats.top_sender.message_count.toLocaleString());
                        }

                        // آمار هفتگی
                        renderWeeklyStats(stats.weekly_stats);
                    }
                },
                error: function () {
                    console.error('خطا در دریافت آمار داشبورد');
                }
            });
        }

        function renderWeeklyStats(weeklyStats) {
            const container = $('#weekly-stats');
            container.empty();

            if (weeklyStats.length === 0) {
                container.html('<p class="text-gray-500 text-center py-4">داده‌ای برای نمایش وجود ندارد</p>');
                return;
            }

            weeklyStats.forEach(stat => {
                const date = new Date(stat.date).toLocaleDateString('fa-IR');
                const html = `
                        <div class="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                            <div class="flex items-center gap-4">
                                <span class="text-sm font-medium text-gray-700">${date}</span>
                            </div>
                            <div class="flex gap-4">
                                <span class="text-xs bg-green-100 text-green-800 px-2 py-1 rounded">
                                    ارسال شده: ${stat.sent}
                                </span>
                                <span class="text-xs bg-red-100 text-red-800 px-2 py-1 rounded">
                                    مسدود شده: ${stat.blocked}
                                </span>
                                <span class="text-xs bg-blue-100 text-blue-800 px-2 py-1 rounded">
                                    کل: ${stat.total}
                                </span>
                            </div>
                        </div>
                    `;
                container.append(html);
            });
        }

        // رفرش خودکار هر 30 ثانیه
        setInterval(loadDashboardStats, 30000);
    </script>
@endsection