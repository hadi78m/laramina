<form {{ $attributes->class(['main_forms'])->merge(['id' => 'main_form'])->merge(['autocomplete' => 'off']) }}  enctype="multipart/form-data" dir="rtl">
    @csrf

    {{$slot}}
    {{-- @isset($form_data)
        {{ $form_data }}
    @endisset --}}
</form>

{{--  main_forms for work by ajax --}}