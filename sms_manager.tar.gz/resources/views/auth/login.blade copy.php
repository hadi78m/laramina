<x-guest-layout>
    <div class="container mx-auto h-full grid grid-cols-1 md:grid-cols-1 py-2 gap-4">
        <x-auth-session-status class="mb-4" :status="session('status')" />
        <div class="bg-cover bg-center rounded-l-lg bg-[url('/public/img/taavon.jpg')]">
            <div class=" bg-[#ffffffde] md:w-[20rem] p-8 h-full flex flex-col">
                    <img src="{{ asset('img/kar.png') }}" class="px-20 mt-20" alt=""
                        loading="lazy">
                <form method="POST" action="{{ route('login') }}" dir="rtl" class="space-y-4">
                    @csrf
                    <div>
                        <label for="email" class="block text-gray-700 font-bold mb-2">@lang('app.email')</label>
                        <x-text-input id="email"
                            class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
                            type="email" name="email" :value="old('email')" placeholder="نام کاربری خود را وارد کنید"
                            required autofocus autocomplete="off" />
                        <x-input-error :messages="$errors->get('email')" class="mt-2"></x-input-error>
                    </div>
                    <div>
                        <label for="password" class="block text-gray-700 font-bold mb-2">@lang('app.password')</label>
                        <x-text-input type="password" id="password"
                            class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
                            type="password" name="password" required autocomplete="current-password"
                            placeholder="رمز عبور خود را وارد کنید" />
                        <x-input-error :messages="$errors->get('password')" class="mt-2"></x-input-error>
                    </div>
                    <div class="flex justify-center">
                        <button type="submit"
                            class="bg-blue-500 w-full hover:bg-blue-700 text-white font-bold py-2 px-4 rounded focus:outline-none focus:shadow-outline">
                            @lang('app.login')
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</x-guest-layout>
