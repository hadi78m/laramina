@extends('layouts.mclsApp')

@section('content')
    <main class="flex-1 container mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div class="mb-8 ">
            <h2 class="text-2xl font-bold text-gray-800 mb-2">خوش آمدید</h2>
            <div class="flex justify-between">
                <p class="text-gray-600">سرویس‌های مورد نیاز خود را انتخاب کنید</p>
                <p class="flex">
                    <a href="{{ route('logout') }}"
                        class="flex items-center  p-2 hover:text-red-400 bg-orange-400 hover:bg-red-200 rounded text-gray-700">
                        <x-bi-box-arrow-left />
                        <span class="mr-3">
                            @lang('app.logout')
                        </span>
                    </a>
                </p>
            </div>
        </div>

        <div class=" flex justify-beetwen grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            @foreach ($services as $service)
                @isset($service['route'])
                    <a href="{{ route($service['route']) }}" class="w-full">
                        <div
                            class=" my-2 bg-white rounded-lg shadow-sm overflow-hidden hover:shadow-lg hover:bg-blue-100 transition-shadow duration-300">
                            <div class="p-6 {{ $service['color'] }}">
                                <div class="flex justify-between items-start">
                                    <h3 class="text-xl font-semibold mb-2">{{ $service['title'] }}</h3>
                                    @isset($service['icon'])
                                        {{-- @svg("$service[icon]","$service[iconColor]") --}}

                                        {{ svg($service['icon'], "$service[iconColor]") }}
                                    @endisset
                                </div>
                            </div>
                            <div class="p-6">
                                {{-- <h3 class="text-xl font-semibold mb-2">{{ $service['title'] }}</h3> --}}
                                <p class="text-gray-600">{{ $service['description'] }}</p>
                            </div>
                        </div>
                    </a>
                @endisset
            @endforeach
        </div>
    </main>
@endsection
