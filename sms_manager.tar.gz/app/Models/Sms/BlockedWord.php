<?php

namespace App\Models\Sms;

use Cache;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class BlockedWord extends Model
{
    use HasFactory;

    protected $fillable = [
        'word',
        'description',
        'is_active',
        'detection_count',
    ];

    protected $casts = [
        'is_active' => 'boolean',
        'detection_count' => 'integer',
    ];

    // رابطه با کاربر ایجادکننده
    public function creator()
    {
        return $this->belongsTo(\App\Models\User::class, 'created_by');
    }
    /**
     * افزایش شمارنده تشخیص
     */
    public function incrementDetectionCount()
    {
        $this->increment('detection_count');
    }

    /**
     * بررسی وجود کلمات غیرمجاز در متن
     * از طریق کوئری
     */
    public static function checkMessageQuery($message)
    {
        $activeWords = self::where('is_active', true)->get();
        $foundWords = [];

        foreach ($activeWords as $blockedWord) {
            $pattern = '/\b' . preg_quote($blockedWord->word, '/') . '\b/iu';

            if (preg_match($pattern, $message)) {
                $foundWords[] = $blockedWord->word;
                $blockedWord->incrementDetectionCount();
            }
        }

        return $foundWords;
    }

    /**
     * بررسی وجود کلمات غیرمجاز در متن
     * از طریق کش
     */
    public static function checkMessage($message)
    {
        $blockedWords = Cache::remember('blocked_words', 3600, function () {
            return self::where('is_active', true)->pluck('word')->toArray();
        });
        $found = [];

        foreach ($blockedWords as $word) {  
            if (stripos($message, $word) !== false)
                $found[] = $word;
        }
        return $found;
    }
}
