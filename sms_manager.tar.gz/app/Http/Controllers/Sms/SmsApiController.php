<?php

namespace App\Http\Controllers\Sms;



use App\Http\Controllers\Controller;
use App\Jobs\Sms\SendBulkSmsJob;
use App\Models\Sms\Provider;
use App\Models\Sms\Message;
use App\Models\Sms\Credential;
use App\Models\Sms\BlockedWord;
use App\Models\Sms\Social;
use App\Services\Sms\SmsSenderService;
use App\Services\Sms\SocialSenderService;
// use Hash;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Bus;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;

class SmsApiController extends Controller
{

    /**
     * دریافت توکن دسترسی با Basic Auth
     * 
     * ⚠️ غیرفعال شده — از static_token استفاده کنید
     * 
     * مثال:
     * Authorization: Basic dXNlcm5hbWU6cGFzc3dvcmQ=
     */
    public function getApiToken(Request $request)
    {
        return response()->json([
            'success' => false,
            'error_code' => 'ENDPOINT_DISABLED',
            'message' => 'این endpoint غیرفعال است. از static_token استفاده کنید.'
        ], 400);

        /*
        $authHeader = $request->header('Authorization');

        // 1. بررسی وجود هدر Authorization و نوع Basic
        if (!$authHeader || !str_starts_with($authHeader, 'Basic ')) {
            return response()->json([
                'success' => false,
                'error_code' => 'BASIC_AUTH_REQUIRED',
                'message' => 'هدر Authorization با نوع Basic الزامی است.',
                'example' => 'Authorization: Basic dXNlcm5hbWU6cGFzc3dvcmQ='
            ], 401);
        }

        // 2. استخراج Base64 و دیکد کردن
        $base64Credentials = trim(substr($authHeader, 6)); // حذف "Basic "
        $credentials = base64_decode($base64Credentials, true);

        if ($credentials === false || !str_contains($credentials, ':')) {
            return response()->json([
                'success' => false,
                'error_code' => 'BASIC_AUTH_INVALID_FORMAT',
                'message' => 'فرمت Basic Auth نامعتبر است.'
            ], 401);
        }

        // 3. جدا کردن username و password
        [$username, $password] = explode(':', $credentials, 2);

        if (empty($username) || empty($password)) {
            return response()->json([
                'success' => false,
                'error_code' => 'CREDENTIALS_EMPTY',
                'message' => 'نام کاربری یا رمز عبور خالی است.'
            ], 401);
        }

        // 4. پیدا کردن اعتبارنامه
        $credential = Credential::where('username', $username)
            ->where('is_active', true)
            ->first();


        if (!$credential || !Hash::check($password, $credential->password)) {
            return response()->json([
                'success' => false,
                'error_code' => 'CREDENTIALS_INVALID',
                'message' => 'نام کاربری یا رمز عبور اشتباه است.'
            ], 401);
        }

        // 5. تولید توکن با اعتبار ۱ ساعت
        $token = $credential->createToken('sms-access-token', ['send-sms'], now()->addHour())->plainTextToken;


        return response()->json([
            'success' => true,
            'message' => 'ورود موفق. توکن با اعتبار ۱ ساعت صادر شد.',
            'access_token' => $token,
            'token_type' => 'Bearer',
            'expires_in' => 3600, // ثانیه
            'expires_at' => now()->addHour()->format('Y-m-d H:i:s'),
        ]);
        */
    }

    /*
     * ⚠️ غیرفعال شده — از static_token استفاده کنید
     * دریافت توکن دسترسی با نام کاربری و رمز عبور
     */
    public function __getAccessToken(Request $request)
    {
        return response()->json([
            'success' => false,
            'error_code' => 'ENDPOINT_DISABLED',
            'message' => 'این endpoint غیرفعال است. از static_token استفاده کنید.'
        ], 400);

        /*
        $validator = Validator::make($request->all(), [
            'username' => 'required|string',
            'password' => 'required|string',
        ]);

        if ($validator->fails()) {
            return response()->json([
                'success' => false,
                'error_code' => 'VALIDATION_ERROR',
                'errors' => $validator->errors()
            ], 422);
        }

        $credential = Credential::where('username', $request->username)->first();

        if (!$credential || !Hash::check($request->password, $credential->password) || !$credential->is_active) {
            return response()->json([
                'success' => false,
                'error_code' => 'CREDENTIALS_INVALID',
                'message' => 'نام کاربری یا رمز عبور نامعتبر است یا حساب غیرفعال است'
            ], 401);
        }

        // ایجاد توکن dynamic (مثلاً با انقضای ۱ روز)
        $expiration = now()->addDay();

        $tokenInstance = $credential->createToken('dynamic-token', ['send-sms'], $expiration);

        // مهم: حذف همه توکن‌های dynamic قبلی این کاربر
        $credential->tokens()->where('name', 'dynamic-token')->delete();

        return response()->json([
            'success'     => true,
            'access_token' => $tokenInstance->plainTextToken,
            'expires_in'  => now()->diffInSeconds($expiration),
            'token_type'  => 'Bearer',
            'expires_at'  => $expiration->toDateTimeString(),
        ]);
        */
    }


    /**
     * Summary of send
     * @param Request $request
     */
    public function send(Request $request)
    {

        // احراز هویت با Sanctum (توکن موقت)
        $credential = $request->user('sanctum');

        if (!$credential) {
            return response()->json([
                'success' => false,
                'error_code' => 'UNAUTHORIZED',
                'message' => 'توکن دسترسی نامعتبر یا منقضی شده است.',
                'hint' => 'لطفا توکن خود را بررسی یا با ادمین تماس بگیرید.'
            ], 401);
        }

        // اعتبارسنجی ورودی‌ها
        $validator = Validator::make($request->all(), [
            'message' => 'required|array|min:1|max:100',
            'message.*' => 'required|string|max:330',
            'recipients'    => 'required|array|min:1|max:100',
            'recipients.*'  => 'required|string|regex:/^09[0-9]{9}$/',
            'type'          => 'nullable|in:news,default', // اختیاری
        ], [
            'recipients.required' => 'شماره گیرنده الزامی است.',
            'recipients.array' => ' شماره گیرنده بایست بصورت آرایه باشند.',
            'recipients.min' => 'حداقل یک شماره گیرنده الزامی است.',
            'recipients.max' => 'حداکثر 100 شماره گیرنده مجاز می باشد.',
            'recipients.*.regex' => 'فرمت شماره موبایل :input صحیح نیست. (مثال: 09123456789)',

            'message.required' => 'متن پیام الزامی است.',
            'message.array' => ' پیام بایست بصورت آرایه باشند.',
            'message.min' => 'حداقل یک پیام الزامی است.',
            'message.max' => 'حداکثر 100 پیام ارسالی مجاز می باشد.',
            'message.*.max' => 'متن پیام نمی‌تواند بیشتر از 330 کاراکتر باشد.',
            'message.*.string' => ' پیام ارسالی بایست بصورت استرینگ باشد.',
            'type.in' => 'نوع پیامک نامعتبر است',
        ]);

        if ($validator->fails()) {
            return response()->json([
                'success' => false,
                'error_code' => 'VALIDATION_ERROR',
                'message' => 'خطا در اطلاعات ارسالی',
                'errors' => $validator->errors()
            ], 422);
        }

        $validated = $validator->validated();

        // بررسی تعداد پیام ها و شماره ها
        $messageCount = count($validated['message']);
        $numberCount = count($validated['recipients']);
        // اعتبار سنجی تعداد پیام ها با تعداد شماره های ارسالی
        if (($messageCount > 1) && ($messageCount != $numberCount)) {
            return response()->json([
                'success' => false,
                'error_code' => 'MESSAGE_COUNT_MISMATCH',
                'message' => 'تعداد پیام های ارسالی متناسب با تعداد شماره ها نیست ',
            ], 403);
        }


        // اگر یک پیام بود 
        if ($messageCount == 1) {

            return     $this->sendOne($request, $credential);
        }
        if ($messageCount > 1) {
            return     $this->sendBulk($request, $credential);
        }
    }

    /**
     * Summary of sendBulk
     * @param Request $request
     * @param mixed $credential
     * @return \Illuminate\Http\JsonResponse
     */
    public function sendBulk(Request $request, $credential)
    {
        // چند پیام برای چند شماره 
        // $credential باید از طریق $request->user('sanctum') در تابع اصلی دریافت شود.
        try {

            $recipients     = $request->recipients;
            $messages       = $request->message; // فرض بر اینکه آرایه پیام ها با آرایه شماره ها هم اندازه است
            $recipientsCount = count($recipients);
            $successfulMessageIds = [];
            $blockedCount = 0;
            $allBlockedWords = [];

            if ($recipientsCount !== count($messages)) {
                return response()->json([
                    'success' => false,
                    'error_code' => 'MESSAGE_COUNT_MISMATCH',
                    'message' => 'تعداد پیام ها و شماره ها باید یکسان باشد.',
                ], 400);
            }

            // 1. پیش-بررسی: چک کردن محدودیت روزانه قبل از هرگونه ثبت در دیتابیس
            $dailyCheck = $credential->canSendMessage($recipientsCount);
            if (!$dailyCheck['can_send']) {
                return response()->json([
                    'success' => false,
                    'error_code' => 'DAILY_LIMIT_EXCEEDED',
                    'message' => $dailyCheck['reason'],
                ], 403);
            }

            // 2. شروع تراکنش برای ثبت در دیتابیس
            DB::beginTransaction();

            try {
                foreach ($recipients as $key => $recipient) {
                    $currentMessage = $messages[$key];

                    // بررسی کلمات ممنوعه 
                    $blockedWords = BlockedWord::checkMessage($currentMessage);

                    // ذخیره پیام های ممنوعه
                    if (count($blockedWords) > 0) {
                        $blockedCount++;
                        $allBlockedWords = array_merge($allBlockedWords, $blockedWords);

                        Message::create([
                            'sms_credential_id' => $credential->id,
                            'recipient'         => $recipient,
                            'message'           => $currentMessage,
                            'status'            => 'blocked',
                            'blocked_words'     => json_encode($blockedWords),
                            'blocked_reason'    => 'کلمات غیرمجاز یافت شد',
                            'type'              => $request->type ?? 'default',
                        ]);

                        continue; // رفتن به گیرنده بعدی
                    }

                    // ایجاد رکورد پیام های موفق
                    $message = Message::create([
                        'sms_credential_id' => $credential->id,
                        'recipient'         => $recipient,
                        'message'           => $currentMessage,
                        'status'            => 'pending',
                        'type'              => $request->type ?? 'default',
                    ]);

                    $successfulMessageIds[] = $message->id;
                }

                $sentCount = count($successfulMessageIds);

                // افزایش شمارنده روزانه فقط برای پیام‌های موفق (بعد از ثبت موفق)
                if ($sentCount > 0) {
                    $credential->incrementDailyCount($sentCount);
                }

                // 3. Commit تراکنش (پس از ثبت همه موارد در دیتابیس)
                DB::commit();
            } catch (\Exception $e) {
                // Rollback در صورت هرگونه خطای دیتابیسی در حلقه
                DB::rollBack();
                Log::error('خطا در ثبت دیتابیس ارسال انبوه: ' . $e->getMessage(), [
                    'trace' => $e->getTraceAsString(),
                ]);
                return response()->json([
                    'success' => false,
                    'error_code' => 'SERVER_ERROR',
                    'message' => 'خطا در ثبت پیام‌ها در پایگاه داده.',
                    'error'   => config('app.debug') ? $e->getMessage() : 'خطای سرور',
                ], 500);
            }


            // 4. ارسال پیام‌ها (خارج از تراکنش)
            if (!empty($successfulMessageIds)) {
                // Dispatch Job
                SendBulkSmsJob::dispatch($successfulMessageIds)->onQueue('sms');
            }

            return response()->json([
                'success'          => true,
                'message'          => "{$sentCount} پیام با موفقیت در صف ارسال قرار گرفت.",
                'total_requested'  => $recipientsCount,
                'sent_count'       => $sentCount,
                'blocked_count'    => $blockedCount,
                'blocked_words'    => array_unique($allBlockedWords),
            ], 202);
        } catch (\Exception $e) {
            // این قسمت برای خطاهای خارج از بلوک try/catch اصلی (مثل نبود credential) است
            Log::error('خطای کلی در کنترلر sendBulk: ' . $e->getMessage(), [
                'request' => $request->except(['password']),
            ]);

            return response()->json([
                'success' => false,
                'error_code' => 'SERVER_ERROR',
                'message' => 'خطا در پردازش درخواست ارسال انبوه.',
                'error'   => config('app.debug') ? $e->getMessage() : 'خطای سرور',
            ], 500);
        }
    }

    /**
     * sendOne
     * ارسال پیامک هایی که فقط 1 پیام مشترک دارند
     *
     * @param  mixed $request
     * 
     */
    public function sendOne(Request $request, $credential)
    {

        try {

            $baaseMessage  = $request->message[0];
            $recipients     = array_unique($request->recipients); // حذف شماره های تکراری‌
            $recipientsCount = count($recipients);
            $successfulMessageIds = [];
            $blockedCount = 0;

            // بررسی کلمات غیرمجاز
            $blockedWords = BlockedWord::checkMessage($baaseMessage);

            // افزودن تعداد کلمات غیر مجاز 
            $blockedCount += count($blockedWords);



            // اگر آرایه است → از empty استفاده کن
            if (is_array($blockedWords) ? !empty($blockedWords) : $blockedWords->isNotEmpty()) {
                $wordsArray = is_array($blockedWords) ? $blockedWords : $blockedWords->toArray();

                DB::beginTransaction();
                // ذخیره پیام های ممنوعه در پایگاه داده 
                foreach ($recipients as $recipient) {
                    Message::create([
                        'sms_credential_id' => $credential->id,
                        'recipient'         => $recipient,
                        'message'           => $baaseMessage,
                        'status'            => 'blocked',
                        'blocked_words'     => json_encode($wordsArray),
                        'blocked_reason'     => 'کلمات غیرمجاز یافت شد',
                        'type'              => $request->type ?? 'default',
                    ]);
                }
                DB::commit();

                return response()->json([
                    'success' => false,
                    'error_code' => 'BLOCKED_WORDS',
                    'message' => "پیام شما دارای کلمات غیر مجاز است و مسدود شد",
                    'blockedCount' => $blockedCount,
                    'blocked_words' => $wordsArray
                ], 422);
            }


            // چک محدودیت روزانه
            $canSend = $credential->canSendMessage(count($request->recipients));
            if (!$canSend['can_send']) {
                return response()->json([
                    'success' => false,
                    'error_code' => 'DAILY_LIMIT_EXCEEDED',
                    'message' => $canSend['reason'],
                ], 403);
            }

            // --- ثبت پیام‌های آماده ارسال (با chunking برای جلوگیری از memory limit) ---
            $successfulMessageIds = [];
            $chunks = array_chunk($recipients, 100);

            foreach ($chunks as $chunk) {
                DB::beginTransaction();
                foreach ($chunk as $recipient) {
                    $message = Message::create([
                        'sms_credential_id' => $credential->id,
                        'recipient'         => $recipient,
                        'message'           => $baaseMessage,
                        'status'            => 'pending',
                        'type'              => $request->type ?? 'default',
                    ]);
                    $successfulMessageIds[] = $message->id;
                }
                DB::commit();
            }


            // افزایش شمارنده روزانه فقط برای پیام‌های موفق
            $sentCount = count($successfulMessageIds);
            if ($sentCount > 0) {
                $credential->incrementDailyCount($sentCount);
            }

            // ارسال پیامک با استفاده از SendBulkSmsJob
            if (!empty($successfulMessageIds)) {
                // فرض بر این است که همه این پیام‌ها از یک نوع (یا از نوعی که نیازی به تأخیر ندارد) هستند.
                // اگر نیاز به تفکیک تأخیر دارید، باید منطق پیچیده‌تری به کنترلر اضافه شود.

                SendBulkSmsJob::dispatch($successfulMessageIds)->onQueue('sms');
            }

            return response()->json([
                'success'          => true,
                'message'          => "{$recipientsCount} پیام با موفقیت در صف ارسال قرار گرفت",
                'total_requested'  => $recipientsCount,
                'sent_count'       => $sentCount,
                'blocked_count'    => $blockedCount,
            ], 202);
        } catch (\Exception $e) {
            DB::rollBack();
            Log::error('خطا در ارسال تکی پیامک: ' . $e->getMessage(), [
                'trace' => $e->getTraceAsString(),
            ]);

            return response()->json([
                'success' => false,
                'error_code' => 'SERVER_ERROR',
                'message' => 'خطا در پردازش درخواست ارسال پیامک تکی',
                'error'   => config('app.debug') ? $e->getMessage() : 'خطای سرور',
            ], 500);
        }
    }

    /**
     * Summary of sendOtp
     * @param Request $request
     * @return \Illuminate\Http\JsonResponse
     */
    public function sendOtp(Request $request)
    {
        $credential = $request->user('sanctum');

        if (!$credential) {
            return response()->json([
                'success' => false,
                'error_code' => 'UNAUTHORIZED',
                'message' => 'توکن دسترسی نامعتبر یا منقضی شده است.',
            ], 401);
        }

        // اعتبارسنجی
        $validator = Validator::make($request->all(), [
            'recipient' => 'required|string|regex:/^09[0-9]{9}$/',
            'message'   => 'required|regex:/^[0-9]{4,6}$/',
        ], [
            'recipient.required' => 'شماره گیرنده الزامی است.',
            'recipient.regex'    => 'فرمت شماره موبایل صحیح نیست.',
            'message.required'   => 'کد پیام الزامی است.',
            'message.regex'      => 'کد پیام باید شامل عدد باشد.',
        ]);

        if ($validator->fails()) {
            return response()->json([
                'success' => false,
                'error_code' => 'VALIDATION_ERROR',
                'message' => 'داده‌های ورودی نامعتبر است',
                'errors'  => $validator->errors(),
            ], 422);
        }

        // بررسی محدودیت
        $canSend = $credential->canSendMessage();
        if (!$canSend['can_send']) {
            return response()->json([
                'success' => false,
                'error_code' => 'DAILY_LIMIT_EXCEEDED',
                'message' => $canSend['reason']
            ], 403);
        }

        try {
            // 1. شروع تراکنش فقط برای ثبت رکورد و افزایش شمارنده
            DB::beginTransaction();

            $message = Message::create([
                'sms_credential_id' => $credential->id,
                'recipient'         => $request->recipient,
                'message'           => $request->message,
                'status'            => 'pending',
                'type'              => 'otp',
            ]);

            // افزایش شمارنده روزانه
            $credential->incrementDailyCount(1);

            // 2. بستن تراکنش و commit کردن دیتابیس
            // حالا رکورد در دیتابیس موجود است و تغییرات دائمی شده‌اند.
            DB::commit();

            // 3. ارسال پیامک (خارج از تراکنش)
            // حتی اگر ارسال ناموفق بود، رکورد در دیتابیس می‌ماند و با status 'failed' آپدیت می‌شود.
            $this->sendImmediately($message);

            // 4. ارسال پیامک به شبکه های اجتماعی
            $this->sendSocial($message);

            return response()->json([
                'success'      => true,
                'message'      => 'پیامک با موفقیت ثبت و ارسال شد.',
                'request_id'   => $message->id, // شناسه پیام برای پیگیری
            ], 200); // 200 چون پردازش کامل شده است (حتی اگر خطای ارسال داشته باشد، کاربر باید از وضعیت پیام باخبر شود)

        } catch (\Exception $e) {
            DB::rollBack();
            Log::error('خطا در فرآیند ارسال OTP: ' . $e->getMessage(), [
                'trace' => $e->getTraceAsString(),
                'recipient' => $request->recipient ?? 'unknown',
            ]);

            return response()->json([
                'success' => false,
                'error_code' => 'SERVER_ERROR',
                'message' => 'خطا در پردازش درخواست.',
                'error'   => config('app.debug') ? $e->getMessage() : 'خطای سرور',
            ], 500);
        }
    }

    /**
     * ارسال فوری پیامک بدون صف
     * این متد مستقیماً وضعیت رکورد را در دیتابیس آپدیت می‌کند
     */
    protected function sendImmediately(Message $message)
    {
        // دریافت پرووایدر پیش‌فرض فعال
        $provider = Provider::getDefault();

        if (!$provider) {
            $message->markAsFailed('هیچ پرووایدر فعالی یافت نشد.');
            return;
        }

        try {
            // ایجاد نمونه سرویس با تزریق Provider
            $sender = new SmsSenderService($provider);

            // تنظیم پارامترهای OTP (اگر نوع پیام OTP باشد)
            if ($message->type === 'otp') {
                $sender->setOtpParameters(true, null);
            } else {
                $sender->setOtpParameters(false, null);
            }

            // ارسال به درگاه
            $result = $sender->sendToProvider($message->recipient, $message->message);

            // آپدیت وضعیت در دیتابیس بر اساس نتیجه
            if ($result['success']) {
                $message->markAsSent($result['gateway_id'] ?? null);
            } else {
                $message->markAsFailed($result['error'] ?? 'خطای ناشناخته در ارسال');
            }

            // لاگ موفقیت/خطا برای دیباگ
            Log::info("OTP Sent Status: " . ($result['success'] ? 'Success' : 'Failed') . " | ID: " . $message->id);
        } catch (\Exception $e) {
            // در صورت خطای شدید (مثل قطع شبکه)، رکورد را به عنوان 'failed' ثبت کنید
            $message->markAsFailed('خطای سیستمی در ارسال: ' . $e->getMessage());
            Log::error("خطای داخلی در ارسال فوری OTP: " . $e->getMessage());
        }
    }
    protected function sendSocial(Message $message)
    {
        // دریافت پیام رسان پیش‌فرض فعال
        $social = Social::getDefault();

        if (!$social) {
            $message->markAsSocial('هیچ پیام رسان فعالی یافت نشد.');
            return;
        }

        try {
            // ایجاد نمونه سرویس با تزریق social
            $sender = new SocialSenderService($social);

            // تنظیم پارامترهای OTP (اگر نوع پیام OTP باشد)
            if ($message->type === 'otp') {
                $sender->setOtpParameters(true, null);
            } else {
                $sender->setOtpParameters(false, null);
            }

            // ارسال به درگاه
            $result = $sender->sendToSocial($message->recipient, $message->message);

            // آپدیت وضعیت در دیتابیس بر اساس نتیجه
            if ($result['success']) {
                $message->markAsSocial('پیام ارسال شد', $social->name, $result['message_id'] ?? null);
            } else {
                $message->markAsSocial($result['error'] ?? 'خطای ناشناخته در ارسال');
            }

            // لاگ موفقیت/خطا برای دیباگ
            Log::info("OTP Sent Status: " . ($result['success'] ? 'Success' : 'Failed') . " | ID: " . $message->id);
        } catch (\Exception $e) {
            // در صورت خطای شدید (مثل قطع شبکه)، رکورد را به عنوان 'failed' ثبت کنید
            $message->markAsSocial('خطای سیستمی در ارسال: ' . $e->getMessage());
            Log::error("خطای داخلی در ارسال فوری OTP در پیام رسان: " . $e->getMessage());
        }
    }
}
