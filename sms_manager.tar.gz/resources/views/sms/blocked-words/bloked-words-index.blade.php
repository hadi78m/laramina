@extends('layouts.mclsApp')
@section('content')
    <x-elements.sidebar>
        <x-sidebars.sms />
    </x-elements.sidebar>
    <div class="container mx-auto px-4 py-8">
        <!-- بررسی متن -->
        <div class="bg-gradient-to-r from-purple-50 to-pink-50 border-2 border-purple-200 rounded-xl shadow-lg p-6 mb-6">
            <div class="flex items-center gap-3 mb-4">
                <div class="bg-purple-600 text-white w-12 h-12 rounded-full flex items-center justify-center">
                    <i class="fas fa-search text-xl"></i>
                </div>
                <h4 class="text-xl font-bold text-purple-900">بررسی متن برای کلمات غیرمجاز</h4>
            </div>

            <form id="checkTextForm">
                <div class="flex gap-3">
                    <textarea name="text" rows="4" required
                        class="flex-1 px-4 py-3 border-2 border-purple-200 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent transition-all resize-none"
                        placeholder="متن خود را برای بررسی وارد کنید..."></textarea>
                    <button type="submit"
                        class="px-8 bg-gradient-to-r from-purple-600 to-pink-600 text-white rounded-lg hover:from-purple-700 hover:to-pink-700 transition-all font-semibold flex items-center gap-2">
                        <i class="fas fa-check"></i>
                        بررسی
                    </button>
                </div>
            </form>

            <div id="checkResult" class="mt-4 hidden"></div>
        </div>

        <!-- لیست کلمات -->
        <div class="bg-white rounded-lg shadow-lg overflow-hidden">
            <div class="bg-gradient-to-r from-red-600 to-pink-600 text-white px-6 py-4 flex justify-between items-center">
                <h3 class="text-xl font-bold">لیست کلمات غیرمجاز</h3>
                <button onclick="openAddModal()"
                    class="bg-white text-red-600 px-4 py-2 rounded-lg hover:bg-red-50 transition-all duration-200 flex items-center gap-2 font-semibold">
                    <i class="fas fa-plus"></i>
                    افزودن کلمه جدید
                </button>
            </div>

            <div class="p-1">
                <x-form.table id="wordsTable">
                    <x-slot name="thead">
                        <tr class="">
                            {{-- <th class="px-4 py-3 text-right text-sm font-semibold text-gray-700">شناسه</th> --}}
                            <th class="px-4 py-3 text-right text-sm font-semibold text-gray-700">کلمه</th>
                            <th class="px-4 py-3 text-right text-sm font-semibold text-gray-700">توضیحات</th>
                            <th class="px-4 py-3 text-right text-sm font-semibold text-gray-700">وضعیت</th>
                            <th class="px-4 py-3 text-right text-sm font-semibold text-gray-700">ایجاد کننده</th>
                            <th class="px-4 py-3 text-right text-sm font-semibold text-gray-700">تاریخ ایجاد</th>
                            <th class="px-4 py-3 text-right text-sm font-semibold text-gray-700">عملیات</th>
                        </tr>

                    </x-slot>
                    {{-- <tbody class="text-center">
                        <tr class="text-center"></tr>
                    </tbody> --}}
                </x-form.table>
            </div>
        </div>
    </div>

    <!-- Modal افزودن کلمه -->
    <div id="addWordModal" class="hidden fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center p-4">
        <div class="bg-white rounded-xl shadow-2xl w-full max-w-md transform transition-all">
            <div
                class="bg-gradient-to-r from-red-600 to-pink-600 text-white px-6 py-4 rounded-t-xl flex justify-between items-center">
                <h5 class="text-lg font-bold">افزودن کلمه غیرمجاز</h5>
                <button onclick="closeAddModal()" class="text-white hover:text-gray-200 transition-colors">
                    <i class="fas fa-times text-xl"></i>
                </button>
            </div>

            <form id="addWordForm" class="p-6">
                <div class="space-y-4">
                    <div>
                        <label class="block text-sm font-semibold text-gray-700 mb-2">
                            کلمه <span class="text-red-500">*</span>
                        </label>
                        <input type="text" name="word" required
                            class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-transparent transition-all"
                            placeholder="کلمه غیرمجاز">
                    </div>

                    <div>
                        <label class="block text-sm font-semibold text-gray-700 mb-2">
                            توضیحات
                        </label>
                        <textarea name="description" rows="3"
                            class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-transparent transition-all"
                            placeholder="توضیحات اختیاری..."></textarea>
                    </div>
                </div>

                <div class="flex gap-3 mt-6">
                    <button type="button" onclick="closeAddModal()"
                        class="flex-1 px-4 py-2 bg-gray-200 text-gray-700 rounded-lg hover:bg-gray-300 transition-colors font-semibold">
                        انصراف
                    </button>
                    <button type="submit"
                        class="flex-1 px-4 py-2 bg-gradient-to-r from-red-600 to-pink-600 text-white rounded-lg hover:from-red-700 hover:to-pink-700 transition-all font-semibold">
                        ذخیره
                    </button>
                </div>
            </form>
        </div>
    </div>

    <!-- Modal ویرایش کلمه -->
    <div id="editWordModal" class="hidden fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center p-4">
        <div class="bg-white rounded-xl shadow-2xl w-full max-w-md transform transition-all">
            <div
                class="bg-gradient-to-r from-orange-600 to-red-600 text-white px-6 py-4 rounded-t-xl flex justify-between items-center">
                <h5 class="text-lg font-bold">ویرایش کلمه غیرمجاز</h5>
                <button onclick="closeEditModal()" class="text-white hover:text-gray-200 transition-colors">
                    <i class="fas fa-times text-xl"></i>
                </button>
            </div>

            <form id="editWordForm" class="p-6">
                <input type="hidden" name="word_id" id="edit_word_id">

                <div class="space-y-4">
                    <div>
                        <label class="block text-sm font-semibold text-gray-700 mb-2">
                            کلمه <span class="text-red-500">*</span>
                        </label>
                        <input type="text" name="word" id="edit_word" required
                            class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-transparent transition-all">
                    </div>

                    <div>
                        <label class="block text-sm font-semibold text-gray-700 mb-2">
                            توضیحات
                        </label>
                        <textarea name="description" id="edit_description" rows="3"
                            class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-transparent transition-all"></textarea>
                    </div>

                    <div>
                        <label class="block text-sm font-semibold text-gray-700 mb-2">
                            وضعیت
                        </label>
                        <select name="is_active" id="edit_is_active"
                            class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-transparent transition-all">
                            <option value="1">فعال</option>
                            <option value="0">غیرفعال</option>
                        </select>
                    </div>
                </div>

                <div class="flex gap-3 mt-6">
                    <button type="button" onclick="closeEditModal()"
                        class="flex-1 px-4 py-2 bg-gray-200 text-gray-700 rounded-lg hover:bg-gray-300 transition-colors font-semibold">
                        انصراف
                    </button>
                    <button type="submit"
                        class="flex-1 px-4 py-2 bg-gradient-to-r from-orange-600 to-red-600 text-white rounded-lg hover:from-orange-700 hover:to-red-700 transition-all font-semibold">
                        به‌روزرسانی
                    </button>
                </div>
            </form>
        </div>
    </div>
@endsection

@section('scripts')
    @include('sms.blocked-words.script.bloked-words-script')
@endsection
