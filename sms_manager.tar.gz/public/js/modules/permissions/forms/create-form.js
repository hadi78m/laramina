const publicLang   = AdminLang.getNamespace('common');
const moduleFields = AdminLang.getNamespace('modules.permissions.fields');
const moduleActions = AdminLang.getNamespace('modules.permissions.actions');

export const createForm = {

    endpoint: 'manage.permissions.store',
    updateEndpoint: 'manage.permissions.update',
    deleteEndpoint: 'manage.permissions.destroy',

    title: moduleActions.create || publicLang.create,

    fields: [
        {
            name: 'name',
            label: publicLang.name,
            type: 'text'
        },
    ],

    buttons: {
        submit: publicLang.save,
        cancel: publicLang.cancel,
    }
};