<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('sms_credentials', function (Blueprint $table) {
            $table->text('static_token_plain')->nullable()->after('password'); // توکن خام (رمزنگاری شود)
            $table->string('allowed_ip', 45)->nullable()->after('static_token_plain'); // IPv4 یا IPv6
        });
    }

    public function down(): void
    {
        Schema::table('sms_credentials', function (Blueprint $table) {
            $table->dropColumn(['static_token_plain', 'allowed_ip']);
        });
    }
};