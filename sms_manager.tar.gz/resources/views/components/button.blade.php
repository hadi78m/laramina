<button
    {{ $attributes->merge([
        'type' => 'button',
        'class' =>
            'submit bg-blue-700 hover:bg-blue-800 text-white py-2 px-4 rounded-md flex items-center justify-center md:w-96 mx-auto w-full focus:outline-none focus:border-blue-900 focus:ring focus:ring-blue-300 disabled:opacity-25 transition ease-in-out duration-150',
    ]) }}>
    {{ $slot }}
    <div class="custom-loader" id="searchLoader"></div>
    <x-bi-search class="mr-2" />
</button>

{{-- use --}}

{{-- <x-button type="submit" id="searchBtn">
    <span id="searchBtnText">جستجو</span>
</x-button> --}}