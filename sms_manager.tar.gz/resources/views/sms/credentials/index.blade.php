@extends('layouts.mclsApp')

@section('content')
    <x-elements.sidebar>
        <x-sidebars.sms />
    </x-elements.sidebar>
    <div id="admin-module" data-module="sms/credentials"></div>
    @include('sms.credentials.modal.credential-modal')

@endsection
@section('scripts')
    @include('sms.credentials.script.credential-script-module')
@endsection