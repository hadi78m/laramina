/*!
 * showalert.production.js
 * Enterprise SweetAlert + Ajax Helper
 * Namespace: AppAlert (Backward Compatible)
 * Requires: jQuery, SweetAlert2
 */

window.AppAlert = (function ($, Swal) {
    'use strict';

    if (!$) throw new Error('AppAlert requires jQuery');
    if (!Swal) throw new Error('AppAlert requires SweetAlert2');

    let loadingCount = 0;
    let activeRequests = {};

    /* =========================
     * Utils
     * ========================= */

    function csrfToken() {
        return $('meta[name="csrf-token"]').attr('content') || '';
    }

    function isFormData(data) {
        return typeof FormData !== 'undefined' && data instanceof FormData;
    }

    function jq(el) {
        if (!el) return null;
        return el instanceof jQuery ? el : $(el);
    }

    function escapeHtml(str) {
        return String(str ?? '')
            .replace(/&/g, '&amp;')
            .replace(/</g, '&lt;')
            .replace(/>/g, '&gt;')
            .replace(/"/g, '&quot;')
            .replace(/'/g, '&#039;');
    }

    /* =========================
     * SweetAlert Base
     * ========================= */

    const SwalBase = Swal.mixin({
        customClass: {
            popup: 'rtl text-center',
            title: 'text-center',
            htmlContainer: 'text-center',
            confirmButton: 'btn btn-primary mx-1',
            cancelButton: 'btn btn-secondary mx-1'
        },
        buttonsStyling: false,
        reverseButtons: true
    });

    const ToastBase = Swal.mixin({
        toast: true,
        position: 'top-end',
        showConfirmButton: false,
        timer: 3000,
        timerProgressBar: true,
        customClass: { popup: 'rtl' }
    });

    /* =========================
     * Alerts
     * ========================= */

    function showToast(icon, title) {
        return ToastBase.fire({ icon, title });
    }

    function showSuccess(message = 'عملیات با موفقیت انجام شد', asHtml = true) {
        const config = {
            icon: 'success',
            title: '<div class="text-center">موفق</div>',
            confirmButtonText: 'باشه'
        };

        if (asHtml) {
            config.html = message;
        } else {
            config.text = message;
        }

        return Swal.fire(config);
    }


    function showError(message = 'خطایی رخ داده است') {
        return Swal.fire({
            icon: 'error',
            title: '<div class="text-center">خطا</div>',
            html: message,
            confirmButtonText: 'متوجه شدم'
        });
    }

    function showWarning(message = 'خطایی رخ داده است') {
        return Swal.fire({
            icon: 'warning',
            title: '<div class="text-center">خطا</div>',
            html: message,
            confirmButtonText: 'متوجه شدم'
        });
    }

    function showLoading(title = 'در حال پردازش...') {
        loadingCount++;
        if (Swal.isVisible()) return;

        Swal.fire({
            title,
            allowOutsideClick: false,
            allowEscapeKey: false,
            showConfirmButton: false,
            didOpen: () => Swal.showLoading()
        });
    }

    function hideLoading(force = false) {
        if (force) {
            loadingCount = 0;
            Swal.close();
            return;
        }
        loadingCount = Math.max(loadingCount - 1, 0);
        if (loadingCount === 0) Swal.close();
    }

    /* =========================
     * Validation
     * ========================= */

    function clearValidation(form) {
        const $f = jq(form);
        if (!$f) return;

        $f.find('.is-invalid').removeClass('is-invalid');
        $f.find('.invalid-feedback.ajax').remove();
    }

    function showValidationErrors(form, errors) {
        const $f = jq(form);
        if (!$f || !errors) return;

        $.each(errors, function (field, messages) {
            const msg = Array.isArray(messages) ? messages[0] : messages;
            const $input = $f.find(`[name="${field}"], [name="${field}[]"]`).first();

            if ($input.length) {
                $input.addClass('is-invalid');
                $input.after(
                    `<div class="invalid-feedback ajax">${escapeHtml(msg)}</div>`
                );
            }
        });
    }

    function parseValidationErrors(errors) {
        let html = '<ul class="text-start">';
        $.each(errors, function (_, msgs) {
            (Array.isArray(msgs) ? msgs : [msgs]).forEach(m => {
                html += `<li>${escapeHtml(m)}</li>`;
            });
        });
        return html + '</ul>';
    }

    /* =========================
     * Ajax Core
     * ========================= */

    function handleAjaxError(xhr, options = {}) {
        if (xhr.status === 422 && xhr.responseJSON?.errors) {
            if (options.form) {
                clearValidation(options.form);
                showValidationErrors(options.form, xhr.responseJSON.errors);
            }
            showError(parseValidationErrors(xhr.responseJSON.errors));
            return;
        }

        let msg = xhr.responseJSON?.message || 'خطای سرور رخ داده است';

        if (xhr.status === 401) msg = 'دسترسی غیرمجاز';
        if (xhr.status === 403) msg = 'عدم دسترسی';
        if (xhr.status === 419) msg = 'نشست منقضی شده است';
        if (xhr.status === 500) msg = 'خطای داخلی سرور';

        showError(msg);
    }

    function ajax(url, method = 'POST', options = {}) {
        const opts = $.extend(true, {
            method: method,
            data: {},
            form: null,
            button: null,
            loading: true,
            successAlert: false,
            successMessage: null,
            reloadTable: null
        }, options);

        const key = `${opts.method}:${url}`;
        if (activeRequests[key]) return;

        activeRequests[key] = true;

        if (opts.form) clearValidation(opts.form);
        if (opts.loading) showLoading();

        return $.ajax({
            url,
            type: opts.method,
            data: opts.data,
            processData: !isFormData(opts.data),
            contentType: isFormData(opts.data) ? false : undefined,
            headers: { 'X-CSRF-TOKEN': csrfToken() },
            success(res) {
                if (opts.successAlert) {
                    showSuccess(opts.successMessage || res.message);
                }
                if (opts.reloadTable) {
                    reloadDataTable(opts.reloadTable);
                }
                opts.success && opts.success(res);
            },
            error(xhr) {
                handleAjaxError(xhr, opts);
            },
            complete() {
                delete activeRequests[key];
                hideLoading();
            }
        });
    }

    /* =========================
     * Helpers
     * ========================= */

    function _post(url, data = {}, options = {}) {

        const token = document.querySelector('meta[name="csrf-token"]')?.content || '';

        const config = {
            url: url,
            type: (options.method || options.type || 'POST').toUpperCase(),
            data: data,
            headers: {
                'X-CSRF-TOKEN': token
            },
            ...options
        };

        // این‌ها را به options اصلی تحمیل نکنیم
        delete config.success;
        delete config.error;

        if (data instanceof FormData) {
            config.processData = false;
            config.contentType = false;
        }

        if (options.loading) showLooading();

        const xhr = $.ajax(config);

        xhr
            .done(function (res) {

                if (res?.success === false || res?.status === false) {

                    if (options.errorAlert !== false) {
                        AppAlert.showError(res.message || 'خطایی رخ داده است');
                    }

                    // در این حالت success callback را صدا نمی‌زنیم
                    return;
                }

                if (options.successAlert) {
                    AppAlert.showSuccess(res.message || 'عملیات با موفقیت انجام شد');
                }

                if (typeof options.success === 'function') {
                    options.success(res);
                }
            })
            .fail(function (err) {

                let message = 'خطایی رخ داده است';

                if (err.responseJSON?.message) {
                    message = err.responseJSON.message;
                } else if (err.responseJSON?.errors) {
                    const first = Object.values(err.responseJSON.errors)[0];
                    message = Array.isArray(first) ? first[0] : first;
                }

                if (options.errorAlert !== false) {
                    AppAlert.showError(message);
                }
            })
            .always(function () {
                if (options.loading) hideLooading();
            });

        return xhr;
    }
    function post(url, data = {}, options = {}) {
        const token = document.querySelector('meta[name="csrf-token"]')?.content || '';

        const config = {
            url: url,
            type: (options.method || options.type || 'POST').toUpperCase(),
            data: data,
            headers: {
                'X-CSRF-TOKEN': token
            },
            ...options
        };

        delete config.success;
        delete config.error;

        if (data instanceof FormData) {
            config.processData = false;
            config.contentType = false;
        }

        if (options.loading) showLooading();

        // ✅ برگرداندن Promise
        return new Promise((resolve, reject) => {
            $.ajax(config)
                .done(function (res) {
                    if (res?.success === false || res?.status === false) {
                        if (options.errorAlert !== false) {
                            AppAlert.showError(res.message || 'خطایی رخ داده است');
                        }
                        reject(new Error(res.message || 'خطا در عملیات'));
                        return;
                    }

                    if (options.successAlert !== false) {
                        AppAlert.showSuccess(res.message || 'عملیات با موفقیت انجام شد');
                    }

                    if (typeof options.success === 'function') {
                        options.success(res);
                    }
                    resolve(res);
                })
                .fail(function (err) {
                    let message = 'خطایی رخ داده است';

                    if (err.responseJSON?.message) {
                        message = err.responseJSON.message;
                    } else if (err.responseJSON?.errors) {
                        const first = Object.values(err.responseJSON.errors)[0];
                        message = Array.isArray(first) ? first[0] : first;
                    }

                    if (options.errorAlert !== false) {
                        AppAlert.showError(message);
                    }

                    if (typeof options.error === 'function') {
                        options.error(err);
                    }
                    reject(new Error(message));
                })
                .always(function () {
                    if (options.loading) hideLooading();
                });
        });
    }
    function del(url, options = {}) {
        const token = document.querySelector('meta[name="csrf-token"]').content

        const config = {
            url: url,
            type: (options.method || options.type || 'DELETE').toString().toUpperCase(),
            data: options.data || {},
            headers: {
                'X-CSRF-TOKEN': token
            },
            ...options
        }

        delete config.method

        return new Promise((resolve, reject) => {

            $.ajax(config)
                .done(res => {

                    if (res?.status === true || res?.success === true) {

                        if (res.message)
                            AppAlert.showSuccess(res.message)

                        resolve(res)
                        return
                    }

                    if (res?.status === false || res?.success === false) {

                        AppAlert.showError(res.message || 'خطایی رخ داده است')
                        resolve(null)
                        return
                    }

                    resolve(res)
                })
                .fail(err => {

                    let message = 'خطایی رخ داده است'

                    if (err.responseJSON?.message)
                        message = err.responseJSON.message

                    else if (err.responseJSON?.errors) {

                        const first = Object.values(err.responseJSON.errors)[0]
                        message = Array.isArray(first) ? first[0] : first
                    }

                    AppAlert.showError(message)

                    resolve(null)
                })

        })
    }


    async function confirmDelete(url, options = {}) {

        const res = await Swal.fire({
            title: `<div class="text-center">${options.title || 'حذف شود؟'}</div>`,
            text: options.text || 'این عملیات قابل بازگشت نیست',
            icon: 'warning',
            showCancelButton: true,
            confirmButtonText: 'بله',
            cancelButtonText: 'انصراف'
        })

        if (!res.isConfirmed) return null

        showLooading()

        try {
            return await del(url, options)
        } finally {
            hideLooading()
        }
    }


    // تایید عملیات عمومی
    function confirmAction(title, text, icon = 'question') {
        return Swal.fire({
            title: '<div class="text-center">' + title + '</div>',
            html: text,
            icon: icon,
            showCancelButton: true,
            confirmButtonText: 'بله',
            cancelButtonText: 'خیر'
        });
    }

    function ajaxForm(form, options = {}) {
        const $f = jq(form);
        if (!$f) return;

        $f.on('submit.appAlert', function (e) {
            e.preventDefault();
            const hasFile = $f.find('input[type=file]').length > 0;
            const data = hasFile ? new FormData(this) : $f.serialize();

            ajax($f.attr('action'), $.extend(options, {
                method: $f.attr('method') || 'POST',
                data,
                form: $f
            }));
        });
    }

    function reloadDataTable(table) {
        if ($.fn.DataTable && table instanceof $.fn.dataTable.Api) {
            table.ajax.reload();
        } else {
            const $t = jq(table);
            if ($t && $.fn.DataTable.isDataTable($t)) {
                $t.DataTable().ajax.reload();
            }
        }
    }


    /* ==============================
    * loading
    *================================ */
    window.showLooading = function () {

        const loader = document.getElementById('global-loading')

        if (loader)
            loader.style.display = 'flex'
    }

    window.hideLooading = function () {

        const loader = document.getElementById('global-loading')

        if (loader)
            loader.style.display = 'none'
    }


    /* =========================
    *  Set Route by Route name
    *  ========================= */
    // resources/js/custom/showalertProduction.js - اضافه کردن یکپارچگی
    window.route = function (name, params = {}) {
        // اولویت 1: LaravelRoutes (موجود)
        let url = window.LaravelRoutes?.[name];

        // اولویت 2: RouteManager (جدید)
        if (!url && window.RouteManager) {
            url = window.RouteManager.url(name, params);
        }

        if (!url) {
            console.error('Route not found:', name);
            return '#';
        }

        Object.keys(params).forEach(key => {
            url = url.replace(`{${key}}`, params[key]);
            url = url.replace(`:${key}`, params[key]);
        });

        return url;
    };

    // /* ========================================
    // * همگام‌سازی RouteManager با LaravelRoutes 
    // *  ========================================*/

    if (window.LaravelRoutes && window.RouteManager) {
        window.RouteManager.registerFromLaravel(window.LaravelRoutes);
    }

    /* =========================
     * Public API
     * ========================= */

    return {
        SwalBase,
        ToastBase,

        confirmAction,

        route,

        showToast,
        showSuccess,
        showWarning,
        showError,
        showLoading,
        hideLoading,
        showLooading,
        hideLooading,

        clearValidation,
        showValidationErrors,
        handleAjaxError,

        ajax,
        post,
        delete: del,
        confirmDelete,
        ajaxForm,
        reloadDataTable
    };

})(jQuery, Swal);

window.showSuccess = AppAlert.showSuccess;
window.showError = AppAlert.showError;
window.showToast = AppAlert.showToast;