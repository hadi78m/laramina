<!DOCTYPE html>
<html dir="rtl" lang="{{ str_replace('_', '-', app()->getLocale()) }}"
    x-data="{ darkMode: localStorage.getItem('darkMode') === 'true' }" x-bind:class="{ 'dark': darkMode }">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="{{ csrf_token() }}">

    <title>{{ config('app.name', 'Laravel') }}</title>

    <!-- Scripts -->
    <script src="{{ asset('js/jquery-3.7.1.min.js') }}"></script>
    <script src="{{ asset('js/jquery-sortable-min.js') }}"></script>

    @include('layouts.head')
    @vite(['resources/css/app.css'])
    @vite(['resources/js/app.js'])

</head>

<body class="bg-gray-100  dark:bg-gray-900 text-gray-900 dark:text-gray-100"
    x-data="{ mobileMenuOpen: false, darkMode: false }" :class="{ 'dark': darkMode }">
    {{-- دکمه تغییر حالت تاریک/روشن --}}
    {{-- <x-elements.darkLight /> --}}


    <!-- هدر صفحه با تصویر پس‌زمینه -->
    <x-elements.header />

    {{-- loading --}}
    <div id="global-loading"
        class="fixed inset-0 z-[9999] hidden items-center justify-center bg-white/70 backdrop-blur-sm">
        <div class="flex flex-col items-center gap-4">
            <div class="h-12 w-12 animate-spin rounded-full border-4 border-blue-500 border-t-transparent"></div>
            <span class="text-sm text-gray-600">در حال پردازش...</span>
        </div>
    </div>
    {{-- end loading --}}

    <!-- محتوای اصلی -->
    <div class="main-content">
        <div class="mx-auto p-4 bg-white py-6 ">
            @yield('content')

        </div>
    </div>



    @include('layouts.scripts')

    {{-- show alert and Ajax --}}
    <script src="{{asset('js/custom/showalertProduction.js')}}"></script>

    {{-- custom submit form --}}
    <script src="{{ asset('js/custom/ajaxRequest.js') }}"></script>



    {{-- AdminPlatformFull --}}

    @include('layouts.adminPlatform')


    @yield('scripts')



</body>

</html>