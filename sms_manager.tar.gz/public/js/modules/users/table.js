import { createForm, editForm } from './forms/create-form.js'
import { userActions } from './actions.js'

const publicLang = AdminLang.getNamespace('common');
const moduleFields = AdminLang.getNamespace('modules.users.fields');
const moduleActions = AdminLang.getNamespace('modules.users.actions');

export default {

    endpoint: 'manage.users.json',
    search: true,

    headerTitle: moduleFields.header_title || (publicLang.manage + ' ' + (moduleFields.title || 'کاربران')),
    addButtonLabel: moduleActions.create || (publicLang.create + ' ' + (moduleActions.item || publicLang.item)),
    displayButton: true,

    actions: userActions,

    perPage: 10,

    modalTheme: 'light',

    modals: {
        create: {
            title: moduleActions.create || publicLang.create,
            width: '500px',
            form: createForm,
            role:'SuperAdmin'
        },
        edit: {
            title: moduleActions.edit || publicLang.edit,
            width: '500px',
            form: editForm
        }
    },

    filters: [
        {
            key: 'is_active',
            label: publicLang.all_status,
            type: 'select',
            options: {
                1: publicLang.active,
                0: publicLang.inactive
            }
        },
    ],

    columns: [
        { key: 'id', label: publicLang.id, sortable: true },
        { key: 'name', label: publicLang.name, sortable: true },
        { key: 'email', label: publicLang.email },
        { key: 'created_at', label: publicLang.created_at, sortable: true },
        { key: 'roles', label: 'نقش', sortable: true },
        { key: 'permissions', label: 'دسترسی ها', sortable: true },
        {
            key: 'national_code', label: publicLang.national_code,
            // visible: row => row.has_token === 1,
            // فقط SuperAdmin ببیند

            role: ['SuperAdmin']
        },
        {
            key: 'is_active',
            label: publicLang.status,
            type: 'action-toggle',
            endpoint: 'manage.users.toggle-status',
            confirmTitle: publicLang.confirm_toggle_status || moduleActions.confirm_toggle_status,
            map: {
                true: { label: publicLang.active, color: 'green' },
                false: { label: publicLang.inactive, color: 'gray' }
            },
            icons: {
                true: { html: '<i class="fa-solid fa-toggle-on  text-lg"></i>', color: 'green' },
                false: { html: '<i class="fa-solid fa-toggle-off  text-lg"></i>', color: 'red' }
            }
        },
        {
            label: publicLang.actions,
            type: 'actions',
            actions: ['edit','delete']
        }
    ],
}