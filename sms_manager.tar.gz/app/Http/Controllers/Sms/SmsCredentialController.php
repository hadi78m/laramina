<?php

namespace App\Http\Controllers\Sms;

use App\Http\Controllers\Controller;
use App\Models\Sms\Credential;
use App\Rules\IpValidator;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;


class SmsCredentialController extends Controller
{
    /**
     * نمایش صفحه مدیریت اعتبارنامه‌ها
     */
    public function index()
    {
        return view('sms.credentials.index');
    }

    /**
     * دریافت لیست اعتبارنامه‌ها
     * @return \Illuminate\Http\JsonResponse
     */
    public function json(Request $request)
    {

        $credentials =  Credential::adminTable($request, [
            'search' => ['name', 'website'],
            'filters' => ['is_active'],
        ]);

        return     $credentials;
    }


    public function __json(Request $request)
    {
        $credentials = Credential::orderByDesc('id')->get();


        return response()->json([
            'success' => true,
            'data' => $credentials->map(function ($cred) {
                $activeTokens = $cred->tokens()->where('expires_at', '>', now())->count();
                $lastToken    = $cred->tokens()->latest()->first();

                // مقداردهی امن برای last_token_expires_at
                if ($lastToken && $lastToken->expires_at) {
                    $lastTokenExpiresAt = "<div dir='ltr' class='text-center'>"
                        . verta($lastToken->expires_at)->format('Y/m/d H:i')
                        . "</div>";
                } else {
                    $lastTokenExpiresAt = '';
                }

                return [
                    'id'                  => $cred->id,
                    'name'                => $cred->name,
                    'website'             => $cred->website,
                    'is_active'           => $cred->is_active,
                    'daily_limit'         => $cred->daily_limit,
                    'messages_sent_today' => $cred->messages()
                        ->whereDate('created_at', today())
                        ->count(),
                    'created_at'          => "<div dir='ltr' class='text-center'>"
                        . verta($cred->created_at)->format('Y/m/d H:i')
                        . "</div>",

                    'token_type'          => $lastToken
                        ? ($lastToken->name === 'static-token' ? '<span class="text-green-600 bg-gray-300 p-1 rounded-md"> استاتیک </span>' : '<span class="text-blue-600 bg-gray-300 p-1 rounded-md"> داینامیک </span>')
                        : '<span class="text-red-600 bg-gray-300 p-1 rounded-md"> نامشخص </span>',
                    'static_token_exists' => !empty($cred->static_token_plain),
                    'allowed_ip'          => $cred->allowed_ip ?? 'بدون محدودیت',

                    'active_tokens_count'   => $activeTokens,
                    'last_token_expires_at' => $lastTokenExpiresAt,
                    'token_status'          => $activeTokens > 0 ? '<span class="text-green-600 bg-green-300 p-1 rounded-md"> فعال </span>' : '<span class="text-red-600 bg-red-300 p-1 rounded-md"> منقضی یا ندارد </span>',
                ];
            })
        ]);
    }

    /**
     * ذخیره اعتبارنامه جدید
     */
    public function store(Request $request)
    {


        try {
            $validator = Validator::make($request->all(), [
                'name' => 'required|string|max:255',
                'website' => 'required|string|max:255|unique:sms_credentials,website|regex:/^(https?:\/\/)?(www\.)?[\w][\w.-]*\.[a-zA-Z]{2,}(\/.*)?$/i',
                'description' => 'nullable|string',
                'daily_limit' => 'nullable|integer|min:0|max:10000',
            ], [
                'name.required' => 'نام الزامی است',
                'name.max' => 'نام حداکثر 255 کاراکتر است',
                'website.required' => 'آدرس وب‌سایت الزامی است',
                'website.regex' => 'آدرس وب‌سایت نامعتبر است. مثال صحیح: example.com یا https://example.com',
                'website.max' => 'آدرس وب‌سایت حداکثر 255 کاراکتر است',
                'website.unique' => 'این آدرس وب‌سایت قبلاً استفاده شده است',
                'daily_limit.required' => 'محدودیت روزانه الزامی است',
            ]);

            if ($request->allowed_ip) {
                // بررسی اینکه آیا $value یک رشته است
                if (!is_string($request->allowed_ip)) {
                    return    $this->validationError('نوع ورودی نامعتبر است. باید یک رشته باشد.');
                }
                // استفاده از regex برای بررسی فرمت IP
                if (!preg_match('/^(([0-9]|[1-9][0-9]|1[0-9]{2}|2[0-4][0-9]|25[0-5])\.){3}([0-9]|[1-9][0-9]|1[0-9]{2}|2[0-4][0-9]|25[0-5])$/', $request->allowed_ip)) {
                    return    $this->validationError("فرمت IP نامعتبر است.");
                }

                // بررسی اینکه آیا IP در محدوده‌ی 0 تا 255 است
                $parts = explode('.', $request->allowed_ip);
                foreach ($parts as $part) {
                    if ($part !== '0') {
                        if (!filter_var($part, FILTER_VALIDATE_INT, ['options' => ['min_range' => 0, 'max_range' => 255]])) {

                            return    $this->validationError('هر قسمت IP باید یک عدد بین 0 تا 255 باشد.');
                        }
                    }
                }
            }
            if ($validator->fails()) {
                return response()->json([
                    'success' => false,
                    'message' => $validator->errors()->first(),
                    'errors' => $validator->errors(),
                ], 422);
            }
            DB::beginTransaction();

            $credential = Credential::create([
                'name' => $request->name,
                'website' => $request->website,
                // 'password' => Hash::make($request->password),
                'description' => $request->description,
                'daily_limit' => $request->daily_limit,
                'is_active' => true,
            ]);


            $this->createToken($credential->id);
            DB::commit();

            return response()->json([
                'success' => true,
                'message' => 'اعتبارنامه جدید با موفقیت ایجاد شد',
                'data' => [
                    'id' => $credential->id,
                    'name' => $credential->name,
                    'website' => $credential->website,
                ],
            ]);
        } catch (\Exception $e) {
            DB::rollBack();
            Log::error('خطا در ایجاد اعتبارنامه: ' . $e->getMessage());

            return response()->json([
                'success' => false,
                'message' => 'خطا در ایجاد اعتبارنامه: ' . $e->getMessage(),
            ], 500);
        }
    }

    public function edit($id)
    {
        $credentials = Credential::orderByDesc('id');

        if ($id) {
            $credentials = $credentials->where('id', $id)->get();
        } else {
            $credentials = $credentials->get();
        }

        return response()->json([
            'success' => true,
            'data' => $credentials->map(function ($cred) {
                $activeTokens = $cred->tokens()->where('expires_at', '>', now())->count();
                $lastToken    = $cred->tokens()->latest()->first();

                // مقداردهی امن برای last_token_expires_at
                if ($lastToken && $lastToken->expires_at) {
                    $lastTokenExpiresAt = "<div dir='ltr' class='text-center'>"
                        . verta($lastToken->expires_at)->format('Y/m/d H:i')
                        . "</div>";
                } else {
                    $lastTokenExpiresAt = '';
                }

                return [
                    'id'                  => $cred->id,
                    'name'                => $cred->name,
                    'website'             => $cred->website,
                    'is_active'           => $cred->is_active,
                    'daily_limit'         => $cred->daily_limit,
                    'messages_sent_today' => $cred->messages()
                        ->whereDate('created_at', today())
                        ->count(),
                    'created_at'          => "<div dir='ltr' class='text-center'>"
                        . verta($cred->created_at)->format('Y/m/d H:i')
                        . "</div>",

                    'token_type'          => $lastToken
                        ? ($lastToken->name === 'static-token' ? '<span class="text-green-600 bg-gray-300 p-1 rounded-md"> استاتیک </span>' : '<span class="text-blue-600 bg-gray-300 p-1 rounded-md"> داینامیک </span>')
                        : '<span class="text-red-600 bg-gray-300 p-1 rounded-md"> نامشخص </span>',
                    'static_token_exists' => !empty($cred->static_token_plain),
                    'allowed_ip'          => $cred->allowed_ip ?? 'بدون محدودیت',

                    'active_tokens_count'   => $activeTokens,
                    'last_token_expires_at' => $lastTokenExpiresAt,
                    'token_status'          => $activeTokens > 0 ? '<span class="text-green-600 bg-green-300 p-1 rounded-md"> فعال </span>' : '<span class="text-red-600 bg-red-300 p-1 rounded-md"> منقضی یا ندارد </span>',
                ];
            })
        ]);
    }
    /**
     * به‌روزرسانی اعتبارنامه
     */
    public function update(Request $request, $id)
    {
        try {
            $credential = Credential::findOrFail($id);

            $validator = Validator::make($request->all(), [
                'name' => 'required|string|max:255',
                'website' => 'required|string|max:255|unique:sms_credentials,website,' . $id . '|regex:/^(https?:\/\/)?(www\.)?[\w][\w.-]*\.[a-zA-Z]{2,}(\/.*)?$/i',
                'description' => 'nullable|string',
                'daily_limit' => 'nullable|integer|min:0|max:10000',
                'is_active' => 'required|boolean',
            ], [
                'name.required' => 'نام الزامی است',
                'name.max' => 'نام حداکثر 255 کاراکتر است',
                'website.required' => 'آدرس وب‌سایت الزامی است',
                'website.regex' => 'آدرس وب‌سایت نامعتبر است. مثال صحیح: example.com یا https://example.com',
                'website.max' => 'آدرس وب‌سایت حداکثر 255 کاراکتر است',
                'website.unique' => 'این آدرس وب‌سایت قبلاً استفاده شده است',
                'daily_limit.required' => 'محدودیت روزانه الزامی است',
                'is_active.required' => 'وضعیت الزامی است',
            ]);

            if ($validator->fails()) {
                return response()->json([
                    'success' => false,
                    'message' => $validator->errors()->first(),
                    'errors' => $validator->errors(),
                ], 422);
            }


            if ($request->allowed_ip) {
                // بررسی اینکه آیا $value یک رشته است
                if (!is_string($request->allowed_ip)) {
                    return    $this->validationError('نوع ورودی نامعتبر است. باید یک رشته باشد.');
                }
                // استفاده از regex برای بررسی فرمت IP
                if (!preg_match('/^(([0-9]|[1-9][0-9]|1[0-9]{2}|2[0-4][0-9]|25[0-5])\.){3}([0-9]|[1-9][0-9]|1[0-9]{2}|2[0-4][0-9]|25[0-5])$/', $request->allowed_ip)) {
                    return    $this->validationError("فرمت IP نامعتبر است.");
                }

                // بررسی اینکه آیا IP در محدوده‌ی 0 تا 255 است
                $parts = explode('.', $request->allowed_ip);
                foreach ($parts as $part) {
                    if ($part !== '0') {
                        if (!filter_var($part, FILTER_VALIDATE_INT, ['options' => ['min_range' => 0, 'max_range' => 255]])) {

                            return    $this->validationError('هر قسمت IP باید یک عدد بین 0 تا 255 باشد.');
                        }
                    }
                }
            }


            DB::beginTransaction();

            $updateData = [
                'name' => $request->name,
                'website' => $request->website,
                'description' => $request->description,
                'daily_limit' => $request->daily_limit,
                'is_active' => $request->is_active,
            ];

            // if ($request->filled('password')) {
            //     $updateData['password'] = Hash::make($request->password);
            // }

            $credential->update($updateData);

            DB::commit();

            return response()->json([
                'success' => true,
                'message' => 'اعتبارنامه با موفقیت به‌روزرسانی شد',
            ]);
        } catch (\Exception $e) {
            DB::rollBack();
            Log::error('خطا در به‌روزرسانی اعتبارنامه: ' . $e->getMessage());

            return response()->json([
                'success' => false,
                'message' => 'خطا در به‌روزرسانی اعتبارنامه',
            ], 500);
        }
    }

    /**
     * حذف اعتبارنامه
     */
    public function destroy($id)
    {
        try {
            $credential = Credential::findOrFail($id);

            DB::beginTransaction();

            $credential->delete();

            DB::commit();

            return response()->json([
                'success' => true,
                'message' => 'اعتبارنامه با موفقیت حذف شد',
            ]);
        } catch (\Exception $e) {
            DB::rollBack();
            Log::error('خطا در حذف اعتبارنامه: ' . $e->getMessage());

            return response()->json([
                'success' => false,
                'message' => 'خطا در حذف اعتبارنامه',
            ], 500);
        }
    }


    /**
     * تغییر وضعیت فعال/غیرفعال
     */
    public function toggleStatus($id)
    {
        try {
            $credential = Credential::findOrFail($id);
            $credential->is_active = !$credential->is_active;
            $credential->save();

            return response()->json([
                'success' => true,
                'message' => 'وضعیت با موفقیت تغییر کرد',
                'is_active' => $credential->is_active,
            ]);
        } catch (\Exception $e) {
            Log::error('خطا در تغییر وضعیت: ' . $e->getMessage());

            return response()->json([
                'success' => false,
                'message' => 'خطا در تغییر وضعیت',
            ], 500);
        }
    }

    /**
     * ایجاد توکن جدید با انقضای 1 ساله (static)
     */
    public function createToken($id)
    {
        $credential = Credential::findOrFail($id);

        // revoke قبلی‌ها
        $credential->tokens()->where('name', 'static-token')->delete();

        $expiration = now()->addYears(1);
        $newToken = $credential->createToken('static-token', ['*'], $expiration);

        // ذخیره plain text (رمزنگاری شده)
        $credential->static_token_plain = $newToken->plainTextToken;
        $credential->save();

        return response()->json([
            'success' => true,
            'token' => $newToken->plainTextToken, // فقط این بار برگردانده می‌شود
            'expires_at' => verta($expiration)->format('Y/m/d H:i'),
            'message' => 'توکن استاتیک ایجاد شد',
        ]);
    }
    /**
     * تمدید توکن موجود به 1 سال آینده
     */
    public function extendToken($id)
    {
        // try {
        $credential = Credential::findOrFail($id);
        $lastToken = $credential->tokens()->latest()->first();

        if (!$lastToken) {
            return response()->json(['success' => false, 'message' => 'توکنی وجود ندارد'], 400);
        }

        $newExpiration = now()->addYear();
        $lastToken->update(['expires_at' => $newExpiration]);

        // $request['id'] = $id;
        // $data = $this->findJson($id);

        return response()->json([
            'success' => true,
            'message' => 'توکن با موفقیت تمدید شد',
            'rowData' => [
                'id' => $id,
                'last_token_expires_at' => $lastToken->expires_at,
            ]
        ]);
    }

    /**
     * دریافت توکن استاتیک رمزنگاری‌شده برای نمایش موقت
     * فقط برای کاربر مجاز (ادمین یا صاحب اعتبارنامه)
     */
    public function getStaticToken($id)
    {
        $credential = Credential::findOrFail($id);

        // اختیاری: چک مجوز (مثلاً فقط ادمین یا خود credential)
        // if (!auth()->user()->can('view-sms-credentials') && auth()->user()->id !== $credential->user_id) {
        //     abort(403);
        // }

        if (!$credential->static_token_plain) {
            return response()->json([
                'success' => false,
                'message' => 'توکن استاتیک برای این اعتبارنامه وجود ندارد'
            ], 404);
        }

        $activeToken = Credential::findOrFail($id)->tokens()->latest()->first();

        // توکن decrypt شده برگردانده می‌شود (Laravel خودش decrypt می‌کند اگر cast تعریف شده باشد)
        return response()->json([
            'success' => true,
            'token'   => $credential->static_token_plain,
            'expires_at' => $activeToken->expires_at
                ? verta($activeToken->expires_at)->format('Y/m/d H:i')
                : 'نامشخص'
        ]);
    }


    /**
     * curlStaticToken
     *
     * @param  mixed $id
     * 
     */
    public function curlStaticToken($id)
    {
        $credential = Credential::findOrFail($id);

        // اختیاری: چک مجوز (مثلاً فقط ادمین یا خود credential)
        // if (!auth()->user()->can('view-sms-credentials') && auth()->user()->id !== $credential->user_id) {
        //     abort(403);
        // }

        if (!$credential->static_token_plain) {
            return response()->json([
                'success' => false,
                'message' => 'توکن استاتیک برای این اعتبارنامه وجود ندارد'
            ], 404);
        }

        $activeToken = Credential::findOrFail($id)->tokens()->latest()->first();

        // توکن decrypt شده برگردانده می‌شود (Laravel خودش decrypt می‌کند اگر cast تعریف شده باشد)
        return response()->json([
            'success' => true,
            'expires_at' => $activeToken->expires_at
                ? verta($activeToken->expires_at)->format('Y/m/d H:i')
                : 'نامشخص',
            'data' => "curl --request POST \\\n" .
                "  --url " . config('app.url') . "/api/v1/sms/sendOtp \\\n" .
                "  --header \"Accept: application/json\" \\\n" .
                "  --header \"Authorization: Bearer {$credential->static_token_plain}\" \\\n" .
                "  --header \"Content-Type: application/json\" \\\n" .
                "  --data '{\n" .
                "    \"recipient\": \"09********\",\n" .
                "    \"message\": \"0***\",\n" .
                "  }'",
        ]);
    }

    /**
     * validationError
     *
     * @param  mixed $message
     * 
     */
    private static function validationError($message)
    {

        return response()->json([
            "success" => false,
            "message" => $message,
        ], 422);
    }
}
