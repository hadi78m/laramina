<script>
    // تنظیم AJAX برای ارسال توکن CSRF
    $.ajaxSetup({
        headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        }
    });
    


    // تنظیمات پایه
    window.SwalBase = Swal.mixin({
        customClass: {
            popup: 'rtl text-center',
            title: 'text-center !important',
            htmlContainer: 'text-center',
            confirmButton: 'btn btn-primary mx-1',
            cancelButton: 'btn btn-secondary mx-1'
        },
        buttonsStyling: false,
        reverseButtons: true
    });


    const Toast = Swal.mixin({
        toast: true,
        position: 'top-end',
        showConfirmButton: false,
        timer: 3000,
        timerProgressBar: true,
        didOpen: (toast) => {
            toast.addEventListener('mouseenter', Swal.stopTimer)
            toast.addEventListener('mouseleave', Swal.resumeTimer)
        }
    });

    // toast  = بالا صفحه   برابر با showSuccess , showError 
    window.showToast = function (message, icon = 'success') {

        Toast.fire({
            icon: icon,
            title: '<div class="text-right">' + message + '</div>'
        });
    };

    // تایید عملیات عمومی
    window.confirmAction = function (title, text, callback) {
        Swal.fire({
            title: '<div class="text-center">' + title + '</div>',
            text: text,
            icon: 'question',
            showCancelButton: true,
            confirmButtonText: 'بله',
            cancelButtonText: 'خیر'
        }).then((result) => {
            if (result.isConfirmed) {
                callback();
            }
        });
    };



    // تایید حذف
    window.confirmDelete = function (callback) {
        Swal.fire({
            title: '<div class="text-center">حذف شود؟</div>',
            text: 'این عملیات قابل بازگشت نیست',
            icon: 'warning',
            showCancelButton: true,
            confirmButtonText: 'بله حذف کن',
            cancelButtonText: 'انصراف'
        }).then((result) => {
            if (result.isConfirmed) {
                callback();
            }
        });
    };

    //  برابر با showSystemSuccess
    // alert موفق
    window.showSuccess = function (message = 'عملیات با موفقیت انجام شد') {
        Swal.fire({
            icon: 'success',
            title: '<div class="text-center">موفق</div>',
            text: message,
            // timer: 2000,
            showConfirmButton: true,
            confirmButtonText: 'متوجه شدم',
        });
    };

    //  برابر با showSystemError , showError
    // alert خطا
    window.showError = function (message = 'خطایی رخ داد') {
        Swal.fire({
            icon: 'error',
            title: '<div class="text-center">خطا</div>',
            text: message,
            confirmButtonText: 'تلاش مجدد',
            footer: '<hr/><p class="text-sm mt-1 text-gray-500">در صورت تکرار خطا با پشتیبانی تماس بگیرید</p>'
        });
    };

</script>