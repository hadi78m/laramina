<script>

    const copyStaticTokenUrl = 'sms.credentials.get-static-token';
    const curlStaticTokenUrl = 'sms.credentials.curl-static-token';
    const createStaticTokenUrl = 'sms.credentials.create-token';
    const extendStaticTokenUrl = 'sms.credentials.extend-token';


    async function regenerateStaticToken(id) {
        createStaticToken(id); // همان منطق ایجاد مجدد
    }

    /* ایجاد توکن جدید */
    function createStaticToken(id) {
        Swal.fire({
            title: 'ایجاد توکن استاتیک',
            text: 'توکن قبلی (در صورت وجود) غیرفعال می‌شود. ادامه می‌دهید؟',
            icon: 'question',
            showCancelButton: true,
            confirmButtonText: 'بله، ایجاد کن',
            cancelButtonText: 'انصراف'
        }).then(result => {
            if (result.isConfirmed) {

                AppAlert.post(
                    AppAlert.route(createStaticTokenUrl, {
                        id: id,
                    }),
                    {},
                    {
                        loading: true,
                        errorAlert: true,
                        successAlert: false,
                        success: function (res) {
                            if (!res || !res.success) return;
                            if (res.success) {
                                showStaticToken(id, res.token, res.expires_at);
                                AppAlert.showSuccess(res.message);

                            } else {
                                AppAlert.showError(res.message);
                            }
                        },
                        error: function () {
                            AppAlert.showError(res.message);
                        }
                    }
                )
                    .always(function () {
                        // btn.prop('disabled', false);
                    });

            }
        });
    }
    /* باز کردن مودال توکن */
    function showStaticToken(id, token, expires) {
        $('#staticTokenText').val(token);
        $('#tokenExpiresInfo').text('انقضا: ' + expires);
        document.getElementById('showStaticTokenModal').classList.remove('hidden');
    }
    /* بستن مودال توکن */
    function closeStaticTokenModal() {
        document.getElementById('showStaticTokenModal').classList.add('hidden');
        $('#staticTokenText').val('');
    }

    /* تمدید تاریخ انقضای توکن */
    function extendToken(id) {
        AppAlert.post(
            AppAlert.route(extendStaticTokenUrl, {
                id: id,
            }),
            {},
            {
                loading: true,
                errorAlert: true,
                successAlert: false,
                success: function (response) {
                    if (response.success) {
                        AppAlert.showSuccess('توکن با موفقیت تمدید شد ، تاریخ انقضاء : ' + response.expires_at);

                        // بارگذاری جدول
                        document.dispatchEvent(new CustomEvent('admin:table:reload', {}));
                        // بارگذاری مجدد ردیف خاص
                        // document.dispatchEvent(new CustomEvent('admin:table:reload-row', {
                        //     detail: {
                        //         // tableId: 'users-table', // اختیاری
                        //         rowId: id // شناسه ردیف مورد نظر
                        //     }
                        // }))

                    }
                },
                error: function () {
                    AppAlert.showError('خطا در تمدید توکن');
                }
            }
        )
            .always(function () {
                // btn.prop('disabled', false);
            });
    }
    // تابع اصلی برای پیدا کردن جدول از طریق دکمه
    function findTableFromButton(id) {
        // ۱. پیدا کردن دکمه با data-id
        const button = document.querySelector(`button[data-id="${id}"]`);
        if (!button) return null;

        // ۲. حرکت به بالا در DOM تا پیدا کردن جدول
        let parent = button.parentElement;
        let tableElement = null;

        // حرکت به بالا تا پیدا کردن جدول
        while (parent && !tableElement) {
            if (parent.tagName === 'TABLE' ||
                parent.classList.contains('admin-table') ||
                parent.hasAttribute('data-table')) {
                tableElement = parent;
                break;
            }
            parent = parent.parentElement;
        }

        if (!tableElement) {
            // اگر جدول پیدا نشد، به body برسیم
            return null;
        }

        // ۳. پیدا کردن instance جدول
        return getTableInstance(tableElement);
    }

    // پیدا کردن instance جدول از element
    function getTableInstance(tableElement) {
        // روش‌های مختلف برای پیدا کردن instance

        // ۱. اگر Alpine.js استفاده می‌کند
        if (tableElement.__x) {
            return tableElement.__x.$data.table || tableElement.__x.$data;
        }

        // ۲. اگر Vue.js استفاده می‌کند
        if (tableElement.__vue__) {
            return tableElement.__vue__.table || tableElement.__vue__;
        }

        // ۳. اگر custom property دارد
        if (tableElement.table) {
            return tableElement.table;
        }

        // ۴. اگر data attribute دارد
        if (tableElement.dataset.tableInstance) {
            return window[tableElement.dataset.tableInstance];
        }

        // ۵. جستجو در parent ها برای Alpine/Vue
        let current = tableElement;
        while (current) {
            if (current.__x || current.__vue__) {
                const instance = current.__x ? current.__x.$data : current.__vue__;
                if (instance.table) return instance.table;
                return instance;
            }
            current = current.parentElement;
        }

        return null;
    }

    /* کپی توکن */
    function copyStaticToken(id) {
        const tokenField = document.getElementById('staticTokenText');
        const textToCopy = tokenField.value.trim();

        if (!textToCopy) {
            AppAlert.showWarning('هیچ متنی برای کپی وجود ندارد');
            return;
        }

        // چک امنیت و پشتیبانی مرورگر
        if (!navigator || !navigator.clipboard || typeof navigator.clipboard.writeText !== 'function') {
            fallbackCopy(textToCopy);
            return;
        }

        navigator.clipboard.writeText(textToCopy)
            .then(() => {
                AppAlert.showToast('success', 'توکن در کلیپ‌بورد قرار گرفت');
            })
            .catch(err => {
                console.error('Clipboard API error:', err);
                fallbackCopy(textToCopy);
            });
    }

    // روش fallback قدیمی (برای مرورگرهای قدیمی یا http)
    function fallbackCopy(text) {
        const textArea = document.createElement('textarea');
        textArea.value = text;
        textArea.style.position = 'fixed';
        textArea.style.opacity = '0';
        document.body.appendChild(textArea);
        textArea.focus();
        textArea.select();

        try {
            const successful = document.execCommand('copy');
            if (successful) {
                AppAlert.showToast('success', 'توکن در کلیپ‌بورد قرار گرفت');

            } else {
                AppAlert.showToast('error', 'کپی خودکار انجام نشد - لطفاً دستی انتخاب و کپی کنید');
                // AppAlert.showError('کپی خودکار انجام نشد - لطفاً دستی انتخاب و کپی کنید');
            }
        } catch (err) {
            AppAlert.showError('کپی انجام نشد');
        }

        document.body.removeChild(textArea);
    }


    /* دریافت آخرین توکن جهت کپی کاربر */
    function fetchStaticToken(id) {

        AppAlert.post(
            AppAlert.route(copyStaticTokenUrl, {
                id: id,
            }),
            {},
            {
                method: 'GET',
                loading: true,
                errorAlert: true,
                successAlert: false,
                success: function (res) {
                    if (res.success) {
                        $('#staticTokenText').val(res.token);
                        $('#tokenExpiresInfo').text('انقضا: ' + res.expires_at);
                        $('#modalHeader').text('توکن استاتیک');
                        document.getElementById('showStaticTokenModal').classList.remove('hidden');
                    } else {
                        showError(response.message || 'توکن یافت نشد');
                    }
                },
                error: function (xhr) {
                    let msg = 'خطا در دریافت توکن';
                    if (xhr.status === 403) msg = 'دسترسی مجاز نیست';
                    if (xhr.status === 404) msg = 'توکن استاتیک وجود ندارد';
                    showError(res.message || 'توکن یافت نشد');
                }
            }
        )
            .always(function () {
                // btn.prop('disabled', false);
            });
    }

    function fetchCurlStaticToken(id) {

        AppAlert.post(
            AppAlert.route(curlStaticTokenUrl, {
                id: id,
            }),
            {},
            {
                method: 'POST',
                loading: true,
                errorAlert: true,
                successAlert: false,
                success: function (res) {
                    if (res.success) {
                        $('#staticTokenText').val(res.data);
                        $('#tokenExpiresInfo').text('انقضا: ' + res.expires_at);
                        $('#modalHeader').text('کرل توکن استاتیک');
                        document.getElementById('showStaticTokenModal').classList.remove('hidden');
                    } else {
                        showError(response.message || 'توکن یافت نشد');
                    }
                },
                error: function (xhr) {
                    let msg = 'خطا در دریافت توکن';
                    if (xhr.status === 403) msg = 'دسترسی مجاز نیست';
                    if (xhr.status === 404) msg = 'توکن استاتیک وجود ندارد';
                    showError(res.message || 'توکن یافت نشد');
                }
            }
        )
            .always(function () {
                // btn.prop('disabled', false);
            });
    }



    async function reloadRow(id) {

        // const res = await fetch(/row/${ id });

        // const html = await res.text();

        // document.querySelector(#row - ${ id }).outerHTML = html;

    }
</script>