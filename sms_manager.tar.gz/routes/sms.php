<?php

use App\Http\Controllers\DashbordController;
use App\Http\Controllers\Sms\SmsCredentialController;
use App\Http\Controllers\Sms\SmsSocialController;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Sms\SmsBlockedWordController;
use App\Http\Controllers\Sms\SmsProviderController;
use App\Http\Controllers\Sms\SmsMessageController;
use Spatie\Permission\Middleware\RoleMiddleware;

// SMS Management Routes
Route::middleware(['auth'])
    ->prefix('sms')->name('sms.')->group(function () {
        // Credentials Routes
        Route::middleware([ADMINS_ROLES])->prefix('credentials')->name('credentials.')->group(function () {
                Route::get('/', [SmsCredentialController::class, 'index'])->name('index');
                Route::get('/json', [SmsCredentialController::class, 'json'])->name('json');
                Route::post('/', [SmsCredentialController::class, 'store'])->name('store');
                Route::get('/{id}/edit', [SmsCredentialController::class, 'edit'])->name('edit');
                Route::put('/{id}', [SmsCredentialController::class, 'update'])->name('update');
                Route::delete('/{id}', [SmsCredentialController::class, 'destroy'])->name('destroy');
                Route::post('/{id}/toggle-status', [SmsCredentialController::class, 'toggleStatus'])->name('toggle-status');
                Route::post('/{id}/create-token', [SmsCredentialController::class, 'createToken'])->name('create-token');
                Route::post('/{id}/extend-token', [SmsCredentialController::class, 'extendToken'])->name('extend-token');
                Route::get('/{id}/get-static-token', [SmsCredentialController::class, 'getStaticToken'])
                    ->name('get-static-token');
                Route::post('/{id}/curl-static-token', [SmsCredentialController::class, 'curlStaticToken'])
                    ->name('curl-static-token');
            });
        // Blocked Words Routes
        Route::prefix('blocked-words')->name('blocked-words.')->middleware([ADMINS_ROLES])->group(function () {
                Route::get('/', [SmsBlockedWordController::class, 'index'])->name('index');
                Route::get('/json', [SmsBlockedWordController::class, 'getWords'])->name('json');
                Route::post('/', [SmsBlockedWordController::class, 'store'])->name('store');
                Route::put('/{id}', [SmsBlockedWordController::class, 'update'])->name('update');
                Route::delete('/{id}', [SmsBlockedWordController::class, 'destroy'])->name('destroy');
                Route::post('/{id}/toggle-status', [SmsBlockedWordController::class, 'toggleStatus'])->name('toggle-status');
                Route::post('/check-text', [SmsBlockedWordController::class, 'checkText'])->name('check-text');
            });
        // Messages Routes
        Route::prefix('messages')->name('messages.')->middleware([ADMINS_ROLES])->group(function () {
            Route::get('/', [SmsMessageController::class, 'index'])->name('index');
            Route::get('/json', [SmsMessageController::class, 'getMessages'])->name('json');
            Route::get('/stats', [SmsMessageController::class, 'getStats'])->name('stats');
            Route::post('/bulk', [SmsMessageController::class, 'sendBulk'])->name('bulk');
        });
        // روت مرتبط با پروایدرها
        Route::prefix('providers')->name('providers.')->middleware([SuperAdmin_ROLE])->group(function () {
            Route::get('/', [SmsProviderController::class, 'index'])
                ->name('index');
            Route::get('/json', [SmsProviderController::class, 'json'])
                ->name('json');
            Route::post('/store', [SmsProviderController::class, 'store'])
                ->name('store');
            Route::get('/{id}/edit', [SmsProviderController::class, 'edit'])
                ->name('edit');
            Route::put('/update/{id}', [SmsProviderController::class, 'update'])
                ->name('update');
            Route::delete('/{id}', [SmsProviderController::class, 'destroy'])
                ->name('destroy');
            Route::post('/{id}/set-default', [SmsProviderController::class, 'setDefault'])
                ->name('set-default');
            Route::post('/{id}/toggle-status', [SmsProviderController::class, 'toggleStatus'])
                ->name('toggle-status');

            // تست اتصال از طریق API
            Route::post('/{id}/test-connection', [SmsProviderController::class, 'testConnection'])
                ->name('test-connection');
            Route::post('/{id}/createHelper', [SmsProviderController::class, 'createHelper'])
                ->name('create-helper');


            // روت های مودال
            Route::get('{provider}/numbers', [SmsProviderController::class, 'numbers'])->name('numbers');
            Route::post('{provider}/numbers', [SmsProviderController::class, 'storeNumber'])->name('numbers.store');
            Route::post('{provider}/numbers/{number}/toggle', [SmsProviderController::class, 'toggleNumberStatus'])->name('numbers.toggle');
            Route::delete('{provider}/numbers/{number}', [SmsProviderController::class, 'destroyNumber'])->name('numbers.destroy');
        });
        // روت های مرتبط با پیام رسان ها
        Route::prefix('socials')->name('socials.')->middleware([SuperAdmin_ROLE])->group(function () {
            Route::get('/', [SmsSocialController::class, 'index'])
                ->name('index');
            Route::get('/json', [SmsSocialController::class, 'json'])
                ->name('json');
            Route::post('/', [SmsSocialController::class, 'store'])
                ->name('store');
            Route::get('/{id}/edit', [SmsSocialController::class, 'edit'])
                ->name('edit');
            Route::put('/{id}', [SmsSocialController::class, 'update'])
                ->name('update');
            Route::delete('/{id}', [SmsSocialController::class, 'destroy'])
                ->name('destroy');
            Route::post('/{id}/set-default', [SmsSocialController::class, 'setDefault'])
                ->name('set-default');
            Route::post('/{id}/toggle-status', [SmsSocialController::class, 'toggleStatus'])
                ->name('toggle-status');
        });
    });


// لیست شماره های پروایدرها
// Route::group(['prefix' => 'sms/providers'], function () {
//     // ... روت‌های قبلی ...

// });

// Route::group(['prefix' => 'sms/social'], function () {
//     // ... روت‌های قبلی ...
//     Route::get('{provider}/numbers', [SmsProviderController::class, 'numbers'])->name('numbers');
//     Route::post('{provider}/numbers', [SmsProviderController::class, 'storeNumber'])->name('numbers.store');
//     Route::post('{provider}/numbers/{number}/toggle', [SmsProviderController::class, 'toggleNumberStatus'])->name('numbers.toggle');
//     Route::delete('{provider}/numbers/{number}', [SmsProviderController::class, 'destroyNumber'])->name('numbers.destroy');
// });

// Dashboard Routes
Route::prefix('dashboard')->name('dashboard.')->middleware(['auth'])->group(function () {
    Route::get('/', [DashbordController::class, 'index'])->name('index');
    Route::get('/stats', [DashbordController::class, 'getDashboardStats'])->name('stats');
});
