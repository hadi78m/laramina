<div class="overflow-x-auto p-2">
    <table
        {{ $attributes->class(['table table-striped   display dt-responsive text-right rtl border bg-white border-gray-300 table-auto'])->merge(['id' => '']) }}>
        @isset($thead)
            <thead {{ $thead->attributes->class(['bg-gray-200']) }}>
                {{ $thead }}
            </thead>
        @endisset
        @isset($tbody)
            {{ $tbody }}
        @endisset
        @isset($tfoot)
            <tfoot {{ $tfoot->attributes->class(['bg-gray-200']) }}> {{ $tfoot }} </tfoot>
        @endisset
    </table>
</div>
