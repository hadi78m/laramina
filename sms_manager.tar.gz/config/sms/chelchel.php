<?php

use Ramsey\Uuid\Uuid;

$username = 'samanemali_rsb';
$password = 'S$$@maneM@li**65';
$uuid = Uuid::uuid4();
$uuid = $uuid->toString();
return [
    "url" => "this",
    'Authorization'         => "Basic " . base64_encode("$username:$password"),
    'active' => '1', // ارسال 1 غیر فعال 0
];
