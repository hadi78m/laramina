const publicLang = AdminLang.getNamespace('common');
const moduleFields = AdminLang.getNamespace('modules.credentials.fields');
const moduleActions = AdminLang.getNamespace('modules.credentials.actions');

export const createForm = {

    endpoint: 'sms.credentials.store',
    updateEndpoint: 'sms.credentials.update',
    deleteEndpoint: 'sms.credentials.destroy',

    title: moduleActions.create || publicLang.create,

    fields: [
        {
            name: 'name',
            label: publicLang.name,
            type: 'text',
            placeholder: 'نام نمایشی اعتبارنامه',
            helper: 'نامی برای شناسایی این Credential در پنل'
        },
        {
            name: 'website',
            label: publicLang.website,
            type: 'text',
            placeholder: 'https://example.com',
            helper: 'آدرس کامل وب‌سایت شامل http:// یا https://',
            required: true
        },
        {
            name: 'daily_limit',
            label: publicLang.daily_limit || moduleFields.daily_limit,
            type: 'number',
            placeholder: 'مثال: 1000',
            helper: 'حداکثر تعداد پیامک قابل ارسال در روز. 0 یا خالی = نامحدود'
        },
        {
            name: 'allowed_ip',
            label: publicLang.allowed_ip || moduleFields.allowed_ip,
            type: 'text',
            placeholder: 'مثال: 192.168.1.1',
            helper: 'محدودیت استفاده از توکن فقط با این IP. خالی = بدون محدودیت',
            autocomplete: 'off'
        },
        {
            name: 'description',
            label: publicLang.description || moduleFields.description,
            type: 'textarea',
            placeholder: 'توضیحات اختیاری درباره این Credential'
        },
        {
            name: 'is_active',
            label: publicLang.status + ' ' + (publicLang.is_active || moduleFields.is_active),
            type: 'select',
            options: [
                { value: 1, label: 'فعال' },
                { value: 0, label: 'غیرفعال' }
            ],
            required: true,
            helper: 'در صورت غیرفعال بودن، امکان ارسال پیامک وجود ندارد'
        },
    ],

    buttons: {
        submit: publicLang.save,
        cancel: publicLang.cancel,
    }
};