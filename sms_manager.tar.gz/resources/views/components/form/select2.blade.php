<div class="">
  <div {{$attributes->class(['mb-3 xl:w-full rounded h-20'])}}>
    @isset($label)
        {{$label}}
    @endisset
    @isset($select)
        
    <select {{$select->attributes->class(['mt-2 form-select appearance-none block w-full px-3 py-1.5 text-base font-normal text-gray-700 bg-white bg-clip-padding bg-no-repeat border border-solid border-gray-300 rounded transition ease-in-out m-0
      focus:text-gray-700 focus:bg-white focus:border-blue-600 focus:outline-none'])}} aria-label="Default select example">
        <option selected></option>
        @isset($options)
        {{$options}}
        @endisset
      </select>
      @endisset
  </div>
</div>