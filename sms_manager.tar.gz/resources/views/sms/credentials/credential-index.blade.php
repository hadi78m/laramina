@extends('layouts.mclsApp')

@section('content')
    <x-elements.sidebar>
        <x-sidebars.sms />
    </x-elements.sidebar>

    <div class="container mx-auto px-4 py-8">
        <div class="bg-white rounded-lg shadow-lg overflow-hidden">
            <!-- Header -->
            <div class="bg-gradient-to-r from-blue-600 to-blue-800 text-white px-6 py-4 flex justify-between items-center">
                <h3 class="text-xl font-bold">مدیریت اعتبارنامه‌های پیامکی</h3>
                <button onclick="openAddModal()"
                    class="bg-white text-blue-600 px-4 py-2 rounded-lg hover:bg-blue-50 transition-all duration-200 flex items-center gap-2 font-semibold">
                    <i class="fas fa-plus"></i>
                    افزودن اعتبارنامه جدید
                </button>
            </div>

            <!-- Body -->
            <div class="p-6">
                <div class="overflow-x-auto">
                    <table id="credentialsTable" class="w-full text-center">
                        <thead> 
                            <tr class="bg-gray-50">
                                <th class="px-4 py-3 text-right text-sm font-semibold text-gray-700">شناسه</th>
                                <th class="px-4 py-3 text-right text-sm font-semibold text-gray-700">نام</th>
                                <th class="px-4 py-3 text-right text-sm font-semibold text-gray-700">نام یا آدرس سامانه</th>
                                <th class="px-4 py-3 text-right text-sm font-semibold text-gray-700">وضعیت توکن</th>
                                <th class="px-4 py-3 text-right text-sm font-semibold text-gray-700">نوع توکن</th>
                                <th class="px-4 py-3 text-right text-sm font-semibold text-gray-700">توکن استاتیک</th>
                                <th class="px-4 py-3 text-right text-sm font-semibold text-gray-700">IP مجاز</th>
                                <th class="px-4 py-3 text-right text-sm font-semibold text-gray-700">انقضای آخرین توکن</th>
                                <th class="px-4 py-3 text-right text-sm font-semibold text-gray-700">وضعیت</th>
                                <th class="px-4 py-3 text-right text-sm font-semibold text-gray-700">محدودیت روزانه</th>
                                <th class="px-4 py-3 text-right text-sm font-semibold text-gray-700">ارسال امروز</th>
                                <th class="px-4 py-3 text-right text-sm font-semibold text-gray-700">عملیات</th>
                            </tr>
                        </thead>
                        <tbody dir="" class="text-center"></tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <!-- Modal افزودن اعتبارنامه -->
    <div id="addCredentialModal"
        class="hidden fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center p-4">
        <div class="bg-white rounded-xl shadow-2xl w-full max-w-md transform transition-all">
            <div
                class="bg-gradient-to-r from-cyan-600 to-blue-600 text-white px-6 py-4 rounded-t-xl flex justify-between items-center">
                <h5 class="text-lg font-bold">افزودن اعتبارنامه جدید</h5>
                <button onclick="closeAddModal()" class="text-white hover:text-gray-200 transition-colors">
                    <i class="fas fa-times text-xl"></i>
                </button>
            </div>

            <form id="addCredentialForm" class="p-6">
                <div class="space-y-4">
                    <div>
                        <label class="block text-sm font-semibold text-gray-700 mb-2">
                            نام <span class="text-red-500">*</span>
                        </label>
                        <input type="text" name="name" required
                            class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all"
                            placeholder="نام سرویس یا مشتری">
                        <div class="text-red-500 text-sm mt-1 hidden error-name"></div>
                    </div>

                    <div>
                        <label class="block text-sm font-semibold text-gray-700 mb-2">
                            نام یا آدرس سامانه <span class="text-red-500">*</span>
                        </label>
                        <input type="text" name="website" required
                            class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all"
                            placeholder="نام سامانه یا آدرس سامانه">
                        <div class="text-red-500 text-sm mt-1 hidden error-website"></div>
                    </div>

                    {{-- <div>
                        <label class="block text-sm font-semibold text-gray-700 mb-2">
                            رمز عبور <span class="text-red-500">*</span>
                        </label>
                        <input type="password" name="password" required
                            class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all"
                            placeholder="رمز عبور">
                        <div class="text-red-500 text-sm mt-1 hidden error-password"></div>
                    </div> --}}

                    <div>
                        <label class="block text-sm font-semibold text-gray-700 mb-2">
                            محدودیت روزانه
                        </label>
                        <input type="number" name="daily_limit"
                            class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all"
                            placeholder="تعداد پیام (پیش‌فرض: نامحدود)">
                        <div class="text-gray-500 text-xs mt-1">برای نامحدود خالی بگذارید</div>
                    </div>
                    <div class="mt-4">
                        <label for="allowed_ip" class="block text-sm font-medium text-gray-700">
                            IP مجاز (اختیاری - برای محدودیت دسترسی)
                        </label>
                        <input type="text" name="allowed_ip" id="allowed_ip"
                            class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm"
                            placeholder="مثال: 185.55.123.45 یا خالی بگذارید">
                        <p class="mt-1 text-xs text-gray-500">اگر پر شود، فقط از این IP اجازه استفاده از توکن وجود دارد
                        <div class="text-red-500 text-sm mt-1 hidden error-allowed_ip"></div>
                        </p>
                    </div>

                    <div>
                        <label class="block text-sm font-semibold text-gray-700 mb-2">
                            توضیحات
                        </label>
                        <textarea name="description" rows="3"
                            class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all"
                            placeholder="توضیحات اختیاری..."></textarea>
                    </div>
                </div>


                <div class="flex gap-3 mt-6">
                    <button type="button" onclick="closeAddModal()"
                        class="flex-1 px-4 py-2 bg-gray-200 text-gray-700 rounded-lg hover:bg-gray-300 transition-colors font-semibold">
                        انصراف
                    </button>
                    <button type="submit"
                        class="flex-1 px-4 py-2 bg-gradient-to-r from-cyan-600 to-blue-600 text-white rounded-lg hover:from-cyan-700 hover:to-blue-700 transition-all font-semibold">
                        ذخیره
                    </button>
                </div>
            </form>
        </div>
    </div>
    <!-- Modal ویرایش اعتبارنامه -->
    <div id="editCredentialModal"
        class="hidden fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center p-4">
        <div class="bg-white rounded-xl shadow-2xl w-full max-w-md transform transition-all">
            <div
                class="bg-gradient-to-r from-green-600 to-emerald-600 text-white px-6 py-4 rounded-t-xl flex justify-between items-center">
                <h5 class="text-lg font-bold">ویرایش اعتبارنامه</h5>
                <button onclick="closeEditModal()" class="text-white hover:text-gray-200 transition-colors">
                    <i class="fas fa-times text-xl"></i>
                </button>
            </div>

            <form id="editCredentialForm" class="p-6">
                <input type="hidden" name="credential_id" id="edit_credential_id">

                <div class="space-y-4">
                    <div>
                        <label class="block text-sm font-semibold text-gray-700 mb-2">
                            نام <span class="text-red-500">*</span>
                        </label>
                        <input type="text" name="name" id="edit_name" required
                            class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent transition-all">
                    </div>
                    <div>
                        <label class="block text-sm font-semibold text-gray-700 mb-2">
                            نام یا آدرس سامانه <span class="text-red-500">*</span>
                        </label>
                        <input type="text" name="website" id="edit_website" required
                            class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent transition-all">
                    </div>

                    {{-- <div>
                        <label class="block text-sm font-semibold text-gray-700 mb-2">
                            رمز عبور جدید
                        </label>
                        <input type="password" name="password" id="edit_password"
                            class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent transition-all"
                            placeholder="برای تغییر رمز عبور پر کنید">
                        <div class="text-gray-500 text-xs mt-1">خالی بگذارید اگر نمی‌خواهید تغییر کند</div>
                    </div> --}}

                    <div>
                        <label class="block text-sm font-semibold text-gray-700 mb-2">
                            محدودیت روزانه
                        </label>
                        <input type="number" name="daily_limit" id="edit_daily_limit"
                            class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent transition-all">
                    </div>
                    <div class="mt-4">
                        <label for="edit_allowed_ip" class="block text-sm font-medium text-gray-700">
                            IP مجاز (اختیاری - برای محدودیت دسترسی)
                        </label>
                        <input type="text" name="allowed_ip" id="edit_allowed_ip"
                            class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm"
                            placeholder="مثال: 185.55.123.45 یا خالی بگذارید">
                        <p class="mt-1 text-xs text-gray-500">
                            اگر پر شود، فقط از این IP اجازه استفاده از توکن وجود دارد
                        </p>
                    </div>
                    <div>
                        <label class="block text-sm font-semibold text-gray-700 mb-2">
                            توضیحات
                        </label>
                        <textarea name="description" id="edit_description" rows="3"
                            class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent transition-all"></textarea>
                    </div>

                    <div>
                        <label class="block text-sm font-semibold text-gray-700 mb-2">
                            وضعیت
                        </label>
                        <select name="is_active" id="edit_is_active"
                            class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent transition-all">
                            <option value="1">فعال</option>
                            <option value="0">غیرفعال</option>
                        </select>
                    </div>
                </div>

                <div class="flex gap-3 mt-6">
                    <button type="button" onclick="closeEditModal()"
                        class="flex-1 px-4 py-2 bg-gray-200 text-gray-700 rounded-lg hover:bg-gray-300 transition-colors font-semibold">
                        انصراف
                    </button>
                    <button type="submit"
                        class="flex-1 px-4 py-2 bg-gradient-to-r from-green-600 to-emerald-600 text-white rounded-lg hover:from-green-700 hover:to-emerald-700 transition-all font-semibold">
                        به‌روزرسانی
                    </button>
                </div>
            </form>
        </div>
    </div>

    <!-- Modal نمایش / کپی توکن استاتیک -->
    <div id="showStaticTokenModal"
        class="hidden fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center p-4">
        <div class="bg-white rounded-xl shadow-2xl w-full max-w-lg transform transition-all">
            <div
                class="bg-gradient-to-r from-purple-600 to-indigo-600 text-white px-6 py-4 rounded-t-xl flex justify-between items-center">
                <h5 class="text-lg font-bold">توکن استاتیک</h5>
                <button onclick="closeStaticTokenModal()" class="text-white hover:text-gray-200">
                    <i class="fas fa-times text-xl"></i>
                </button>
            </div>
            <div class="p-6">
                <p class="text-sm text-gray-600 mb-4">این توکن بلندمدت است. آن را در جای امن نگه دارید.</p>
                <div class="relative">
                    <textarea id="staticTokenText" readonly
                        class="w-full px-4 py-3 border border-gray-300 rounded-lg bg-gray-50 font-mono text-sm resize-none"
                        rows="3"></textarea>

                </div>
                <p id="tokenExpiresInfo" class="mt-3 text-sm text-gray-600"></p>
                <div class="mt-6 flex gap-3">
                    <button onclick="copyStaticToken()"
                        class="flex-1 px-4 py-2 bg-blue-600 text-white text-xs rounded hover:bg-blue-700">
                        کپی
                    </button>
                    <button onclick="closeStaticTokenModal()"
                        class="flex-1 px-4 py-2 bg-red-200 text-gray-700 rounded-lg hover:bg-gray-300">
                        بستن
                    </button>
                </div>
            </div>
        </div>
    </div>
    <!-- Modal نشان دادن توکن -->
    <div id="showTokenModal" class="hidden fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center p-4">
        <div class="bg-white rounded-xl shadow-2xl w-full max-w-md transform transition-all">
            <div
                class="bg-gradient-to-r from-purple-600 to-indigo-600 text-white px-6 py-4 rounded-t-xl flex justify-between items-center">
                <h5 class="text-lg font-bold">توکن جدید</h5>
                <button onclick="closeTokenModal()" class="text-white hover:text-gray-200 transition-colors">
                    <i class="fas fa-times text-xl"></i>
                </button>
            </div>
            <div class="p-6">
                <p class="text-sm text-gray-600 mb-4">توکن جدید ایجاد شد. آن را کپی کنید و در جای امن نگه دارید.</p>
                <textarea id="tokenText" readonly
                    class="w-full px-4 py-2 border border-gray-300 rounded-lg bg-gray-50 font-mono text-sm"
                    rows="3"></textarea>
                <div class="flex gap-3 mt-4">
                    <button onclick="copyTokenFromModal()"
                        class="flex-1 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-all font-semibold">
                        کپی توکن
                    </button>
                    <button onclick="closeTokenModal()"
                        class="flex-1 px-4 py-2 bg-gray-200 text-gray-700 rounded-lg hover:bg-gray-300 transition-colors font-semibold">
                        بستن
                    </button>
                </div>
            </div>
        </div>
    </div>
@endsection
@section('scripts')
    @include('sms.credentials.script.credential-script')
@endsection