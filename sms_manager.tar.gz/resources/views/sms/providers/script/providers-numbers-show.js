// فرض: jQuery و showalertProduction.js (AppAlert) لود شده

$(document).on('click', '#btn-show-numbers', function () {
    const providerId = $(this).data('provider-id') || $('#provider-id').val();

    $('#numbers-list-loading').show();
    $('#numbers-list-container').html('');

    $.ajax({
        url: `/sms/providers/${providerId}/numbers`,
        method: 'GET',
        success: function (html) {
            $('#numbers-list-loading').hide();
            $('#numbers-list-container').html(html);
            $('#numbersModal').modal('show'); // اگر Bootstrap 5: new bootstrap.Modal(...)
        },
        error: function (xhr) {
            $('#numbers-list-loading').hide();
            AppAlert.error('خطایی در دریافت لیست شماره‌ها رخ داد.');
        }
    });
});

$(document).on('click', '.btn-delete-number', function () {
    const id = $(this).data('id');

    AppAlert.confirm('حذف شماره', 'آیا از حذف این شماره مطمئن هستید؟', function () {
        $.ajax({
            url: `/providers/numbers/${id}`,
            method: 'DELETE',
            data: {
                _token: $('meta[name="csrf-token"]').attr('content')
            },
            success: function () {
                // رفرش ساده لیست:
                $('#btn-show-numbers').trigger('click');
                AppAlert.success('شماره با موفقیت حذف شد.');
            },
            error: function () {
                AppAlert.error('خطا در حذف شماره.');
            }
        });
    });
});
