@extends('layouts.mclsApp')

@section('content')
    <x-elements.sidebar>
        <x-sidebars.sms />
    </x-elements.sidebar>
    <style>


        .icon-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(160px, 1fr));
            gap: 1rem;
        }

        @media (max-width: 768px) {
            .icon-grid {
                grid-template-columns: repeat(auto-fill, minmax(130px, 1fr));
                gap: 0.75rem;
            }
        }

        @media (max-width: 640px) {
            .icon-grid {
                grid-template-columns: repeat(auto-fill, minmax(110px, 1fr));
                gap: 0.5rem;
            }
        }

        /* استایل برای هایلایت جستجو */
        .highlight {
            background-color: #fef3c7;
            padding: 0 2px;
            border-radius: 2px;
        }

        /* انیمیشن برای آیکون‌ها */
        .icon-item {
            transition: all 0.2s ease-in-out;
        }

        .icon-item:hover {
            transform: translateY(-2px);
        }


    </style>
    <div class="bg-gray-50 min-h-screen" dir="rtl">
        <div x-data="iconManager()" x-init="init()" class="container mx-auto px-4 py-8">
            <!-- هدر اصلی -->
            <header class="mb-8">
                {{-- <h1 class="text-3xl font-bold text-gray-800 mb-2 flex items-center gap-2"> --}}
                    <i class="fas fa-icons text-blue-500"></i>
                    کتابخانه آیکون‌های Font Awesome
                {{-- </h1> --}}
                <p class="text-gray-600 mb-6">
                    مدیریت و نمایش همه آیکون‌های موجود در کتابخانه Font Awesome
                </p>

                <!-- کارت اطلاعات -->
                <div class="grid  grid-cols-2 md:grid-cols-4 gap-4 mb-6">
                    <div class="bg-white rounded-lg shadow p-4 border border-gray-200">
                        <div class="flex items-center justify-between">
                            <div>
                                <p class="text-sm text-gray-500">کل آیکون‌ها</p>
                                <p class="text-2xl font-bold text-gray-800" x-text="totalIcons"></p>
                            </div>
                            <i class="fas fa-th-large text-blue-500 text-2xl"></i>
                        </div>
                    </div>

                    <div class="bg-white rounded-lg shadow p-4 border border-gray-200">
                        <div class="flex items-center justify-between">
                            <div>
                                <p class="text-sm text-gray-500">صفحه فعلی</p>
                                <p class="text-2xl font-bold text-gray-800" x-text="`${currentPage} از ${totalPages}`"></p>
                            </div>
                            <i class="fas fa-file-alt text-green-500 text-2xl"></i>
                        </div>
                    </div>

                    <div class="bg-white rounded-lg shadow p-4 border border-gray-200">
                        <div class="flex items-center justify-between">
                            <div>
                                <p class="text-sm text-gray-500">نمایش در صفحه</p>
                                <p class="text-2xl font-bold text-gray-800" x-text="perPage"></p>
                            </div>
                            <i class="fas fa-eye text-purple-500 text-2xl"></i>
                        </div>
                    </div>

                    <div class="bg-white rounded-lg shadow p-4 border border-gray-200">
                        <div class="flex items-center justify-between">
                            <div>
                                <p class="text-sm text-gray-500">جستجو شده</p>
                                <p class="text-2xl font-bold text-gray-800" x-text="filteredIcons.length"></p>
                            </div>
                            <i class="fas fa-search text-yellow-500 text-2xl"></i>
                        </div>
                    </div>
                </div>
            </header>

            <!-- نوار ابزار کنترل -->
            <div class="bg-white rounded-xl shadow-lg p-6 mb-6 border border-gray-200">
                <div class="flex flex-col lg:flex-row gap-4 items-center justify-between">
                    <!-- جستجو -->
                    <div class="w-full lg:w-auto lg:flex-1">
                        <div class="relative">
                            <i class="fas fa-search absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400"></i>
                            <input type="text" x-model="searchQuery" @input="searchIcons()"
                                placeholder="جستجوی آیکون (نام، یونیکد، دسته)..."
                                class="w-full pl-4 pr-10 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none transition-all">
                            <button x-show="searchQuery" @click="searchQuery = ''; searchIcons()"
                                class="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 hover:text-gray-600">
                                <i class="fas fa-times"></i>
                            </button>
                        </div>
                    </div>

                    <!-- گروه‌بندی -->
                    <div class="w-full lg:w-auto">
                        <select x-model="groupBy" @change="groupIcons()"
                            class="w-full lg:w-48 py-3 px-4 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none bg-white">
                            <option value="">بدون گروه‌بندی</option>
                            <option value="firstLetter">گروه‌بندی بر اساس حرف اول</option>
                        </select>
                    </div>

                    <!-- مرتب‌سازی -->
                    <div class="w-full lg:w-auto">
                        <select x-model="sortBy" @change="sortIcons()"
                            class="w-full lg:w-48 py-3 px-4 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none bg-white">
                            <option value="name">مرتب‌سازی بر اساس نام</option>
                            <option value="name_desc">مرتب‌سازی بر اساس نام (نزولی)</option>
                        </select>
                    </div>

                    <!-- تعداد در هر صفحه -->
                    <div class="w-full lg:w-auto">
                        <select x-model="perPage" @change="updatePagination()"
                            class="w-full lg:w-32 py-3 px-4 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none bg-white">
                            <option value="12">۱۲ در صفحه</option>
                            <option value="24">۲۴ در صفحه</option>
                            <option value="48">۴۸ در صفحه</option>
                            <option value="96">۹۶ در صفحه</option>
                            <option value="all">همه</option>
                        </select>
                    </div>
                </div>

                <!-- فیلترهای سریع -->
                <div class="mt-4 flex flex-wrap gap-2">
                    <button @click="setQuickSearch('user')"
                        class="px-4 py-2 text-sm bg-blue-100 text-blue-700 rounded-lg hover:bg-blue-200 transition-colors flex items-center gap-2">
                        <i class="fas fa-user"></i>
                        کاربر
                    </button>
                    <button @click="setQuickSearch('home')"
                        class="px-4 py-2 text-sm bg-green-100 text-green-700 rounded-lg hover:bg-green-200 transition-colors flex items-center gap-2">
                        <i class="fa fa-house"></i>
                        خانه
                    </button>
                    <button @click="setQuickSearch('social')"
                        class="px-4 py-2 text-sm bg-purple-100 text-purple-700 rounded-lg hover:bg-purple-200 transition-colors flex items-center gap-2">
                        <i class="fas fa-share-alt"></i>
                        شبکه‌های اجتماعی
                    </button>
                    <button @click="setQuickSearch('solid')"
                        class="px-4 py-2 text-sm bg-yellow-100 text-yellow-700 rounded-lg hover:bg-yellow-200 transition-colors flex items-center gap-2">
                        <i class="fas fa-star"></i>
                        Solid
                    </button>
                    <button @click="setQuickSearch('brand')"
                        class="px-4 py-2 text-sm bg-red-100 text-red-700 rounded-lg hover:bg-red-200 transition-colors flex items-center gap-2">
                        <i class="fab fa-font-awesome"></i>
                        Brand
                    </button>
                    <button @click="clearFilters()"
                        class="px-4 py-2 text-sm bg-gray-100 text-gray-700 rounded-lg hover:bg-gray-200 transition-colors flex items-center gap-2">
                        <i class="fas fa-times"></i>
                        حذف فیلترها
                    </button>
                </div>
            </div>

            <!-- بخش اصلی آیکون‌ها -->
            <main>
                <!-- پیام خطا یا خالی -->
                <div x-show="filteredIcons.length === 0" class="text-center py-12">
                    <i class="fas fa-search text-gray-400 text-5xl mb-4"></i>
                    <h3 class="text-xl font-semibold text-gray-700 mb-2">آیکونی یافت نشد</h3>
                    <p class="text-gray-500">لطفاً عبارت جستجوی خود را تغییر دهید یا فیلترها را بازنشانی کنید.</p>
                </div>

                <!-- نمایش گروه‌بندی شده -->
                <template x-if="groupedIcons && Object.keys(groupedIcons).length > 0">
                    <div>
                        <template x-for="(group, groupName) in groupedIcons" :key="groupName">
                            <div class="mb-8">
                                <!-- هدر گروه -->
                                <div
                                    class="group-header bg-white/80 py-3 px-4 rounded-t-lg border border-gray-200 mb-2 shadow-sm">
                                    <h2 class="text-lg font-bold text-gray-800 flex items-center gap-2">
                                        <i class="fas fa-folder" :class="getGroupIcon(groupName)"></i>
                                        <span x-text="groupName"></span>
                                        <span class="text-sm font-normal text-gray-500 bg-gray-100 px-2 py-1 rounded">
                                            <span x-text="group.length"></span> آیکون
                                        </span>
                                    </h2>
                                </div>

                                <!-- آیکون‌های گروه -->
                                <div class="icon-grid mb-4">
                                    <template x-for="(icon, index) in getCurrentPageIcons(group)" :key="icon.id">
                                        <div
                                            class="icon-item bg-white rounded-lg shadow border border-gray-200 p-4 hover:shadow-md hover:border-blue-300 transition-all">
                                            <!-- پیش‌نمایش آیکون -->
                                            <div class="flex justify-center mb-3">
                                                <i :class="getIconClass(icon)" class="text-3xl"
                                                    :style="`color: ${getIconColor(icon)}`"></i>
                                            </div>

                                            <!-- اطلاعات آیکون -->
                                            <div class="text-center">
                                                <div class="font-medium text-gray-800 mb-1 text-sm"
                                                    x-html="highlightText(icon.name)"></div>
                                                <div class="text-xs text-gray-500 font-mono mb-1"
                                                    x-text="`\\${icon.unicode}`"></div>
                                                <div class="text-xs text-gray-400 flex items-center justify-center gap-1">
                                                    <i class="fas fa-tag text-xs"></i>
                                                    <span x-text="icon.category || 'عمومی'"></span>
                                                </div>
                                            </div>

                                            <!-- دکمه‌های عملیات -->
                                            <div class="mt-3 flex justify-center gap-2">
                                                <button @click="copyIconClass(icon)"
                                                    class="text-xs px-2 py-1 bg-blue-100 text-blue-700 rounded hover:bg-blue-200 transition-colors"
                                                    title="کپی کلاس">
                                                    <i class="fas fa-copy"></i>
                                                </button>
                                                <button @click="copyIconUnicode(icon)"
                                                    class="text-xs px-2 py-1 bg-green-100 text-green-700 rounded hover:bg-green-200 transition-colors"
                                                    title="کپی یونیکد">
                                                    <i class="fas fa-code"></i>
                                                </button>
                                                <button @click="previewIcon(icon)"
                                                    class="text-xs px-2 py-1 bg-purple-100 text-purple-700 rounded hover:bg-purple-200 transition-colors"
                                                    title="پیش‌نمایش">
                                                    <i class="fas fa-eye"></i>
                                                </button>
                                            </div>
                                        </div>
                                    </template>
                                </div>

                                <!-- صفحه‌بندی گروه (اگر نیاز باشد) -->
                                <template x-if="group.length > perPage">
                                    <div class="flex justify-center mt-4">
                                        <nav class="flex items-center gap-1">
                                            <template x-for="page in getGroupPages(group)" :key="page">
                                                <button @click="setGroupPage(groupName, page)"
                                                    :class="`px-3 py-1 rounded ${currentGroupPages[groupName] === page ? 'bg-blue-500 text-white' : 'bg-gray-100 text-gray-700 hover:bg-gray-200'}`"
                                                    x-text="page"></button>
                                            </template>
                                        </nav>
                                    </div>
                                </template>
                            </div>
                        </template>
                    </div>
                </template>

                <!-- نمایش بدون گروه‌بندی -->
                <template x-if="!groupBy && filteredIcons.length > 0">
                    <div>
                        <div class="icon-grid">
                            <template x-for="icon in currentPageIcons" :key="icon.id">
                                <div
                                    class="icon-item bg-white rounded-lg shadow border border-gray-200 p-4 hover:shadow-md hover:border-blue-300 transition-all">
                                    <!-- پیش‌نمایش آیکون -->
                                    <div class="flex justify-center mb-3">
                                        <i :class="getIconClass(icon)" class="text-3xl"
                                            :style="`color: ${getIconColor(icon)}`"></i>
                                    </div>

                                    <!-- اطلاعات آیکون -->
                                    <div class="text-center">
                                        <div class="font-medium text-gray-800 mb-1 text-sm"
                                            x-html="highlightText(icon.name)"></div>
                                        <div class="text-xs text-gray-500 font-mono mb-1" x-text="`\\${icon.unicode}`">
                                        </div>
                                        <div class="text-xs text-gray-400 flex items-center justify-center gap-1">
                                            <i class="fas fa-tag text-xs"></i>
                                            <span x-text="icon.category || 'عمومی'"></span>
                                        </div>
                                    </div>

                                    <!-- دکمه‌های عملیات -->
                                    <div class="mt-3 flex justify-center gap-2">
                                        <button @click="copyIconClass(icon)"
                                            class="text-xs px-2 py-1 bg-blue-100 text-blue-700 rounded hover:bg-blue-200 transition-colors"
                                            title="کپی کلاس">
                                            <i class="fas fa-copy"></i>
                                        </button>
                                        <button @click="copyIconUnicode(icon)"
                                            class="text-xs px-2 py-1 bg-green-100 text-green-700 rounded hover:bg-green-200 transition-colors"
                                            title="کپی یونیکد">
                                            <i class="fas fa-code"></i>
                                        </button>
                                        <button @click="previewIcon(icon)"
                                            class="text-xs px-2 py-1 bg-purple-100 text-purple-700 rounded hover:bg-purple-200 transition-colors"
                                            title="پیش‌نمایش">
                                            <i class="fas fa-eye"></i>
                                        </button>
                                    </div>
                                </div>
                            </template>
                        </div>
                    </div>
                </template>

                <!-- صفحه‌بندی کلی -->
                <template x-if="!groupBy && totalPages > 1">
                    <div class="mt-8 flex flex-col sm:flex-row items-center justify-between gap-4">
                        <!-- اطلاعات صفحه -->
                        <div class="text-sm text-gray-600">
                            نمایش
                            <span class="font-semibold" x-text="((currentPage - 1) * perPage) + 1"></span>
                            تا
                            <span class="font-semibold"
                                x-text="Math.min(currentPage * perPage, filteredIcons.length)"></span>
                            از
                            <span class="font-semibold" x-text="filteredIcons.length"></span>
                            آیکون
                        </div>

                        <!-- کنترل‌های صفحه‌بندی -->
                        <div class="flex items-center gap-2">
                            <!-- دکمه قبلی -->
                            <button @click="prevPage()" :disabled="currentPage === 1"
                                :class="`px-4 py-2 rounded-lg flex items-center gap-2 ${currentPage === 1 ? 'bg-gray-100 text-gray-400 cursor-not-allowed' : 'bg-white text-gray-700 hover:bg-gray-50 border border-gray-300'}`">
                                <i class="fas fa-chevron-right"></i>
                                قبلی
                            </button>

                            <!-- شماره صفحات -->
                            <div class="flex items-center gap-1">
                                <template x-for="page in paginationRange" :key="page">
                                    <button @click="goToPage(page)"
                                        :class="`w-10 h-10 rounded-lg ${currentPage === page ? 'bg-blue-500 text-white' : 'bg-white text-gray-700 hover:bg-gray-50 border border-gray-300'}`"
                                        x-text="page"></button>
                                </template>

                                <!-- نقطه‌چین برای صفحات زیاد -->
                                <span x-show="totalPages > 7 && currentPage < totalPages - 3" class="px-2">...</span>

                                <!-- آخرین صفحه -->
                                <button x-show="totalPages > 7 && currentPage < totalPages - 2"
                                    @click="goToPage(totalPages)"
                                    :class="`w-10 h-10 rounded-lg ${currentPage === totalPages ? 'bg-blue-500 text-white' : 'bg-white text-gray-700 hover:bg-gray-50 border border-gray-300'}`"
                                    x-text="totalPages"></button>
                            </div>

                            <!-- دکمه بعدی -->
                            <button @click="nextPage()" :disabled="currentPage === totalPages"
                                :class="`px-4 py-2 rounded-lg flex items-center gap-2 ${currentPage === totalPages ? 'bg-gray-100 text-gray-400 cursor-not-allowed' : 'bg-white text-gray-700 hover:bg-gray-50 border border-gray-300'}`">
                                بعدی
                                <i class="fas fa-chevron-left"></i>
                            </button>
                        </div>

                        <!-- انتخاب مستقیم صفحه -->
                        <div class="flex items-center gap-2">
                            <span class="text-sm text-gray-600">برو به صفحه:</span>
                            <input type="number" x-model="jumpToPage" @keyup.enter="jumpToPageHandler()" min="1"
                                :max="totalPages" class="w-16 px-3 py-1 border border-gray-300 rounded-lg text-center">
                        </div>
                    </div>
                </template>
            </main>

            <!-- پانل پیش‌نمایش آیکون -->
            <div x-show="showPreview"
                class="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
                <div class="bg-white rounded-xl shadow-2xl max-w-md w-full" @click.outside="showPreview = false">
                    <div class="p-6">
                        <div class="flex justify-between items-center mb-6">
                            <h3 class="text-xl font-bold text-gray-800">پیش‌نمایش آیکون</h3>
                            <button @click="showPreview = false" class="text-gray-400 hover:text-gray-600">
                                <i class="fas fa-times text-xl"></i>
                            </button>
                        </div>

                        <div class="text-center mb-6">
                            <i :class="previewIconData.class" class="text-6xl mb-4"
                                :style="`color: ${getIconColor(previewIconData)}`"></i>
                            <h4 class="text-lg font-semibold text-gray-800" x-text="previewIconData.name"></h4>
                            <p class="text-gray-600 mt-1" x-text="previewIconData.category || 'دسته‌بندی نشده'"></p>
                        </div>

                        <div class="bg-gray-50 rounded-lg p-4 mb-6">
                            <div class="space-y-3">
                                <div>
                                    <label class="text-sm text-gray-500 block mb-1">کلاس CSS:</label>
                                    <div class="flex items-center gap-2">
                                        <code
                                            class="bg-white border border-gray-300 px-3 py-2 rounded flex-1 font-mono text-sm"
                                            x-text="previewIconData.class"></code>
                                        <button @click="copyToClipboard(previewIconData.class)"
                                            class="px-3 py-2 bg-blue-500 text-white rounded-lg hover:bg-blue-600 transition-colors">
                                            <i class="fas fa-copy"></i>
                                        </button>
                                    </div>
                                </div>
                                <div>
                                    <label class="text-sm text-gray-500 block mb-1">یونیکد:</label>
                                    <div class="flex items-center gap-2">
                                        <code
                                            class="bg-white border border-gray-300 px-3 py-2 rounded flex-1 font-mono text-sm"
                                            x-text="`\\${previewIconData.unicode}`"></code>
                                        <button @click="copyToClipboard(`\\${previewIconData.unicode}`)"
                                            class="px-3 py-2 bg-green-500 text-white rounded-lg hover:bg-green-600 transition-colors">
                                            <i class="fas fa-copy"></i>
                                        </button>
                                    </div>
                                </div>
                                <div>
                                    <label class="text-sm text-gray-500 block mb-1">کد HTML:</label>
                                    <div class="flex items-center gap-2">
                                        <code
                                            class="bg-white border border-gray-300 px-3 py-2 rounded flex-1 font-mono text-sm"
                                            x-text="`<i class='${previewIconData.class}'></i>`"></code>
                                        <button @click="copyToClipboard(`<i class='${previewIconData.class}'></i>`)"
                                            class="px-3 py-2 bg-purple-500 text-white rounded-lg hover:bg-purple-600 transition-colors">
                                            <i class="fas fa-copy"></i>
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="flex justify-end gap-3">
                            <button @click="showPreview = false"
                                class="px-4 py-2 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-colors">
                                بستن
                            </button>
                            <button @click="downloadIcon(previewIconData)"
                                class="px-4 py-2 bg-blue-500 text-white rounded-lg hover:bg-blue-600 transition-colors flex items-center gap-2">
                                <i class="fas fa-download"></i>
                                دانلود SVG
                            </button>
                        </div>
                    </div>
                </div>
            </div>

            <!-- نوار اطلاع‌رسانی -->
            <div x-show="showNotification" x-transition
                class="fixed bottom-4 left-4 right-4 md:left-auto md:right-4 md:w-96 z-40">
                <div class="bg-white rounded-lg shadow-lg border border-gray-200 p-4">
                    <div class="flex items-center justify-between">
                        <div class="flex items-center gap-3">
                            <i :class="notificationIcon" class="text-xl"
                                :class="notificationType === 'success' ? 'text-green-500' : 'text-blue-500'"></i>
                            <div>
                                <p class="font-medium text-gray-800" x-text="notificationMessage"></p>
                                <p class="text-sm text-gray-500" x-text="notificationDetail"></p>
                            </div>
                        </div>
                        <button @click="showNotification = false" class="text-gray-400 hover:text-gray-600">
                            <i class="fas fa-times"></i>
                        </button>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection
@section('scripts')
    <script>
        function iconManager() {
            return {
                // داده‌ها
                allIcons: [],
                filteredIcons: [],
                currentPageIcons: [],
                groupedIcons: {},
                currentGroupPages: {},

                // وضعیت
                searchQuery: '',
                groupBy: '',
                sortBy: 'name',
                perPage: 12,
                currentPage: 1,
                totalPages: 1,
                jumpToPage: 1,

                // پیش‌نمایش
                showPreview: false,
                previewIconData: {},

                // اطلاع‌رسانی
                showNotification: false,
                notificationMessage: '',
                notificationDetail: '',
                notificationType: 'info',
                notificationIcon: 'fas fa-info-circle',

                // دسته‌بندی‌های از پیش تعریف شده
                categories: {
                    'user': ['user', 'person', 'profile', 'avatar', 'account'],
                    'home': ['home', 'house', 'building'],
                    'social': ['facebook', 'twitter', 'instagram', 'linkedin', 'youtube', 'whatsapp', 'telegram'],
                    'solid': ['solid', 'fas'],
                    'brand': ['brand', 'fab'],
                    'interface': ['edit', 'delete', 'add', 'remove', 'close', 'menu', 'settings'],
                    'media': ['photo', 'image', 'video', 'camera', 'microphone'],
                    'communication': ['phone', 'email', 'message', 'chat', 'comment'],
                    'navigation': ['arrow', 'chevron', 'caret', 'angle'],
                    'file': ['file', 'folder', 'document', 'save', 'download'],
                    'business': ['chart', 'graph', 'analytics', 'money', 'dollar'],
                    'medical': ['heart', 'health', 'hospital', 'medical'],
                    'transport': ['car', 'bus', 'plane', 'train', 'bicycle'],
                    'weather': ['sun', 'moon', 'cloud', 'rain', 'snow'],
                    'education': ['book', 'graduation', 'school', 'university'],
                    'food': ['food', 'drink', 'coffee', 'restaurant', 'utensils'],
                },

                // آیکون‌های محبوب
                popularIcons: ['home', 'user', 'cog', 'search', 'envelope', 'heart', 'star', 'calendar', 'phone', 'camera'],

                // متدهای مقداردهی اولیه
                async init() {
                    try {
                        // ابتدا از سرور درخواست می‌کنیم
                        const response = await fetch('/api/icons/extract');
                        const data = await response.json();

                        if (data.success && data.icons && data.icons.length > 0) {
                            this.allIcons = data.icons;
                            this.showNotificationMessage(
                                'بارگذاری کامل شد',
                                `${data.count} آیکون با موفقیت بارگذاری شد`,
                                'success',
                                'fas fa-check-circle'
                            );
                        } else {
                            // اگر از سرور دریافت نشد، از نمونه‌ها استفاده می‌کنیم
                            await this.loadSampleIcons();
                            this.showNotificationMessage(
                                'استفاده از داده‌های نمونه',
                                'داده‌های نمونه بارگذاری شدند',
                                'info',
                                'fas fa-info-circle'
                            );
                        }

                        this.filteredIcons = [...this.allIcons];
                        this.sortIcons();
                        this.updatePagination();

                    } catch (error) {
                        console.error('خطا در بارگذاری آیکون‌ها:', error);
                        // در صورت خطا، از نمونه‌ها استفاده می‌کنیم
                        await this.loadSampleIcons();
                        this.showNotificationMessage(
                            'خطا در بارگذاری',
                            'از داده‌های نمونه استفاده می‌شود',
                            'warning',
                            'fas fa-exclamation-triangle'
                        );
                    }
                },

                // بارگذاری آیکون‌های نمونه با بررسی وجود name
                async loadSampleIcons() {
                    const sampleIcons = [];
                    const iconNames = [
                        'home', 'user', 'cog', 'search', 'envelope', 'heart', 'star', 'calendar', 'phone', 'camera',
                        'image', 'video', 'music', 'file', 'folder', 'download', 'upload', 'trash', 'edit', 'save',
                        'print', 'share', 'link', 'lock', 'unlock', 'eye', 'eye-slash', 'bell', 'comment', 'shopping-cart',
                        'credit-card', 'bank', 'chart-line', 'chart-bar', 'map', 'globe', 'wifi', 'bluetooth', 'battery-full',
                        'microphone', 'headphones', 'tv', 'laptop', 'mobile', 'tablet', 'desktop', 'gamepad', 'keyboard',
                        'mouse', 'usb', 'hdd', 'ssd', 'database', 'server', 'cloud', 'code', 'bug', 'terminal',
                        'window-maximize', 'window-minimize', 'window-restore', 'window-close', 'expand', 'compress', 'plus',
                        'minus', 'times', 'check', 'exclamation', 'question', 'info', 'ban', 'clock', 'history', 'calendar-alt',
                        'birthday-cake', 'gift', 'rocket', 'plane', 'car', 'ship', 'bicycle', 'walking', 'running', 'swimmer',
                        'futbol', 'basketball', 'baseball', 'volleyball', 'tennis', 'golf', 'skiing', 'snowboarding', 'hiking',
                        'campground', 'mountain', 'tree', 'leaf', 'seedling', 'recycle', 'solar-panel', 'wind', 'water', 'fire',
                        'snowflake', 'sun', 'moon', 'cloud', 'cloud-rain', 'cloud-sun', 'bolt', 'umbrella', 'poo', 'biohazard',
                        'atom', 'flask', 'dna', 'microscope', 'telescope', 'satellite', 'robot', 'android', 'apple', 'windows',
                        'linux', 'github', 'gitlab', 'bitbucket', 'docker', 'jenkins', 'kubernetes', 'aws', 'azure', 'google',
                        'facebook', 'twitter', 'instagram', 'linkedin', 'youtube', 'whatsapp', 'telegram', 'discord', 'slack',
                        'skype', 'twitch', 'reddit', 'pinterest', 'tiktok', 'snapchat', 'spotify', 'soundcloud', 'deezer'
                    ];

                    for (let i = 0; i < iconNames.length; i++) {
                        const name = iconNames[i];
                        const unicode = this.generateUnicode(i);
                        const category = this.detectCategory(name);
                        const type = this.detectIconType(name);

                        // بررسی وجود تمام فیلدهای ضروری
                        sampleIcons.push({
                            id: i + 1,
                            name: name || `icon-${i + 1}`,
                            unicode: unicode || 'f000',
                            class: `${type === 'brand' ? 'fab' : 'fas'} fa-${name}`,
                            category: category || 'عمومی',
                            type: type || 'solid',
                            popularity: this.popularIcons.includes(name) ? 5 : Math.floor(Math.random() * 5) + 1
                        });
                    }

                    this.allIcons = sampleIcons;
                    this.filteredIcons = [...sampleIcons];
                },

                // تشخیص نوع آیکون
                detectIconType(name) {
                    if (!name) return 'solid';

                    const brandIcons = ['facebook', 'twitter', 'instagram', 'whatsapp', 'telegram',
                        'youtube', 'linkedin', 'github', 'gitlab', 'docker', 'aws', 'azure', 'google'];

                    for (const brand of brandIcons) {
                        if (name.includes && name.includes(brand)) {
                            return 'brand';
                        }
                    }

                    return 'solid';
                },

                // تولید یونیکد نمونه
                generateUnicode(index) {
                    const base = 0xf000;
                    return (base + index).toString(16);
                },

                // تشخیص دسته‌بندی آیکون با بررسی وجود name
                detectCategory(name) {
                    if (!name || typeof name !== 'string') {
                        return 'عمومی';
                    }

                    const nameLower = name.toLowerCase();

                    for (const [category, keywords] of Object.entries(this.categories)) {
                        for (const keyword of keywords) {
                            if (nameLower.includes(keyword)) {
                                return this.capitalizeFirstLetter(category);
                            }
                        }
                    }
                    return 'عمومی';
                },

                // جستجوی آیکون‌ها با بررسی وجود فیلدها
                searchIcons() {
                    if (!this.searchQuery.trim()) {
                        this.filteredIcons = [...this.allIcons];
                    } else {
                        const query = this.searchQuery.toLowerCase();
                        this.filteredIcons = this.allIcons.filter(icon => {
                            // بررسی وجود فیلدها قبل از دسترسی
                            const iconName = icon?.name || '';
                            const iconUnicode = icon?.unicode || '';
                            const iconCategory = icon?.category || '';
                            const iconClass = icon?.class || '';

                            return iconName.toLowerCase().includes(query) ||
                                iconUnicode.toLowerCase().includes(query) ||
                                iconCategory.toLowerCase().includes(query) ||
                                iconClass.toLowerCase().includes(query);
                        });
                    }

                    this.sortIcons();
                    this.updatePagination();
                },

                // مرتب‌سازی آیکون‌ها با بررسی وجود فیلدها
                sortIcons() {
                    switch (this.sortBy) {
                        case 'name':
                            this.filteredIcons.sort((a, b) => {
                                const nameA = a?.name || '';
                                const nameB = b?.name || '';
                                return nameA.localeCompare(nameB);
                            });
                            break;
                        case 'name_desc':
                            this.filteredIcons.sort((a, b) => {
                                const nameA = a?.name || '';
                                const nameB = b?.name || '';
                                return nameB.localeCompare(nameA);
                            });
                            break;
                        case 'unicode':
                            this.filteredIcons.sort((a, b) => {
                                const unicodeA = a?.unicode || '';
                                const unicodeB = b?.unicode || '';
                                return unicodeA.localeCompare(unicodeB);
                            });
                            break;
                        case 'popular':
                            this.filteredIcons.sort((a, b) => {
                                const popularityA = a?.popularity || 0;
                                const popularityB = b?.popularity || 0;
                                return popularityB - popularityA;
                            });
                            break;
                    }

                    if (this.groupBy) {
                        this.groupIcons();
                    } else {
                        this.updatePagination();
                    }
                },

                // گروه‌بندی آیکون‌ها با بررسی وجود فیلدها
                groupIcons() {
                    if (!this.groupBy) {
                        this.groupedIcons = {};
                        this.updatePagination();
                        return;
                    }

                    const groups = {};

                    this.filteredIcons.forEach(icon => {
                        let groupName = '';

                        switch (this.groupBy) {
                            case 'category':
                                groupName = icon?.category || 'بدون دسته';
                                break;
                            case 'firstLetter':
                                const name = icon?.name || '';
                                groupName = name.charAt(0).toUpperCase() || '?';
                                break;
                            case 'type':
                                groupName = icon?.type === 'brand' ? 'برندها' : 'آیکون‌های معمولی';
                                break;
                            default:
                                groupName = 'عمومی';
                        }

                        if (!groups[groupName]) {
                            groups[groupName] = [];
                            this.currentGroupPages[groupName] = 1;
                        }

                        groups[groupName].push(icon);
                    });

                    // مرتب‌سازی گروه‌ها
                    this.groupedIcons = Object.keys(groups)
                        .sort()
                        .reduce((sorted, key) => {
                            sorted[key] = groups[key];
                            return sorted;
                        }, {});
                },

                // به‌روزرسانی صفحه‌بندی
                updatePagination() {
                    if (this.perPage === 'all') {
                        this.currentPageIcons = this.filteredIcons;
                        this.totalPages = 1;
                        this.currentPage = 1;
                    } else {
                        const perPageNum = parseInt(this.perPage);
                        this.totalPages = Math.ceil(this.filteredIcons.length / perPageNum);
                        this.currentPage = Math.min(this.currentPage, this.totalPages || 1);

                        const start = (this.currentPage - 1) * perPageNum;
                        const end = start + perPageNum;
                        this.currentPageIcons = this.filteredIcons.slice(start, end);
                    }
                },

                // دریافت آیکون‌های صفحه جاری برای یک گروه
                getCurrentPageIcons(group) {
                    if (!group || !Array.isArray(group)) return [];

                    if (this.perPage === 'all') return group;

                    const perPageNum = parseInt(this.perPage);
                    const groupName = Object.keys(this.groupedIcons)[0];
                    const currentPage = this.currentGroupPages[groupName] || 1;
                    const start = (currentPage - 1) * perPageNum;
                    const end = start + perPageNum;

                    return group.slice(start, end);
                },

                // محاسبه تعداد صفحات برای یک گروه
                getGroupPages(group) {
                    if (!group || !Array.isArray(group)) return [1];

                    if (this.perPage === 'all') return [1];

                    const perPageNum = parseInt(this.perPage);
                    const pages = Math.ceil(group.length / perPageNum);
                    return Array.from({ length: pages }, (_, i) => i + 1);
                },

                // تغییر صفحه برای یک گروه خاص
                setGroupPage(groupName, page) {
                    this.currentGroupPages[groupName] = page;
                },

                // تغییر صفحه
                goToPage(page) {
                    if (page >= 1 && page <= this.totalPages) {
                        this.currentPage = page;
                        this.updatePagination();
                    }
                },

                // صفحه بعدی
                nextPage() {
                    if (this.currentPage < this.totalPages) {
                        this.currentPage++;
                        this.updatePagination();
                    }
                },

                // صفحه قبلی
                prevPage() {
                    if (this.currentPage > 1) {
                        this.currentPage--;
                        this.updatePagination();
                    }
                },

                // پرش به صفحه خاص
                jumpToPageHandler() {
                    const page = parseInt(this.jumpToPage);
                    if (!isNaN(page) && page >= 1 && page <= this.totalPages) {
                        this.goToPage(page);
                    }
                    this.jumpToPage = '';
                },

                // محدوده صفحات برای نمایش
                get paginationRange() {
                    const range = [];
                    const delta = 2;
                    const left = this.currentPage - delta;
                    const right = this.currentPage + delta;

                    for (let i = 1; i <= this.totalPages; i++) {
                        if (i === 1 || i === this.totalPages || (i >= left && i <= right)) {
                            range.push(i);
                        }
                    }

                    return range;
                },

                // دریافت کلاس آیکون با بررسی وجود
                getIconClass(icon) {
                    return icon?.class || 'fas fa-question-circle';
                },

                // دریافت رنگ آیکون
                getIconColor(icon) {
                    if (!icon) return '#6B7280';

                    const colors = {
                        'brand': '#1877F2',
                        'solid': '#4F46E5',
                        'user': '#10B981',
                        'home': '#F59E0B',
                        'social': '#8B5CF6',
                        'default': '#6B7280'
                    };

                    const iconType = icon?.type || 'solid';
                    const iconCategory = icon?.category ? icon.category.toLowerCase() : '';

                    return colors[iconType] ||
                        colors[iconCategory] ||
                        colors['default'];
                },

                // دریافت آیکون برای گروه
                getGroupIcon(groupName) {
                    if (!groupName) return 'fa-folder';

                    const icons = {
                        'کاربر': 'fa-user',
                        'خانه': 'fa-home',
                        'شبکه‌های اجتماعی': 'fa-share-alt',
                        'Solid': 'fa-star',
                        'برندها': 'fa-font-awesome',
                        'عمومی': 'fa-th-large',
                        'بدون دسته': 'fa-question-circle',
                        'A': 'fa-font',
                        'B': 'fa-bold',
                        'C': 'fa-code',
                        'D': 'fa-database',
                        'default': 'fa-folder'
                    };

                    return icons[groupName] || icons['default'];
                },

                // هایلایت متن جستجو با بررسی وجود
                highlightText(text) {
                    if (!text || typeof text !== 'string') return '';
                    if (!this.searchQuery.trim()) return text;

                    try {
                        const regex = new RegExp(`(${this.searchQuery})`, 'gi');
                        return text.replace(regex, '<span class="highlight">$1</span>');
                    } catch (e) {
                        return text;
                    }
                },

                // تنظیم جستجوی سریع
                setQuickSearch(query) {
                    this.searchQuery = query;
                    this.searchIcons();
                },

                // پاک کردن فیلترها
                clearFilters() {
                    this.searchQuery = '';
                    this.groupBy = '';
                    this.sortBy = 'name';
                    this.perPage = 12;
                    this.searchIcons();
                },

                // کپی کلاس آیکون
                async copyIconClass(icon) {
                    if (!icon) return;

                    const text = icon.class || '';
                    await this.copyToClipboard(text);
                    this.showNotificationMessage(
                        'کپی شد',
                        `کلاس "${text}" در کلیپ‌بورد کپی شد`,
                        'success',
                        'fas fa-check-circle'
                    );
                },

                // کپی یونیکد آیکون
                async copyIconUnicode(icon) {
                    if (!icon) return;

                    const text = icon.unicode ? `\\${icon.unicode}` : '';
                    await this.copyToClipboard(text);
                    this.showNotificationMessage(
                        'کپی شد',
                        `یونیکد "${text}" در کلیپ‌بورد کپی شد`,
                        'success',
                        'fas fa-check-circle'
                    );
                },

                // پیش‌نمایش آیکون
                previewIcon(icon) {
                    if (!icon) return;

                    this.previewIconData = {
                        name: icon.name || 'نامشخص',
                        unicode: icon.unicode || 'f000',
                        class: icon.class || 'fas fa-question-circle',
                        category: icon.category || 'عمومی',
                        type: icon.type || 'solid'
                    };
                    this.showPreview = true;
                },

                // کپی به کلیپ‌بورد
                async copyToClipboard(text) {
                    if (!text) return false;

                    try {
                        await navigator.clipboard.writeText(text);
                        return true;
                    } catch (err) {
                        // روش fallback برای مرورگرهای قدیمی
                        try {
                            const textArea = document.createElement('textarea');
                            textArea.value = text;
                            document.body.appendChild(textArea);
                            textArea.select();
                            document.execCommand('copy');
                            document.body.removeChild(textArea);
                            return true;
                        } catch (e) {
                            console.error('خطا در کپی به کلیپ‌بورد:', e);
                            return false;
                        }
                    }
                },

                // دانلود آیکون (نمونه)
                downloadIcon(icon) {
                    if (!icon) return;

                    this.showNotificationMessage(
                        'در حال توسعه',
                        'قابلیت دانلود SVG به زودی اضافه خواهد شد',
                        'info',
                        'fas fa-info-circle'
                    );
                },

                // نمایش پیام اطلاع‌رسانی
                showNotificationMessage(message, detail, type, icon) {
                    this.notificationMessage = message || '';
                    this.notificationDetail = detail || '';
                    this.notificationType = type || 'info';
                    this.notificationIcon = icon || 'fas fa-info-circle';
                    this.showNotification = true;

                    // مخفی شدن خودکار پس از ۵ ثانیه
                    setTimeout(() => {
                        this.showNotification = false;
                    }, 5000);
                },

                // تبدیل حرف اول به بزرگ
                capitalizeFirstLetter(string) {
                    if (!string || typeof string !== 'string') return '';
                    return string.charAt(0).toUpperCase() + string.slice(1);
                },

                // Getter برای محاسبات
                get totalIcons() {
                    return this.allIcons.length;
                }
            }
        }
    </script>
@endsection
