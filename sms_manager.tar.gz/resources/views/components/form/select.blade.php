<div {{ $attributes->class(['mb-4']) }}>
    @isset($label)
        <label class="block text-sm font-bold text-gray-700 mb-2"
            for="{{ $selectId ?? ($attributes->get('id') ?? Str::random(10)) }}">
            {{ $label }}
        </label>
    @endisset
    @isset($options)
        <select
            {{ $options->attributes->merge([
                'class' =>
                    'w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500',
                'id' => $selectId ?? '',
                'name' => $selectName ?? '',
            ]) }}>
            {{ $options }}
        </select>
    @endisset
    @isset($error)
        <p class="text-red-500 text-xs italic">{{ $error }}</p>
    @endisset
</div>
