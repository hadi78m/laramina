<?php

return [
    'Showing'=>'نمایش',
    'to'=>'تا',
    'of'=>'از',
    'results'=>'نتیجه',
    'previous'=>'قبلی',
    'next'=>'بعدی',
    ''=>'',
    ''=>'',
];