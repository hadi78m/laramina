<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('sms_messages', function (Blueprint $table) {
            $table->id();
            $table->foreignId('sms_credential_id')->constrained('sms_credentials')->onDelete('cascade');
            $table->string('recipient');
            $table->text('message');
            $table->enum('type', ['default', 'news', 'otp'])->default('default');
            $table->enum('status', ['pending', 'blocked', 'sent', 'failed'])->default('pending');
            $table->text('blocked_reason')->nullable();
            $table->json('blocked_words')->nullable();
            $table->string('gateway_message_id')->nullable();
            $table->timestamp('sent_at')->nullable();
            $table->timestamps();
            
            $table->index('sms_credential_id');
            $table->index('status');
            $table->index('recipient');
            $table->index('created_at');
            
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('sms_messages');
    }
};
