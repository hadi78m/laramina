<script>
    let providersTable;
    const providerJsonUrl = '{{ route('sms.providers.json') }}';
    const providerStoreUrl = '{{ route('sms.providers.store') }}';
    // Note: For edit, delete, etc., it's better to have a base URL.
    // We'll construct them dynamically for now.
    const providersBaseUrl = '{{ url('sms/providers') }}';
    $(document).ready(function () {
        providersTable = $('#providersTable').DataTable({
            processing: true,
            "dom": 'Blfrtip', // نمایش دکمه‌ها
            "buttons": [{
                extend: 'copy',
                text: 'کپی',
                className: 'bg-gray-500 hover:bg-gray-600 text-white px-4 py-2 rounded-lg text-sm font-medium transition-colors duration-200'
            },
            {
                extend: 'excel',
                text: 'اکسل',
                className: 'bg-green-500 hover:bg-green-600 text-white px-4 py-2 rounded-lg text-sm font-medium transition-colors duration-200'
            },
            {
                extend: 'pdf',
                text: 'PDF',
                className: 'bg-red-500 hover:bg-red-600 text-white px-4 py-2 rounded-lg text-sm font-medium transition-colors duration-200'
            },
            {
                extend: 'print',
                text: 'چاپ',
                className: 'bg-blue-500 hover:bg-blue-600 text-white px-4 py-2 rounded-lg text-sm font-medium transition-colors duration-200'
            }
            ],
            ajax: '{{ route('sms.providers.json') }}',
            columns: [{
                data: 'id'
            },
            {
                data: 'name',
                render: data => `<span class="font-semibold">${data}</span>`
            },
            // {
            //     data: 'user',
            //     render: data => data ? data : '<span class="text-gray-400">تنظیم نشده</span>'
            // },
            {
                data: 'url',
                render: data => data ? `<code class="text-xs">${data}</code>` :
                    '<span class="text-gray-400">تنظیم نشده</span>'
            },
            {
                data: 'is_active',
                render: data => data ?
                    '<span class="px-3 py-1 bg-green-100 text-green-800 text-xs rounded-full">فعال</span>' :
                    '<span class="px-3 py-1 bg-red-100 text-red-800 text-xs rounded-full text-center">غیرفعال</span>'
            },
            {
                data: 'is_default',
                render: data => data ?
                    '<span class="px-3 py-1 bg-indigo-100 text-indigo-800 text-xs rounded-full font-bold">پیش‌فرض</span>' :
                    '<span class="text-gray-400 text-xs text-center">—</span>'
            },
            {
                data: 'created_at',

            },
            { data: 'send_rate', render: data => data ?? '<span class="text-gray-400">نامحدود</span>' },
            {
                data: 'rate_unit',
                render: (data => {
                    const units = { per_second: 'در ثانیه', per_minute: 'در دقیقه', per_hour: 'در ساعت', unlimited: 'نامحدود' };
                    return rowData => units[rowData] ?? rowData;
                })()
            },
            
            {
                data: null,
                orderable: false,
                searchable: false,
                render: function (data) {
                    const statusBtn = data.is_active ?
                        `<button onclick="toggleStatus(${data.id})" class="px-3 py-1 bg-orange-500 text-white rounded hover:bg-orange-600" title="غیرفعال کردن"><i class="fas fa-ban"></i></button>` :
                        `<button onclick="toggleStatus(${data.id})" class="px-3 py-1 bg-green-500 text-white rounded hover:bg-green-600" title="فعال کردن"><i class="fas fa-check"></i></button>`;

                    const defaultBtn = data.is_default ?
                        `<button class="px-3 py-1 bg-gray-500 text-white rounded cursor-not-allowed text-xs">پیش‌فرض</button>` :
                        `<button onclick="setDefault(${data.id})" class="px-3 py-1 bg-indigo-600 text-white rounded hover:bg-indigo-700 text-xs">پیش‌فرض کن</button>`;

                    const testBtn =
                        `<button onclick="testConnection(${data.id})" class="px-3 py-1 bg-teal-500 text-white rounded hover:bg-teal-600" title="تست اتصال"><i class="fas fa-plug"></i></button>`;
                    const phoneBtn =
                        `<button class="px-3 py-1 bg-purple-500 text-white rounded hover:bg-purple-600 action-numbers" title="شماره‌ها"><i class="fas fa-phone"></i></button>`;

                    return `
                            <div class="flex gap-1">
                                <button onclick="editProvider(${data.id})" class="px-3 py-1 bg-blue-500 text-white rounded hover:bg-blue-600"><i class="fas fa-edit"></i></button>
                                ${statusBtn}
                                ${testBtn}
                                ${defaultBtn}
                                @role('SuperAdmin')
                                <button onclick="deleteProvider(${data.id})" class="px-3 py-1 bg-red-500 text-white rounded hover:bg-red-600"><i class="fas fa-trash"></i></button>
                                @endrole
                                ${phoneBtn}
                            </div>
                        `;
                }
            }
            ],
            order: [
                [0, 'desc']
            ],
            language: {
                url: "{{ asset('assets/lang/datatables/fa.json') }}"
            }
        });

        $('#addProviderForm').on('submit', function (e) {
            e.preventDefault();
            $('.error-name').addClass('hidden');
            $.ajax({
                url: providerStoreUrl,
                method: 'POST',
                data: $(this).serialize(),
                success: res => {
                    if (res.success) {
                        closeAddModal();
                        this.reset();
                        providersTable.ajax.reload();
                        showSuccess(res.message);
                    }
                },
                error: xhr => {
                    if (xhr.responseJSON?.errors?.name) {
                        $('.error-name').text(xhr.responseJSON.errors.name[0]).removeClass(
                            'hidden');
                    } else {
                        showError(xhr.responseJSON?.message || 'خطا در ذخیره');
                    }
                }
            });
        });

        $('#editProviderForm').on('submit', function (e) {
            e.preventDefault();
            const id = $('#edit_provider_id').val();
            $.ajax({
                url: `${providersBaseUrl}/${id}`,
                method: 'PUT',
                data: $(this).serialize(),
                success: res => {
                    if (res.success) {
                        closeEditModal();
                        providersTable.ajax.reload();
                        showSuccess(res.message);
                    }
                },
                error: xhr => showError(xhr.responseJSON?.message || 'خطا در بروزرسانی')
            });
        });
        $('#add_rate_unit, #edit_rate_unit').on('change', function () {
            const isUnlimited = $(this).val() === 'unlimited';
            $(this).closest('form').find('input[name="send_rate"]').prop('disabled', isUnlimited).val(isUnlimited ? '' : 10);
        });

        // Event Delegation for action buttons
        $('#providersTable tbody').on('click', 'button', function () {
            const row = providersTable.row($(this).closest('tr')).data();
            const id = row.id;

            if ($(this).hasClass('action-edit')) {
                editProvider(id);
            } else if ($(this).hasClass('action-delete')) {
                deleteProvider(id);
            } else if ($(this).hasClass('action-test')) {
                testConnection(id);
            }
        });
    });

    function openAddModal() {
        $('#addProviderModal').removeClass('hidden');
    }

    function closeAddModal() {
        $('#addProviderModal').addClass('hidden');
        $('#addProviderForm')[0].reset();
    }

    function openEditModal() {
        $('#editProviderModal').removeClass('hidden');
    }

    function closeEditModal() {
        $('#editProviderModal').addClass('hidden');
    }

    function editProvider(id) {

        $('#edit_provider_id').val('');
        $('#edit_name').val('');
        $('#edit_helper_name').val('');
        $('#edit_user').val('');
        $('#edit_url').val('');
        $('#edit_is_active').prop('');
        $('#edit_is_default').prop('');
        $('#edit_send_rate').val('');
        $('#edit_token').val('');
        $('#edit_rate_unit').val('').trigger('change');

        // It's better to have a dedicated API endpoint like GET /sms/providers/{id}
        $.get(`${providersBaseUrl}/${id}/edit`, res => {
            const provider = res.provider;
            if (provider) {
                $('#edit_provider_id').val(provider.id);
                $('#edit_name').val(provider.name);
                $('#edit_helper_name').val(provider.helper_name);
                $('#edit_user').val(provider.user || '');
                $('#edit_url').val(provider.url || '');
                $('#edit_is_active').prop('checked', !!provider.is_active);
                $('#edit_is_default').prop('checked', !!provider.is_default);
                $('#edit_send_rate').val(provider.send_rate);
                $('#edit_token').val(provider.token);
                $('#edit_rate_unit').val(provider.rate_unit).trigger('change'); // trigger change to update send_rate field
                openEditModal();
            } else {
                showError('ارائه‌دهنده یافت نشد.');
            }
        }).fail(() => showError('خطا در دریافت اطلاعات ارائه‌دهنده.'));
    }

    function setDefault(id) {

        Swal.fire({
    title: '<div class="text-center">تغییر پیش‌فرض؟</div>',
    html: `<div class="text-center">این پروایدر پیش‌فرض می‌شود</div>`,
    icon: 'question',
    showCancelButton: true,
    confirmButtonText: 'بله',
    cancelButtonText: 'خیر'
}).then(r => {
    if (!r.isConfirmed) return;

    $.ajax({
        url: `${providersBaseUrl}/${id}/set-default`,
        method: 'POST',
        data: {
            _token: $('meta[name="csrf-token"]').attr('content')
        },success: res => res.success ?
                Swal.fire({
                    icon: 'success',
                    html: `<div class="text-right text-sm">
                        <p>${res.message ? `<p><strong>پیام:</strong> ${res.message}</p>` : ''}
                      </div>`
                }) :
                Swal.fire({
                    icon: 'error',
                    title: '<div class="text-center">تغییر پیش‌فرض؟</div>',
                    html: `<div class="text-center text-sm">
                        <p>${res.message ? `<p><strong>پیام:</strong> ${res.message}</p>` : ''}
                      </div>`
                }),
            error: xhr => Swal.fire({
                icon: 'error',
                title: 'خطا',
                html: `<div class="text-center">
                        <p>${xhr.responseJSON?.message ? `<p><strong>پیام:</strong> ${xhr.responseJSON?.message}</p>` : ''}
                      </div>`
                // text: xhr.responseJSON?.message || 'مشکل در ارتباط'
            })
          });

});

    }

    function deleteProvider(id) {
        Swal.fire({
            title: 'حذف؟',
            text: 'قابل بازگشت نیست!',
            icon: 'warning',
            showCancelButton: true,
            confirmButtonText: 'حذف',
            cancelButtonText: 'انصراف',
            confirmButtonColor: '#ef4444'
        })
            .then(r => r.isConfirmed && $.ajax({
                url: `${providersBaseUrl}/${id}`,
                method: 'DELETE',
                data: {
                    _token: $('meta[name="csrf-token"]').attr('content')
                },
                success: res => {
                    providersTable.ajax.reload();
                    showSuccess(res.message);
                }
            }));
    }

    function toggleStatus(id) {
        $.post(`${providersBaseUrl}/${id}/toggle-status`, {
            _token: $('meta[name="csrf-token"]').attr('content')
        }, res => {
            if (res.success) {
                providersTable.ajax.reload();
                showSuccess(res.message);
            } else showError(res.message);
        }).fail(xhr => showError(xhr.responseJSON?.message || 'خطا'));
    }

    /*** تست اتصال**/
    async function testConnection(id) {

        const { value: phone } = await Swal.fire({
            title: 'شماره تلفن را وارد کنید',
            input: 'text',
            inputPlaceholder: 'مثلا 09123456789',
            showCancelButton: true,
            confirmButtonText: 'تست اتصال',
            cancelButtonText: 'انصراف',
            inputValidator: (value) => {
                if (!value) {
                    return 'شماره تلفن الزامی است';
                }
            }
        });

        if (!phone) return;

        Swal.fire({
            title: 'در حال تست...',
            allowOutsideClick: false,
            didOpen: () => Swal.showLoading()
        });

        $.ajax({
            url: `${providersBaseUrl}/${id}/test-connection`,
            method: 'POST',
            data: {
                _token: $('meta[name="csrf-token"]').attr('content'),
                phone: phone
            },
            success: res => res.success ?
                Swal.fire({
                    icon: 'success',
                    title: 'متصل شد!',
                    html: `<div class="text-right text-sm">
                        <p><strong>پروایدر:</strong> ${res.provider}</p>
                        <p><strong>زمان پاسخ:</strong> ${res.response_time}ms</p>
                        ${res.message ? `<p><strong>پیام:</strong> ${res.message}</p>` : ''}
                      </div>`
                }) :
                Swal.fire({
                    icon: 'error',
                    title: 'ناموفق',
                    text: res.message
                }),
            error: xhr => Swal.fire({
                icon: 'error',
                title: 'خطا',
                text: xhr.responseJSON?.message || 'مشکل در ارتباط'
            })
        });
    }

    // / Event Delegation جدید برای دکمه شماره‌ها
    $('#providersTable tbody').on('click', '.action-numbers', function () {
        const row = providersTable.row($(this).closest('tr')).data();
        manageNumbers(row.id);
    });

    function manageNumbers(providerId) {
        $('#current_provider_id').val(providerId);
        loadNumbers(providerId);
        // نمایش مدال + لودینگ
        $('#manageNumbersModal').removeClass('hidden');
        $('#numbersLoading').removeClass('hidden');
        $('#numbersTable').addClass('hidden');           // مخفی کردن جدول تا لود کامل شود
        openNumbersModal();
    }

    function loadNumbers(providerId) {
        $.get(`${providersBaseUrl}/${providerId}/numbers`, res => {
            if (res.success) {
                const tbody = $('#numbersTable tbody');
                tbody.empty();

                if (res.numbers.length === 0) {
                    tbody.append('<tr><td colspan="3" class="text-center py-4 text-gray-500">هیچ شماره‌ای ثبت نشده است</td></tr>');
                } else {
                    res.numbers.forEach(num => {
                        const status = num.is_active
                            ? '<span class="bg-green-100 text-green-800 px-2 py-1 rounded">فعال</span>'
                            : '<span class="bg-red-100 text-red-800 px-2 py-1 rounded">غیرفعال</span>';

                        tbody.append(`
                        <tr>
                            <td class="px-4 py-2">${num.number}</td>
                            <td class="px-4 py-2">${status}</td>
                            <td class="px-4 py-2 flex gap-2">
                                <button class="bg-yellow-500 text-white px-2 py-1 rounded toggle-status" data-id="${num.id}">تغییر وضعیت</button>
                                <button class="bg-red-500 text-white px-2 py-1 rounded delete-number" data-id="${num.id}">حذف</button>
                            </td>
                        </tr>
                    `);
                    });
                }

                // پایان لودینگ → نمایش جدول
                $('#numbersLoading').addClass('hidden');
                $('#numbersTable').removeClass('hidden');
            } else {
                showError('خطا در دریافت شماره‌ها');
                closeNumbersModal(); // یا مدیریت خطا به شکل دیگری
            }
        }).fail(() => {
            showError('خطا در ارتباط با سرور');
            $('#numbersLoading').addClass('hidden');
            closeNumbersModal();
        });
    }

    // هنگام بستن مدال (اختیاری - برای ریست کردن وضعیت)
    function closeNumbersModal() {
        $('#manageNumbersModal').addClass('hidden');
        $('#numbersLoading').addClass('hidden');
        $('#numbersTable').addClass('hidden');
        $('#numbersTable tbody').empty(); // پاک کردن لیست قبلی
    }
    // Submit فرم افزودن شماره
    $('#addNumberForm').on('submit', function (e) {
        e.preventDefault();
        const providerId = $('#current_provider_id').val();
        $.ajax({
            url: `${providersBaseUrl}/${providerId}/numbers`,
            method: 'POST',
            data: $(this).serialize(),
            success: res => {
                if (res.success) {
                    this.reset();
                    loadNumbers(providerId);
                    showSuccess(res.message);
                }
            },
            error: xhr => showError(xhr.responseJSON?.message || 'خطا در ذخیره شماره')
        });
    });

    // Toggle وضعیت
    $('#manageNumbersModal').on('click', '.toggle-status', function () {
        const numberId = $(this).data('id');
        const providerId = $('#current_provider_id').val();
        $.post(`${providersBaseUrl}/${providerId}/numbers/${numberId}/toggle`, { _token: $('meta[name="csrf-token"]').attr('content') }, res => {
            if (res.success) {
                loadNumbers(providerId);
                showSuccess(res.message);
            }
        });
    });

    // حذف شماره
    $('#manageNumbersModal').on('click', '.delete-number', function () {
        const numberId = $(this).data('id');
        const providerId = $('#current_provider_id').val();
        Swal.fire({
            title: 'حذف شماره؟',
            text: 'قابل بازگشت نیست!',
            icon: 'warning',
            showCancelButton: true,
            confirmButtonText: 'حذف',
            cancelButtonText: 'انصراف'
        }).then(r => r.isConfirmed && $.ajax({
            url: `${providersBaseUrl}/${providerId}/numbers/${numberId}`,
            method: 'DELETE',
            data: { _token: $('meta[name="csrf-token"]').attr('content') },
            success: res => {
                loadNumbers(providerId);
                showSuccess(res.message);
            }
        }));
    });

    function openNumbersModal() { $('#manageNumbersModal').removeClass('hidden'); }

    $('#addProviderModal, #editProviderModal').on('click', function (e) {
        if (e.target === this) {
            $(this).addClass('hidden');
        }
    });
    $(document).on('keydown', function (e) {
        if (e.key === 'Escape') {
            closeAddModal();
            closeEditModal();
        }
    });
</script>