{{-- <h2>{{ dd($exception->getMessage(),get_class($exception)) }}</h2> --}}
@php
    $uri = "$_SERVER[REQUEST_URI]";
    if (strpos($uri, 'admin')) {
        $route = 'logout';
        $app = 'app.logout';
        $method = 'post';
    } else {
        $route = 'client.home';
        $app = 'app.home';
        $method = 'get';
    }

    // $message = $exception->getMessage();
    // if (strpos($exception->getMessage(), 'Unknown database')) {
    //     $message = 'عدم ارتباط با پایگاه داده لطفا تنظیمات و یا درخواست خود را بررسی نمایید';
    // }
    // if (strpos($exception->getMessage(), 'Connection timed out')) {
    //     $message = 'Connection timed out';
    // }
    // if (strpos($exception->getMessage(), 'Unknown column')) {
    //     $message = 'تناقض در داده درخواستی و ساختار پایگاه داده';
    // }
    // if (strpos($exception->getMessage(), 'not found')) {
    //     $re = '/(?:\w*)\w(")/';
    //     $str = $exception->getMessage();

    //     preg_match_all($re, $str, $matches, PREG_SET_ORDER, 0);

    //     // Print the entire match result
    //     $matches = str_replace('"', '', $matches[0][0]);

    //     $message = "کلاس $matches تعریف نشده است";
    // }

@endphp
@extends('errors::minimal')
@section('title', __('خطای 500 - مشکل سرور'))
{{-- {{$message}} --}}
{{-- @section('code', '500') --}}
@section('message')
<style>
        .pulse {
            animation: pulse 2s cubic-bezier(0.4, 0, 0.6, 1) infinite;
        }
        @keyframes pulse {
            0%, 100% { opacity: 1; }
            50% { opacity: 0.5; }
        }
        .gear {
            animation: spin 6s linear infinite;
        }
        @keyframes spin {
            from { transform: rotate(0deg); }
            to { transform: rotate(360deg); }
        }
</style>

    <div class="max-w-lg w-full bg-white rounded-xl shadow-2xl overflow-hidden">
        <div class="bg-gradient-to-r from-orange-500 to-amber-600 p-6 text-center">
            <div class="relative inline-block">
                <svg xmlns="http://www.w3.org/2000/svg" class="h-20 w-20 mx-auto text-white gear" fill="none"
                    viewBox="0 0 24 24" stroke="currentColor">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                        d="M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.065 2.572c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.572 1.065c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.065-2.572c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.07 2.572-1.065z" />
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                        d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
                </svg>
                <div class="absolute -top-2 -right-2">
                    <span class="relative flex h-6 w-6">
                        <span
                            class="animate-ping absolute inline-flex h-full w-full rounded-full bg-red-400 opacity-75"></span>
                        <span
                            class="relative inline-flex rounded-full h-6 w-6 bg-red-500 text-white items-center justify-center text-xs font-bold">!</span>
                    </span>
                </div>
            </div>
            <h1 class="text-3xl font-bold text-white mt-4">500 - خطای سرور</h1>
        </div>

        <div class="p-8 text-center">
            <p class="text-gray-700 mb-6">متأسفیم! مشکلی در سرور رخ داده است.</p>

            <div class="bg-amber-50 border border-amber-200 text-amber-700 px-4 py-3 rounded mb-6">
                <p>تیم فنی ما از این مشکل مطلع شده و در حال رسیدگی است.</p>
                <p class="mt-2 text-sm">لطفاً چند دقیقه دیگر مجدداً تلاش کنید.</p>
            </div>

            <div class="flex flex-col space-y-3">
                <a href="/"
                    class="bg-amber-600 hover:bg-amber-700 text-white font-medium py-2 px-4 rounded-lg transition duration-200 pulse">
                    بازگشت به صفحه اصلی
                </a>
                <a href="{{ url()->previous() }}"
                    class="text-indigo-600 hover:text-indigo-800 font-medium py-2 px-4 rounded-lg transition duration-200">
                    بازگشت به صفحه قبل
                </a>
                <a {{-- href="/contact" --}}
                    class="text-amber-600 hover:text-amber-800 font-medium py-2 px-4 rounded-lg transition duration-200">
                    تماس فوری با پشتیبانی
                </a>

            </div>
        </div>
    </div>


@endsection
