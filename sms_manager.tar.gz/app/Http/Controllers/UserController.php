<?php

namespace App\Http\Controllers;

use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Spatie\Permission\Models\Role;
use Spatie\Permission\Models\Permission;

class UserController extends Controller
{
    public function index()
    {
        $users = User::all();
        return view('users.index', compact('users'));
    }

    public function json(Request $request)
    {
        $data =  User::adminTable($request, [
            'search' => ['name', 'national_code'],
            'filters' => ['is_active'],
        ]);

        return $data;
    }
    /*
    *
     * 
     * تغییر وضعیت فعال/غیرفعال 
     *
     */
    public function toggleStatus($id)
    {
        $user = User::findOrFail($id);

        try {
            if ($user->hasRole('SuperAdmin')) {
                return response()->json([
                    'success' => false,
                    'message' => 'کاربر اصلی غیر فعال نمی شود',
                ]);
            }
            $user->toggleStatus();
            return response()->json([
                'success' => true,
                'message' => $user->is_active ? 'کاربر فعال شد.' : 'کاربر غیرفعال شد.',
                'is_active' => $user->is_active,
            ], 200);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => $e->getMessage()
            ], 400);
        }
    }
    public function store(Request $request)
    {
        $user = User::create($request->validate([
            'name' => 'required',
            'email' => 'required|email|unique:users,email',
            'password' => 'required|min:6',
            'national_code' => 'required|regex:/^[0-9]{10}$/|unique:users,national_code',
        ], [

            'name.required' => 'نام اجباری است',
            'email.required' => 'ایمیل اجباری است',
            'email.email' => 'فرمت ایمل نامعتبر است',
            'email.unique' => 'برای این ایمیل اکانتی از قبل تعریف شده است',


            'password.required' => 'رمز عبور اجباری است',
            'password.min' => 'رمز عبور حداقل 6 رقم می باشد',

            'national_code.required' => 'کدملی اجباری است',
            'national_code.regex' => 'کدملی را فقط عدد و 10 رقم وارد کنید',
            'national_code.unique' => 'برای این کدملی اکانتی از قبل تعریف شده است',
        ]));

        if ($request->roles) {
            $user->syncRoles($request->roles);
        }
        if ($request->permissions) {
            $user->syncPermissions($request->permissions);
        }
        if ($user) {
            return response()->json([
                'success' => true,
                'message' => 'کاربر با موفقیت اضافه شد.',
            ], 200);
        } else {
            return response()->json([
                'success' => false,
                'message' => 'خطا در افزودن کاربر',
            ], 200);
        }
        return response()->json($user, 201);
    }

    public function update(Request $request, $id)
    {

        $rules = [
            'name' => 'required|string|max:255',
            'email' => 'required|email|unique:users,email,' . $id . 'email',
            'password' => 'nullable|min:6|max:255',
            'national_code' => 'required|regex:/^[0-9]{10}$/|unique:users,national_code,' . $id . 'national_code',
        ];
        // اگر password خالی بود، از validation حذفش کن
        if (empty($request->password)) {
            unset($rules['password']);
        }

        $validated = $request->validate(
            $rules,
            [
                'name.required' => 'نام اجباری است',
                'email.required' => 'ایمیل اجباری است',
                'email.email' => 'فرمت ایمل نامعتبر است',
                'email.unique' => 'برای این ایمیل اکانتی از قبل تعریف شده است',
                // 'password.required' => 'رمز عبور اجباری است',
                'password.min' => 'رمز عبور حداقل 6 رقم می باشد',
                'national_code.required' => 'کدملی اجباری است',
                'national_code.regex' => 'کدملی را فقط عدد و 10 رقم وارد کنید',
                'national_code.unique' => 'برای این کدملی اکانتی از قبل تعریف شده است',
            ]
        );

        // اگر password وجود داشت، هش کن
        if (isset($validated['password'])) {
            $validated['password'] = bcrypt($validated['password']);
        } else {
            unset($validated['password']);
        }

        DB::beginTransaction();

        $user = User::findOrFail($id);
        $user->update($validated);

        if ($request->roles) {
            $user->syncRoles($request->roles);
        }
        if ($request->permissions) {
            $user->syncPermissions($request->permissions);
        }
        DB::commit();

        return response()->json($user);
        return response()->json(['message' => 'کاربر با موفقیت به‌روزرسانی شد', 'success' => true], 200);
    }

    public function destroy($id)
    {
        $user = User::find($id);

        if (!$user->hasRole('SuperAdmin')) {
            DB::beginTransaction();
            // حذف تمام نقش‌های کاربر
            $user->syncRoles([]);
            
            // حذف تمام دسترسی‌های مستقیم کاربر
            $user->syncPermissions([]);
            // حذف کاربر
            User::destroy($id);
            DB::commit();
            return response()->json([
                'success' => true,
                'message' => 'حذف کاربر با موفقیت انجام شد.',
            ], 200);
        } else {
            return response()->json([
                'success' => false,
                'message' => 'کاربر اصلی قابل حذف نمی باشد',
            ], 400);
        }
    }

    public function edit(User $user)
    {
        return response()->json([
            'name' => $user->name,
            'email' => $user->email,
            'national_code' => $user->national_code,
            'roles' => $user->getRoleNames(),
            'permissions' => $user->getPermissionNames()
        ]);
    }
}
