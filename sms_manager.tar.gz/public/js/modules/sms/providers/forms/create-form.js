export const createForm = {

    endpoint: 'sms.providers.store',
    updateEndpoint: 'sms.providers.update',
    deleteEndpoint: 'sms.providers.destroy',
    
    fields: [
        {
            name: 'name',
            label: 'نام پرووایدر',
            type: 'text',
            required: true,
            placeholder: 'نام نمایشی پرووایدر'
        },
        {
            name: 'helper_name',
            label: 'نام هلپر',
            type: 'text',
            placeholder: 'نام هلپر',
            role:['SuperAdmin']
        },
        {
            type: 'group',
            group: [
                {
                    name: 'user',
                    label: 'نام کاربری',
                    type: 'text',
                    placeholder: 'نام کاربری ارائه شده توسط پرووایدر'
                    // required: true
                },
                {
                    name: 'password',
                    label: 'رمز عبور',
                    type: 'password',
                    placeholder: 'رمز عبور ارائه شده توسط پرووایدر'

                },
            ]
        },
        {
            name: 'url',
            label: 'آدرس API',
            type: 'text'
        },
        {
            name: 'token',
            label: 'توکن سرویس دهنده',
            type: 'text',
            placeholder: 'توکن ارائه شده در صورت نیاز',
        },
        {
            type: 'group',
            group: [
                {
                    name: 'rate_unit',
                    label: 'واحدنرخ ارسال',
                    type: 'select',
                    required: true,
                    options:
                        [
                            { value: "unlimited", label: 'نامحدود' },
                            { value: "per_second", label: 'در ثانیه' },
                            { value: "per_minute", label: 'در دقیقه' },
                            { value: "per_hour", label: 'در ساعت' },
                        ],
                },
                {
                    name: 'send_rate',
                    label: 'نرخ ارسال',
                    type: 'number',
                }
            ]
        },
        {
            name: 'is_active',
            label: 'این پروایدر فعال باشد',
            type: 'checkbox'
        }
    ]
}



