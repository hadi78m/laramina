@extends('layouts.mclsApp')

@section('content')

<div id="sms-providers-module"></div>

@endsection