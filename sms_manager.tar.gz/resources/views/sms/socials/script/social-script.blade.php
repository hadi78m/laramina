<script>
    let socialsTable;
    const socialJsonUrl = '{{ route('sms.socials.json') }}';
    const socialStoreUrl = '{{ route('sms.socials.store') }}';
    // Note: For edit, delete, etc., it's better to have a base URL.
    // We'll construct them dynamically for now.
    const socialsBaseUrl = '{{ url('sms/socials') }}';
    $(document).ready(function () {
        socialsTable = $('#socialsTable').DataTable({
            processing: true,
             "dom": 'Blfrtip', // نمایش دکمه‌ها
            "buttons": [{
                extend: 'copy',
                text: 'کپی',
                className: 'bg-gray-500 hover:bg-gray-600 text-white px-4 py-2 rounded-lg text-sm font-medium transition-colors duration-200'
            },
            {
                extend: 'excel',
                text: 'اکسل',
                className: 'bg-green-500 hover:bg-green-600 text-white px-4 py-2 rounded-lg text-sm font-medium transition-colors duration-200'
            },
            {
                extend: 'pdf',
                text: 'PDF',
                className: 'bg-red-500 hover:bg-red-600 text-white px-4 py-2 rounded-lg text-sm font-medium transition-colors duration-200'
            },
            {
                extend: 'print',
                text: 'چاپ',
                className: 'bg-blue-500 hover:bg-blue-600 text-white px-4 py-2 rounded-lg text-sm font-medium transition-colors duration-200'
            }
            ],
            ajax: '{{ route('sms.socials.json') }}',
            columns: [{
                data: 'id'
            },
            {
                data: 'name',
                render: data => `<span class="font-semibold">${data}</span>`
            },
            // {
            //     data: 'user',
            //     render: data => data ? data : '<span class="text-gray-400">تنظیم نشده</span>'
            // },
            {
                data: 'url',
                render: data => data ? `<code class="text-xs">${data}</code>` :
                    '<span class="text-gray-400">تنظیم نشده</span>'
            },
            {
                data: 'is_active',
                render: data => data ?
                    '<span class="px-3 py-1 bg-green-100 text-green-800 text-xs rounded-full">فعال</span>' :
                    '<span class="px-3 py-1 bg-red-100 text-red-800 text-xs rounded-full text-center">غیرفعال</span>'
            },
            {
                data: 'is_default',
                render: data => data ?
                    '<span class="px-3 py-1 bg-indigo-100 text-indigo-800 text-xs rounded-full font-bold">پیش‌فرض</span>' :
                    '<span class="text-gray-400 text-xs text-center">—</span>'
            },
            {
                data: 'created_at',

            },
            { data: 'send_rate', render: data => data ?? '<span class="text-gray-400">نامحدود</span>' },
            {
                data: 'rate_unit',
                render: (data => {
                    const units = { per_second: 'در ثانیه', per_minute: 'در دقیقه', per_hour: 'در ساعت', unlimited: 'نامحدود' };
                    return rowData => units[rowData] ?? rowData;
                })()
            },
            {
                data: null,
                orderable: false,
                searchable: false,
                render: data => `
                    <div class="flex gap-1" data-id="${data.id}">
                        <button class="px-3 py-1 bg-blue-500 text-white rounded hover:bg-blue-600 action-edit" title="ویرایش"><x-bi-list-check/></button>
                       @role('SuperAdmin')
                        <button class="px-3 py-1 bg-red-500 text-white rounded hover:bg-red-600 action-delete" title="حذف"><x-bi-trash-fill/></button>
                        @endrole
                        <button class="px-3 py-1 bg-teal-500 text-white rounded hover:bg-teal-600 action-test" title="تست اتصال"><x-bi-mouse3/></button>
                        <button class="px-3 py-1 bg-purple-500 text-white rounded hover:bg-purple-600 action-numbers" title="شماره‌ها"><i class="fas fa-phone"></i></button>
                    </div>`
            }
            ],
            order: [
                [0, 'desc']
            ],
            language: {
                url: "{{ asset('assets/lang/datatables/fa.json') }}"
            }
        });

        $('#addSocialForm').on('submit', function (e) {
            e.preventDefault();
            $('.error-name').addClass('hidden');
            $.ajax({
                url: socialStoreUrl,
                method: 'POST',
                data: $(this).serialize(),
                success: res => {
                    if (res.success) {
                        closeAddModal();
                        this.reset();
                        socialsTable.ajax.reload();
                        showSuccess(res.message);
                    }
                },
                error: xhr => {
                    if (xhr.responseJSON?.errors?.name) {
                        $('.error-name').text(xhr.responseJSON.errors.name[0]).removeClass(
                            'hidden');
                    } else {
                        showError(xhr.responseJSON?.message || 'خطا در ذخیره');
                    }
                }
            });
        });

        $('#editSocialForm').on('submit', function (e) {
            e.preventDefault();
            const id = $('#edit_social_id').val();
            $.ajax({
                url: `${socialsBaseUrl}/${id}`,
                method: 'PUT',
                data: $(this).serialize(),
                success: res => {
                    if (res.success) {
                        closeEditModal();
                        socialsTable.ajax.reload();
                        showSuccess(res.message);
                    }
                },
                error: xhr => showError(xhr.responseJSON?.message || 'خطا در بروزرسانی')
            });
        });
        $('#add_rate_unit, #edit_rate_unit').on('change', function () {
            const isUnlimited = $(this).val() === 'unlimited';
            $(this).closest('form').find('input[name="send_rate"]').prop('disabled', isUnlimited).val(isUnlimited ? '' : 10);
        });

        // Event Delegation for action buttons
        $('#socialsTable tbody').on('click', 'button', function () {
            const row = socialsTable.row($(this).closest('tr')).data();
            const id = row.id;

            if ($(this).hasClass('action-edit')) {
                editSocial(id);
            } else if ($(this).hasClass('action-delete')) {
                deleteSocial(id);
            } else if ($(this).hasClass('action-test')) {
                testConnection(id);
            }
        });
    });

    function openAddModal() {
        $('#addSocialModal').removeClass('hidden');
    }

    function closeAddModal() {
        $('#addSocialModal').addClass('hidden');
        $('#addSocialForm')[0].reset();
    }

    function openEditModal() {
        $('#editSocialModal').removeClass('hidden');
    }

    function closeEditModal() {
        $('#editSocialModal').addClass('hidden');
    }

    function editSocial(id) {
        
                $('#edit_social_id').val('');
                $('#edit_name').val('');
                $('#edit_user').val('');
                $('#edit_url').val('');
                $('#edit_is_active').prop('');
                $('#edit_is_default').prop('');
                $('#edit_send_rate').val('');
                $('#edit_token').val('');
                $('#edit_rate_unit').val('').trigger('change'); 

        // It's better to have a dedicated API endpoint like GET /sms/socials/{id}
        $.get(`${socialsBaseUrl}/${id}/edit`, res => {
            const social = res.social;
            if (social) {
                $('#edit_social_id').val(social.id);
                $('#edit_name').val(social.name);
                $('#edit_user').val(social.user || '');
                $('#edit_url').val(social.url || '');
                $('#edit_is_active').prop('checked', !!social.is_active);
                $('#edit_is_default').prop('checked', !!social.is_default);
                $('#edit_send_rate').val(social.send_rate);
                $('#edit_token').val(social.token);
                $('#edit_rate_unit').val(social.rate_unit).trigger('change'); // trigger change to update send_rate field
                openEditModal();
            } else {
                showError('ارائه‌دهنده یافت نشد.');
            }
        }).fail(() => showError('خطا در دریافت اطلاعات ارائه‌دهنده.'));
    }

    function setDefault(id) {
        Swal.fire({
            title: 'تغییر پیش‌فرض؟',
            text: 'این پروایدر پیش‌فرض می‌شود',
            icon: 'question',
            showCancelButton: true,
            confirmButtonText: 'بله',
            cancelButtonText: 'خیر'
        })
            .then(r => r.isConfirmed && $.post(`${socialsBaseUrl}/${id}/set-default`, {
                _token: $('meta[name="csrf-token"]').attr('content')
            }, res => {
                if (res.success) {
                    socialsTable.ajax.reload();
                    showSuccess(res.message);
                }
            }));
    }

    function deleteSocial(id) {
        Swal.fire({
            title: 'حذف؟',
            text: 'قابل بازگشت نیست!',
            icon: 'warning',
            showCancelButton: true,
            confirmButtonText: 'حذف',
            cancelButtonText: 'انصراف',
            confirmButtonColor: '#ef4444'
        })
            .then(r => r.isConfirmed && $.ajax({
                url: `${socialsBaseUrl}/${id}`,
                method: 'DELETE',
                data: {
                    _token: $('meta[name="csrf-token"]').attr('content')
                },
                success: res => {
                    socialsTable.ajax.reload();
                    showSuccess(res.message);
                }
            }));
    }

    function toggleStatus(id) {
        $.post(`${socialsBaseUrl}/${id}/toggle-status`, {
            _token: $('meta[name="csrf-token"]').attr('content')
        }, res => {
            if (res.success) {
                socialsTable.ajax.reload();
                showSuccess(res.message);
            } else showError(res.message);
        }).fail(xhr => showError(xhr.responseJSON?.message || 'خطا'));
    }

    function testConnection(id) {
        Swal.fire({
            title: 'در حال تست...',
            allowOutsideClick: false,
            didOpen: () => Swal.showLoading()
        });
        $.ajax({
            url: `${socialsBaseUrl}/${id}/test-connection`,
            method: 'POST',
            data: {
                _token: $('meta[name="csrf-token"]').attr('content')
            },
            success: res => res.success ?
                Swal.fire({
                    icon: 'success',
                    title: 'متصل شد!',
                    html: `<div class="text-right text-sm"><p><strong>پروایدر:</strong> ${res.social.name}</p><p><strong>زمان پاسخ:</strong> ${res.response_time}ms</p>${res.message ? `<p><strong>پیام:</strong> ${res.message}</p>` : ''}</div>`,
                    confirmButtonText: 'عالی!'
                }) : Swal.fire({
                    icon: 'error',
                    title: 'ناموفق',
                    text: res.message
                }),
            error: xhr => Swal.fire({
                icon: 'error',
                title: 'خطا',
                text: xhr.responseJSON?.message || 'مشکل در ارتباط',
                footer: xhr.status ? `<small>کد: ${xhr.status}</small>` : ''
            })
        });
    }


    // / Event Delegation جدید برای دکمه شماره‌ها
    $('#socialsTable tbody').on('click', '.action-numbers', function () {
        const row = socialsTable.row($(this).closest('tr')).data();
        manageNumbers(row.id);
    });

    function manageNumbers(socialId) {
        $('#current_social_id').val(socialId);
        loadNumbers(socialId);
        // نمایش مدال + لودینگ
        $('#manageNumbersModal').removeClass('hidden');
        $('#numbersLoading').removeClass('hidden');
        $('#numbersTable').addClass('hidden');           // مخفی کردن جدول تا لود کامل شود
        openNumbersModal();
    }

    function loadNumbers(socialId) {
        $.get(`${socialsBaseUrl}/${socialId}/numbers`, res => {
            if (res.success) {
                const tbody = $('#numbersTable tbody');
                tbody.empty();

                if (res.numbers.length === 0) {
                    tbody.append('<tr><td colspan="3" class="text-center py-4 text-gray-500">هیچ شماره‌ای ثبت نشده است</td></tr>');
                } else {
                    res.numbers.forEach(num => {
                        const status = num.is_active
                            ? '<span class="bg-green-100 text-green-800 px-2 py-1 rounded">فعال</span>'
                            : '<span class="bg-red-100 text-red-800 px-2 py-1 rounded">غیرفعال</span>';

                        tbody.append(`
                        <tr>
                            <td class="px-4 py-2">${num.number}</td>
                            <td class="px-4 py-2">${status}</td>
                            <td class="px-4 py-2 flex gap-2">
                                <button class="bg-yellow-500 text-white px-2 py-1 rounded toggle-status" data-id="${num.id}">تغییر وضعیت</button>
                                <button class="bg-red-500 text-white px-2 py-1 rounded delete-number" data-id="${num.id}">حذف</button>
                            </td>
                        </tr>
                    `);
                    });
                }

                // پایان لودینگ → نمایش جدول
                $('#numbersLoading').addClass('hidden');
                $('#numbersTable').removeClass('hidden');
            } else {
                showError('خطا در دریافت شماره‌ها');
                closeNumbersModal(); // یا مدیریت خطا به شکل دیگری
            }
        }).fail(() => {
            showError('خطا در ارتباط با سرور');
            $('#numbersLoading').addClass('hidden');
            closeNumbersModal();
        });
    }

    // هنگام بستن مدال (اختیاری - برای ریست کردن وضعیت)
    function closeNumbersModal() {
        $('#manageNumbersModal').addClass('hidden');
        $('#numbersLoading').addClass('hidden');
        $('#numbersTable').addClass('hidden');
        $('#numbersTable tbody').empty(); // پاک کردن لیست قبلی
    }
    // Submit فرم افزودن شماره
    $('#addNumberForm').on('submit', function (e) {
        e.preventDefault();
        const socialId = $('#current_social_id').val();
        $.ajax({
            url: `${socialsBaseUrl}/${socialId}/numbers`,
            method: 'POST',
            data: $(this).serialize(),
            success: res => {
                if (res.success) {
                    this.reset();
                    loadNumbers(socialId);
                    showSuccess(res.message);
                }
            },
            error: xhr => showError(xhr.responseJSON?.message || 'خطا در ذخیره شماره')
        });
    });

    // Toggle وضعیت
    $('#manageNumbersModal').on('click', '.toggle-status', function () {
        const numberId = $(this).data('id');
        const socialId = $('#current_social_id').val();
        $.post(`${socialsBaseUrl}/${socialId}/numbers/${numberId}/toggle`, { _token: $('meta[name="csrf-token"]').attr('content') }, res => {
            if (res.success) {
                loadNumbers(socialId);
                showSuccess(res.message);
            }
        });
    });

    // حذف شماره
    $('#manageNumbersModal').on('click', '.delete-number', function () {
        const numberId = $(this).data('id');
        const socialId = $('#current_social_id').val();
        Swal.fire({
            title: 'حذف شماره؟',
            text: 'قابل بازگشت نیست!',
            icon: 'warning',
            showCancelButton: true,
            confirmButtonText: 'حذف',
            cancelButtonText: 'انصراف'
        }).then(r => r.isConfirmed && $.ajax({
            url: `${socialsBaseUrl}/${socialId}/numbers/${numberId}`,
            method: 'DELETE',
            data: { _token: $('meta[name="csrf-token"]').attr('content') },
            success: res => {
                loadNumbers(socialId);
                showSuccess(res.message);
            }
        }));
    });

    function openNumbersModal() { $('#manageNumbersModal').removeClass('hidden'); }

    $('#addSocialModal, #editSocialModal').on('click', function (e) {
        if (e.target === this) {
            $(this).addClass('hidden');
        }
    });
    $(document).on('keydown', function (e) {
        if (e.key === 'Escape') {
            closeAddModal();
            closeEditModal();
        }
    });
</script>