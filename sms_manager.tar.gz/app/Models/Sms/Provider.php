<?php
// app/Models/Sms/Provider.php

namespace App\Models\Sms;

use App\AdminPlatform\Traits\AdminTableTrait;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\Crypt;

class Provider extends Model
{
    use AdminTableTrait;
    protected $table = 'providers';

    protected $fillable = [
        'name',
        'user',
        'password',
        'url',
        'is_default',
        'is_active',
        'created_by',
        'send_rate',
        'rate_unit',
        'token',
        'helper_name'
    ];

    protected $hidden = ['password'];

    protected $casts = [
        'is_default' => 'boolean',
        'is_active' => 'boolean',
    ];

    public function creator()
    {
        return $this->belongsTo(\App\Models\User::class, 'created_by');
    }

    // در فایل app/Models/Sms/Provider.php

    public function numbers()
    {
        // فرض بر این است که جدولی به نام provider_numbers ساخته‌اید
        return $this->hasMany(ProviderNumber::class, 'provider_id');
    }

    // متدی برای دریافت پروایدر پیش‌فرض (اگر در دیتابیس ست شده باشد)
    public static function getDefault()
    {
        return self::where('is_default', true)->where('is_active', true)->first();
    }
    // تنظیم پیش‌فرض + فقط پروایدرهای فعال قابل انتخاب باشند
    public static function setAsDefault($providerId)
    {
        $provider = static::findOrFail($providerId);

        if (!$provider->is_active) {
            throw new \Exception('پروایدر غیرفعال نمی‌تواند پیش‌فرض باشد.');
        }

      $data =  static::query()->update(['is_default' => false]);
      $data =  static::where('id', $providerId)->update(['is_default' => true]);

      return $data;
    }

    // تغییر وضعیت فعال/غیرفعال
    public function toggleStatus()
    {
        if ($this->is_default && $this->is_active) {
            // اگر پیش‌فرض بود و می‌خوایم غیرفعالش کنیم → مجاز نیست
            throw new \Exception('پروایدر پیش‌فرض را نمی‌توان غیرفعال کرد.');
        }

        $this->is_active = !$this->is_active;
        $this->save();
    }

     public static function adminTransform($cred)
    {
        return [
            'id' => $cred->id,
            'name' => $cred->name,
            'user' => $cred->user,
            'password' => $cred->password ? Crypt::decrypt($cred->password) : null,
            'is_active' => $cred->is_active,
            'is_default' => $cred->is_default,
            'rate_unit' => $cred->rate_unit,
            'url' => $cred->url,
            'send_rate' => $cred->send_rate,
            'token'=>$cred->token,
            'helper_name'=>$cred->helper_name,

            'created_at' => "<div dir='ltr' class='text-center'>" .
                (verta($cred->created_at)->format('Y/m/d') ?? '') .
                "</div>",
        ];
    }
    
}
