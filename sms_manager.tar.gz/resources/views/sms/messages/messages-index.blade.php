@extends('layouts.mclsApp')

@section('content')
    <x-elements.sidebar>
        <x-sidebars.sms />
    </x-elements.sidebar>
    @role('SuperAdmin')
    <div class="container mx-auto px-4 py-8">
        <!-- آمار -->
        <div class="grid grid-cols-1 md:grid-cols-5 gap-4 mb-6">
            <div class="bg-gradient-to-br from-blue-500 to-blue-600 text-white rounded-xl shadow-lg p-6">
                <div class="flex items-center justify-between">
                    <div>
                        <p class="text-blue-100 text-sm mb-1">کل پیام‌ها</p>
                        <h2 id="stat-total" class="text-3xl font-bold">0</h2>
                    </div>
                    <div class="bg-blue-400 bg-opacity-30 w-14 h-14 rounded-full flex items-center justify-center">
                        <i class="fas fa-envelope text-2xl"></i>
                    </div>
                </div>
            </div>

            <div class="bg-gradient-to-br from-yellow-500 to-orange-500 text-white rounded-xl shadow-lg p-6">
                <div class="flex items-center justify-between">
                    <div>
                        <p class="text-yellow-100 text-sm mb-1">در انتظار</p>
                        <h2 id="stat-pending" class="text-3xl font-bold">0</h2>
                    </div>
                    <div class="bg-yellow-400 bg-opacity-30 w-14 h-14 rounded-full flex items-center justify-center">
                        <i class="fas fa-clock text-2xl"></i>
                    </div>
                </div>
            </div>

            <div class="bg-gradient-to-br from-green-500 to-emerald-600 text-white rounded-xl shadow-lg p-6">
                <div class="flex items-center justify-between">
                    <div>
                        <p class="text-green-100 text-sm mb-1">ارسال شده</p>
                        <h2 id="stat-sent" class="text-3xl font-bold">0</h2>
                    </div>
                    <div class="bg-green-400 bg-opacity-30 w-14 h-14 rounded-full flex items-center justify-center">
                        <i class="fas fa-check-circle text-2xl"></i>
                    </div>
                </div>
            </div>

            <div class="bg-gradient-to-br from-red-500 to-pink-600 text-white rounded-xl shadow-lg p-6">
                <div class="flex items-center justify-between">
                    <div>
                        <p class="text-red-100 text-sm mb-1">مسدود شده</p>
                        <h2 id="stat-blocked" class="text-3xl font-bold">0</h2>
                    </div>
                    <div class="bg-red-400 bg-opacity-30 w-14 h-14 rounded-full flex items-center justify-center">
                        <i class="fas fa-filter text-2xl"></i>
                    </div>
                </div>
            </div>
            <div class="bg-gradient-to-br from-gray-500 to-gray-700 text-white rounded-xl shadow-lg p-6">
                <div class="flex items-center justify-between">
                    <div>
                        <p class="text-red-100 text-sm mb-1">ارسال نشده</p>
                        <h2 id="stat-failed" class="text-3xl font-bold">0</h2>
                    </div>
                    <div class="bg-red-500 bg-opacity-30 w-14 h-14 rounded-full flex items-center justify-center">
                        <i class="fas fa-ban text-2xl"></i>
                    </div>
                </div>
            </div>
        </div>

        <!-- فیلترها -->
        <div class="bg-white rounded-lg shadow-lg p-6 mb-6">
            <h4 class="text-lg font-bold text-gray-800 mb-4 flex items-center gap-2">
                <i class="fas fa-filter text-purple-600"></i>
                فیلترهای جستجو
            </h4>
            <div class="grid grid-cols-1 md:grid-cols-5 gap-4">
                <div>
                    <label class="block text-sm font-semibold text-gray-700 mb-2">اعتبارنامه</label>
                    <select id="filter-credential" class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent transition-all">
                        <option value="">همه</option>
                        @foreach($credentials as $credential)
                            <option value="{{ $credential->id }}">
                                {{ $credential->name }} ({{ $credential->username }})
                            </option>
                        @endforeach
                    </select>
                </div>

                <div>
                    <label class="block text-sm font-semibold text-gray-700 mb-2">وضعیت</label>
                    <select id="filter-status" class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent transition-all">
                        <option value="">همه</option>
                        <option value="pending">در انتظار</option>
                        <option value="sent">ارسال شده</option>
                        <option value="blocked">مسدود شده</option>
                        <option value="failed">خطا</option>
                    </select>
                </div>

                <div>
                    <label class="block text-sm font-semibold text-gray-700 mb-2">از تاریخ</label>
                    <input type="text" id="filter-date-from" class="datedown w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent transition-all">
                </div>

                <div>
                    <label class="block text-sm font-semibold text-gray-700 mb-2">تا تاریخ</label>
                    <input type="text" id="filter-date-to" class="datetop w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent transition-all">
                </div>

                <div class="flex items-end">
                    <button type="button" id="btn-filter" class="w-full px-4 py-2 bg-gradient-to-r from-purple-600 to-pink-600 text-white rounded-lg hover:from-purple-700 hover:to-pink-700 transition-all font-semibold flex items-center justify-center gap-2">
                        <i class="fas fa-filter"></i>
                        اعمال فیلتر
                    </button>
                </div>
            </div>
        </div>

        <!-- لیست پیام‌ها -->
        <div class="bg-white rounded-lg shadow-lg overflow-hidden">
            <div class="bg-gradient-to-r from-indigo-600 to-purple-600 text-white px-6 py-4">
                <h3 class="text-xl font-bold">لیست پیام‌های ارسالی</h3>
            </div>

            <div class="p-6">
                <div class="overflow-x-auto">
                    <table id="messagesTable" class="w-full">
                        <thead>
                            <tr class="bg-gray-50">
                                {{-- <th class="px-4 py-3 text-right text-sm font-semibold text-gray-700">شناسه</th> --}}
                                <th class="px-4 py-3 text-right text-sm font-semibold text-gray-700">فرستنده</th>
                                {{-- <th class="px-4 py-3 text-right text-sm font-semibold text-gray-700">نام کاربری</th> --}}
                                <th class="px-4 py-3 text-right text-sm font-semibold text-gray-700">گیرنده</th>
                                <th class="px-4 py-3 text-right text-sm font-semibold text-gray-700">پیام</th>
                                <th class="px-4 py-3 text-right text-sm font-semibold text-gray-700">نوع</th>
                                <th class="px-4 py-3 text-right text-sm font-semibold text-gray-700">وضعیت</th>
                                <th class="px-4 py-3 text-right text-sm font-semibold text-gray-700">کلمات غیرمجاز</th>
                                <th class="px-4 py-3 text-right text-sm font-semibold text-gray-700">تاریخ ایجاد</th>
                                <th class="px-4 py-3 text-right text-sm font-semibold text-gray-700">تاریخ ارسال</th>
                                <th class="px-4 py-3 text-right text-sm font-semibold text-gray-700">عملیات</th>
                            </tr>
                        </thead>
                        <tbody></tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <!-- Modal جزئیات پیام -->
    <div id="messageDetailsModal" class="hidden fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center p-4">
        <div class="bg-white rounded-xl shadow-2xl w-full max-w-2xl transform transition-all max-h-[90vh] overflow-y-auto">
            <div class="bg-gradient-to-r from-indigo-600 to-purple-600 text-white px-6 py-4 rounded-t-xl flex justify-between items-center sticky top-0">
                <h5 class="text-lg font-bold">جزئیات پیام</h5>
                <button onclick="closeDetailsModal()" class="text-white hover:text-gray-200 transition-colors">
                    <i class="fas fa-times text-xl"></i>
                </button>
            </div>
            
            <div id="message-details-content" class="p-6">
                <!-- محتوا با جاوااسکریپت پر می‌شود -->
            </div>
        </div>
    </div>
@endrole
 


@endsection
@section('scripts')
  @include('sms.messages.script.messages-script')
@endsection
