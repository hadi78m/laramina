import { createForm } from './forms/create-form.js'
import { createPhone } from './forms/providerPhoneForm.js'
import { providerActions } from './actions.js'

const publicLang = AdminLang.getNamespace('common');

export default {
    title: 'Sms Providers',
    endpoint: 'sms.providers.json',
    search: true,

    headerTitle: 'مدیریت پرووایدرها',
    addButtonLabel: 'افزودن پروایدر جدید',
    displayButton: true,

    // تنظیمات مودال
    modalTheme: 'light',
    modals: {

        create: {
            title: 'افزودن پرووایدر',
            width: '500px',
            form: createForm
        },
        edit: {                     // ← افزودن این بخش
            title: 'ویرایش پرووایدر',
            width: '500px',
            form: createForm        // همان فرم که برای اضافه کردن استفاده می‌کنیم
        },
        addPhone: {
            title: 'افزودن شماره',
            width: '400px',
            form: createPhone
        }
    },

    actions: providerActions,
    // فیلتر 
    filters: [

        {
            key: 'is_active',
            label: publicLang.is_active,
            type: 'select',
            options: {
                1: publicLang.active,
                0: publicLang.inactive,
            }
        },
        {
            key: 'is_default',
            label: publicLang.is_default,
            type: 'select',
            options:
            {
                1: publicLang.is_default,
                0: publicLang.indefault,
            }
        },
        // {
        //     key: 'is_default',
        //     label: 'وضعیت پیش فرض',
        //     type: 'select',
        //     options: {
        //         1: 'پیش فرض',
        //         0: 'غیر پیش فرض'
        //     }
        // },

    ],

    // آیتم های جدول
    columns: [
        // { key: 'id', label: 'شناسه', sortable: true },
        { key: 'name', label: 'نام', sortable: true },
        { key: 'send_rate', label: 'نرخ ارسال', sortable: true },
        // { key: 'url', label: 'آدرس' },
        {
            key: 'rate_unit',
            label: 'واحد نرخ',
            type: 'badge',
            map: {
                per_second: { label: 'در ثانیه', color: 'gray' },
                per_minuts: { label: 'در دقیقه', color: 'blue' },
                per_hour: { label: 'در ساعت', color: 'purple' },
                unlimited: { label: 'نامحدود', color: 'green' },
            }
        },
        // { key: 'created_at', label: 'تاریخ ساخت', sortable: true },
        {
            key: 'is_default',
            label: 'پیش‌فرض',
            type: 'action-toggle',
            confirmTitle: 'تغییر مقدار پیش‌فرض؟',
            endpoint: 'sms.providers.set-default',
            map: {
                true: { label: 'پیش‌فرض', color: 'green' },
                false: { label: 'انتخاب', color: 'gray' }
            }
        },
        {
            key: 'is_active',
            label: 'فعال',
            type: 'action-toggle',
            endpoint: 'sms.providers.toggle-status',
            confirmTitle: 'تغییر وضعیت فعال؟',
            map: {
                true: { label: 'فعال', color: 'green' },
                false: { label: 'غیرفعال', color: 'gray' }
            },
            icons: {
                true: { html: '<i class="fa-solid fa-toggle-on  text-lg"></i>', color: 'green' },
                false: { html: '<i class="fa-solid fa-toggle-off  text-lg"></i>', color: 'red' }
            }
        }
        ,

        { key: 'helper_name', label: 'نام هلپر', },
        {
            key: 'helper_name', label: 'ساخت هلپر',
            // role: ['SuperAdmin'],
            type: 'actions',
            visible: row => !row.helper_name,
            'actions': ['createHelper'],
        },
        {
            label: 'عملیات',
            type: 'actions',
            actions: ['edit', 'delete', 'numbers', 'testConnection']
        }
    ],
    // تعداد هر آیتم در جدول  برای pagination
    perPage: 10
};




