<?php

namespace App\Services\Sms;

use App\Helpers\RightelHelper;
use App\Helpers\SociallHelper;
use App\Models\Sms\Social;
use App\Models\Sms\Message; // فرض بر این است که در جایی استفاده می‌شود
use GuzzleHttp\Client;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\RateLimiter;
use RuntimeException;

class SocialSenderService
{
    protected Social $Social;
    protected Client $client;

    // تعریف متغیرهای خصوصی برای وضعیت OTP
    protected bool $isOtp = false;


    /**
     * سازنده سرویس ارسال پیامک.
     * Social باید در زمان نمونه‌سازی تزریق شود.
     */
    public function __construct(?Social $Social = null)
    {

        $this->Social = $Social;


        $this->client = new Client();
    }

    /**
     * ارسال پیامک با رعایت محدودیت‌های Rate Limiter
     */
    public function sendToSocial(string $recipient, string $message): array
    {
        if (!isset($this->Social)) {
            throw new RuntimeException("Social not set on SocialSenderService instance.");
        }

        if ($this->Social->rate_unit === 'unlimited') {
            // مستقیم ارسال بدون RateLimiter
            return $this->executeSendRequest($recipient, $message);
        }

        $key = "sms_Social_{$this->Social->id}";

        // اجرای درخواست فقط اگر RateLimiter اجازه بده
        $executed = RateLimiter::attempt(
            key: $key,
            maxAttempts: 1,
            callback: function () use ($recipient, $message) {
                return $this->executeSendRequest($recipient, $message);
            },
            decaySeconds: 60 // این مقدار باید بر اساس تنظیمات Rate Unit Social تنظیم شود
        );


        if ($executed === false) { // RateLimiter::attempt در صورت محدودیت false برمی‌گرداند
            Log::warning("Rate limit exceeded for Social {$this->Social->name} (ID: {$this->Social->id})");

            return [
                'success' => false,
                'error' => 'Rate limit exceeded. Please try again later.',
                'gateway_id' => null,
            ];
        }

        // $executed نتیجه callback است (یعنی نتیجه ارسال واقعی)
        return $executed;
    }

    /**
     * اجرای واقعی درخواست ارسال پیامک به پیام رسان
     */
    private function executeSendRequest(string $recipient, string $message): array
    {
        // متغیرهای $this->isOtp اکنون تعریف شده‌اند و قابل استفاده هستند
        $result = SociallHelper::send(
            $recipient,
            $message,
            $this->Social,
            $this->isOtp,
        );

        return [
            'success'    => $result['status'] === 'success',
            'gateway_id' => $result['message_id'] ?? null,
            'error'      => $result['status'] === 'error' ? $result['description'] : null,
        ];
    }

    /**
     * متد اصلی ارسال برای استفاده عمومی.
     * فرض می‌شود پارامترهای OTP (در صورت لزوم) قبل از این فراخوانی تنظیم شده‌اند.
     */
    public function send(string $recipient, string $message): array
    {
        return $this->sendToSocial($recipient, $message);
    }

    /**
     * تنظیم Social روی نمونه سرویس موجود (برای استفاده در Jobها پس از DI)
     */
    public function setSocial(Social $Social): self
    {
        $this->Social = $Social;
        return $this;
    }

    /**
     * تنظیم پارامترهای OTP برای استفاده در فراخوانی بعدی send.
     */
    public function setOtpParameters(bool $isOtp): self
    {
        $this->isOtp = $isOtp;
        return $this;
    }
}
