<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;

class Headers
{
    /**
     * Handle an incoming request.
     *
     * @param  \Closure(\Illuminate\Http\Request): (\Symfony\Component\HttpFoundation\Response)  $next
     */
    public function handle(Request $request, Closure $next): Response
    {

        $userInput = $request->all();
        array_walk_recursive($userInput, function (&$userInput) {
            $userInput = strip_tags($userInput);
        });
        $request->merge($userInput);


        $response = $next($request);
        $response->headers->set('Content-Security-Policy', "default-src 'self'; font-src *;img-src * data:; script-src * 'unsafe-inline' 'unsafe-eval'; style-src * 'unsafe-inline';");
        $response->headers->set('Strict-Transport-Security', "max-age=31536000; includeSubDomains; preload");
        $response->headers->set('X-XSS-Protection', "1; mode=block");
        $response->headers->set('Referrer-Policy', "strict-origin");
        $response->headers->set('X-Content-Type-Options', "nosniff");
        $response->headers->set('X-Frame-Options', "SAMEORIGIN");
        $response->headers->set('Strict-Transport-Security', 'max-age= 31536000; includeSubdomains');
        $response->headers->set('Access-Control-Allow-Origin', '*');
        $response->headers->set('Access-Control-Allow-Headers', '*');
        $response->headers->set('Content-Type', 'application/javascript');
        $response->headers->set('Cache-Control', 'no-store,no-cache, must-revalidate, post-check=0, pre-check=0');
        $response->headers->set('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');


        return $response;
    }
}
