{{-- Admin Platform full --}}
<div id="app"></div>

{{-- Admin Platform --}}
<script type="module" src="{{ asset('js/admin-platform/bootstrap/admin-platform.js') }}">
</script>

{{-- ارسال role کاربر به JS برای admin-platform --}}
@php
    $user = auth()->user();
    $roles = [];
    $permissions = [];
    if ($user) {
        if (method_exists($user, 'roles')) {
            $roles = $user->roles->pluck('name')->toArray();
        }
        if (method_exists($user, 'getAllPermissions')) {
            $permissions = $user->getAllPermissions()->pluck('name')->toArray();
        }
    }
@endphp

<script>
    window.AdminUser = {
        roles: @json($roles),
        permissions: @json($permissions)
    };
</script>


{{-- 1️⃣ ساخت route export در Laravel برای admin-platform --}}

<script>
    window.LaravelRoutes = @json(
        collect(Route::getRoutes())->mapWithKeys(function ($route) {
            if ($name = $route->getName()) {
                return [$name => url($route->uri())];
            }
            return [];
        })
    );
</script>

{{-- تزریق ترجمه زبان --}}

<script>
    window.AdminLang = window.AdminLang || {};
    window.AdminLang.locale = "{{ app()->getLocale() }}";

    /* اگر یک زبان داریم */
    // window.AdminLang.messages = @json(trans('adminUI'));
    /*  اگر چند زبان داشته باشیم  */
    window.AdminLang.messages = {
        "fa": @json(trans('adminUI', [], 'fa')),
        "en": @json(trans('adminUI', [], 'en')),
    };
</script>



<script type="module" src="{{ asset('js/admin-platform/admin-lang.js') }}">
</script>