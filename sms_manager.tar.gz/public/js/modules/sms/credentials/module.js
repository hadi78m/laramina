import tableConfig from './table.js'

export default {
    name: 'sms.credentials',

    table: tableConfig,

    init() {
        console.log('sms.credentials module loaded')
    }
}