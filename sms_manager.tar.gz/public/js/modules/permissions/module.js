import tableConfig from './table.js'

export default {
    name: 'manage.permissions',

    table: tableConfig,

    init() {
        console.log('manage.permissions module loaded')
    }
}