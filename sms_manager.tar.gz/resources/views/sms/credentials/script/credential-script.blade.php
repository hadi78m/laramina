<script>
    let credentialsTable;

    $(document).ready(function () {
        console.log('صفحه بارگذاری شد');
        // Initialize DataTable
        credentialsTable = $('#credentialsTable').DataTable({
            processing: true,
            "dom": 'Blfrtip', // نمایش دکمه‌ها
            ajax: {
                url: '{{ route('sms.credentials.json') }}',
                "buttons": [{
                    extend: 'copy',
                    text: 'کپی',
                    className: 'bg-gray-500 hover:bg-gray-600 text-white px-4 py-2 rounded-lg text-sm font-medium transition-colors duration-200'
                },
                {
                    extend: 'excel',
                    text: 'اکسل',
                    className: 'bg-green-500 hover:bg-green-600 text-white px-4 py-2 rounded-lg text-sm font-medium transition-colors duration-200'
                },
                {
                    extend: 'pdf',
                    text: 'PDF',
                    className: 'bg-red-500 hover:bg-red-600 text-white px-4 py-2 rounded-lg text-sm font-medium transition-colors duration-200'
                },
                {
                    extend: 'print',
                    text: 'چاپ',
                    className: 'bg-blue-500 hover:bg-blue-600 text-white px-4 py-2 rounded-lg text-sm font-medium transition-colors duration-200'
                }
                ],
            },
            columns: [
                { data: 'id' },
                { data: 'name' },
                { data: 'website' },
                {
                    data: 'token_status',
                    render: function (data) {
                        if (data === 'فعال') {
                            return '<span class="px-3 py-1 bg-green-100 text-green-800 rounded-full text-xs">فعال</span>';
                        }
                        return '<span class="px-3 py-1 bg-red-100 text-red-800 rounded-full text-xs">منقضی/ندارد</span>';
                    }
                },
                {
                    data: 'token_type',
                    render: function (data) {
                        if (data === 'static') return '<span class="px-2 py-1 bg-purple-100 text-purple-800 rounded-full text-xs">Static</span>';
                        if (data === 'dynamic') return '<span class="px-2 py-1 bg-indigo-100 text-indigo-800 rounded-full text-xs">Dynamic</span>';
                        return '<span class="px-2 py-1 bg-gray-100 text-gray-800 rounded-full text-xs">None</span>';
                    }
                },
                {
                    data: null,
                    title: 'توکن استاتیک',
                    render: function (data, type, row) {
                        if (row.static_token_exists) {  // این فیلد را در JSON اضافه کنید
                            return `<button onclick="fetchStaticToken(${row.id})" class="px-2 py-1 bg-blue-500 text-white rounded text-sm" title="نمایش توکن">
                        <i class="fas fa-eye"></i> کپی و نمایش توکن
                    </button>`;
                        }
                        return '<span class="text-gray-400 italic text-sm">ندارد</span>';
                    }
                },
                {
                    data: 'allowed_ip',
                    render: function (data) {
                        return data ? `<span class="text-green-700">${data}</span>` : '<span class="text-gray-400">بدون محدودیت</span>';
                    }
                },
                { data: 'last_token_expires_at' },
                {
                    data: 'is_active',
                    render: function (data) {
                        return data ? '<span class="px-3 py-1 bg-green-100 text-green-800 rounded-full text-xs">فعال</span>'
                            : '<span class="px-3 py-1 bg-red-100 text-red-800 rounded-full text-xs">غیرفعال</span>';
                    }
                },
                { data: 'daily_limit' },
                { data: 'messages_sent_today' },
                {
                    data: null,
                    render: function (data) {
                        let btns = `
                    <button onclick="editCredential(${data.id})" class="px-2 py-1 bg-blue-500 text-white rounded text-sm" title="ویرایش">
                        <i class="fas fa-edit"></i>
                    </button>
                `;

                        // دکمه وضعیت
                        btns += data.is_active ?
                            `<button onclick="toggleStatus(${data.id})" class="px-2 py-1 bg-orange-500 text-white rounded text-sm ml-1" title="غیرفعال">
                        <i class="fas fa-ban"></i>
                    </button>` :
                            `<button onclick="toggleStatus(${data.id})" class="px-2 py-1 bg-green-500 text-white rounded text-sm ml-1" title="فعال">
                        <i class="fas fa-check"></i>
                    </button>`;

                        // دکمه‌های توکن
                        if (data.active_tokens_count === 0 || data.token_type !== 'static') {
                            btns += `<button onclick="createStaticToken(${data.id})" class="px-2 py-1 bg-purple-600 text-white rounded text-sm ml-1" title="ایجاد توکن استاتیک">
                        <i class="fas fa-key"></i>
                    </button>`;
                        } else {
                            btns += `<button onclick="regenerateStaticToken(${data.id})" class="px-2 py-1 bg-yellow-500 text-white rounded text-sm ml-1" title="بازسازی توکن استاتیک">
                        <i class="fas fa-sync"></i>
                    </button>`;
                            btns += `<button onclick="extendToken(${data.id})" class="px-2 py-1 bg-indigo-500 text-white rounded text-sm ml-1" title="تمدید انقضای توکن">
                        <i class="fas fa-clock"></i>
                    </button>`;
                        }

                        btns += `<button onclick="deleteCredential(${data.id})" class="px-2 py-1 bg-red-500 text-white rounded text-sm ml-1" title="حذف">
                    <i class="fas fa-trash"></i>
                </button>`;

                        return `<div class="flex flex-wrap gap-1 justify-center">${btns}</div>`;
                    }
                }
            ],
            order: [
                [0, 'desc']
            ],
            language: {
                "url": "{{ asset('assets/lang/datatables/fa.json') }}"
            }
        });

        // Add Credential Form
        $('#addCredentialForm').on('submit', function (e) {
            e.preventDefault();
            console.log('فرم ارسال شد');

            // Clear previous errors
            $('.error-name, .error-website, .error-password').addClass('hidden');
            $('input').removeClass('border-red-500');

            const formData = $(this).serialize();

            $.ajax({
                url: '{{ route('sms.credentials.store') }}',
                method: 'POST',
                data: formData,
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                },
                success: function (response) {
                    console.log('پاسخ موفق:', response);
                    if (response.success) {
                        closeAddModal();
                        $('#addCredentialForm')[0].reset();
                        credentialsTable.ajax.reload();
                        showSuccess(response.message);

                    }
                },
                error: function (xhr) {
                    console.log('خطا:', xhr);
                    const response = xhr.responseJSON;
                    if (response.errors) {
                        $.each(response.errors, function (prefix, val) {
                            showError('', val[0])
                        });
                    } else {
                        showError(response.message || 'خطایی رخ داده است');

                    }
                }
            });
        });

        // Edit Credential Form
        $('#editCredentialForm').on('submit', function (e) {
            e.preventDefault();

            const credentialId = $('#edit_credential_id').val();
            const formData = $(this).serialize();

            $.ajax({
                url: `/sms/credentials/${credentialId}`,
                method: 'PUT',
                data: formData,
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                },
                success: function (response) {
                    alert(response.success);
                    if (response.success) {
                        closeEditModal();
                        credentialsTable.ajax.reload();

                        showSuccess(response.message);
                    }
                },
                error: function (xhr) {
                    const response = xhr.responseJSON;
                    if (response.errors) {
                        $.each(response.errors, function (prefix, val) {
                            showError('', val[0])
                        });
                    } else {
                        showError(response.message || 'خطایی رخ داده است');

                    }
                }
            });
        });
    });

    function openAddModal() {
        console.log('باز کردن مودال افزودن');
        document.getElementById('addCredentialModal').classList.remove('hidden');
    }

    function showStaticToken(id, token, expires) {
        $('#staticTokenText').val(token);
        $('#tokenExpiresInfo').text('انقضا: ' + expires);
        document.getElementById('showStaticTokenModal').classList.remove('hidden');
    }

    function copyStaticToken() {
        const tokenField = document.getElementById('staticTokenText');
        const textToCopy = tokenField.value.trim();

        if (!textToCopy) {
            Swal.fire('خطا', 'هیچ متنی برای کپی وجود ندارد', 'warning');
            return;
        }

        // چک امنیت و پشتیبانی مرورگر
        if (!navigator || !navigator.clipboard || typeof navigator.clipboard.writeText !== 'function') {
            fallbackCopy(textToCopy);
            return;
        }

        navigator.clipboard.writeText(textToCopy)
            .then(() => {
                Swal.fire({
                    icon: 'success',
                    title: 'کپی شد',
                    text: 'توکن در کلیپ‌بورد قرار گرفت',
                    timer: 1500,
                    showConfirmButton: false
                });
            })
            .catch(err => {
                console.error('Clipboard API error:', err);
                fallbackCopy(textToCopy);
            });
    }

    // روش fallback قدیمی (برای مرورگرهای قدیمی یا http)
    function fallbackCopy(text) {
        const textArea = document.createElement('textarea');
        textArea.value = text;
        textArea.style.position = 'fixed';
        textArea.style.opacity = '0';
        document.body.appendChild(textArea);
        textArea.focus();
        textArea.select();

        try {
            const successful = document.execCommand('copy');
            if (successful) {
                Swal.fire('', 'توکن کپی گردید', 'success');
            } else {
                Swal.fire('خطا', 'کپی خودکار انجام نشد - لطفاً دستی انتخاب و کپی کنید', 'error');
            }
        } catch (err) {
            Swal.fire('خطا', 'کپی انجام نشد', 'error');
        }

        document.body.removeChild(textArea);
    }

    function closeStaticTokenModal() {
        document.getElementById('showStaticTokenModal').classList.add('hidden');
        $('#staticTokenText').val('');
    }

    function createStaticToken(id) {
        Swal.fire({
            title: 'ایجاد توکن استاتیک',
            text: 'توکن قبلی (در صورت وجود) غیرفعال می‌شود. ادامه می‌دهید؟',
            icon: 'question',
            showCancelButton: true,
            confirmButtonText: 'بله، ایجاد کن',
            cancelButtonText: 'انصراف'
        }).then(result => {
            if (result.isConfirmed) {
                $.ajax({
                    url: `/sms/credentials/${id}/create-token`,
                    method: 'POST',
                    headers: { 'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content') },
                    success: response => {
                        if (response.success) {
                            credentialsTable.ajax.reload(null, false);
                            showStaticToken(id, response.token, response.expires_at);
                            Swal.fire('موفق', 'توکن استاتیک ایجاد شد', 'success');
                        } else {
                            Swal.fire('خطا', response.message || 'عملیات ناموفق', 'error');
                        }
                    },
                    error: () => Swal.fire('خطا', 'ارتباط با سرور برقرار نشد', 'error')
                });
            }
        });
    }

    function regenerateStaticToken(id) {
        createStaticToken(id); // همان منطق ایجاد مجدد
    }

    function createToken(id) {
        regenerateToken(id); // همان regenerate استفاده شود برای ایجاد جدید
    }

    function regenerateToken(id) {
        $.ajax({
            url: `/sms/credentials/${id}/create-token`,
            method: 'POST',
            headers: { 'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content') },
            success: function (response) {
                if (response.success) {
                    $('#tokenText').val(response.token);
                    openTokenModal();
                    credentialsTable.ajax.reload();
                    showSuccess('توکن جدید ایجاد شد');
                }
            },
            error: function () {
                showError('خطا در ایجاد توکن');
            }
        });
    }

    function extendToken(id) {
        $.ajax({
            url: `/sms/credentials/${id}/extend-token`,
            method: 'POST',
            headers: { 'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content') },
            success: function (response) {
                if (response.success) {
                    credentialsTable.ajax.reload();
                    showSuccess('توکن تمدید شد تا ' + response.expires_at);
                }
            },
            error: function () {
                showError('خطا در تمدید توکن');
            }
        });
    }


    function fetchStaticToken(id) {
        $.ajax({
            url: `/sms/credentials/${id}/get-static-token`,
            method: 'GET',
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content'),
                'Accept': 'application/json'
            },
            success: function (response) {
                if (response.success) {
                    $('#staticTokenText').val(response.token);
                    $('#tokenExpiresInfo').text('انقضا: ' + response.expires_at);
                    document.getElementById('showStaticTokenModal').classList.remove('hidden');
                } else {
                    Swal.fire({
                        icon: 'error',
                        title: 'خطا',
                        text: response.message || 'توکن یافت نشد',
                    });
                }
            },
            error: function (xhr) {
                let msg = 'خطا در دریافت توکن';
                if (xhr.status === 403) msg = 'دسترسی مجاز نیست';
                if (xhr.status === 404) msg = 'توکن استاتیک وجود ندارد';
                Swal.fire('خطا', msg, 'error');
            }
        });
    }
    function openTokenModal() {
        document.getElementById('showTokenModal').classList.remove('hidden');
    }

    function closeTokenModal() {
        document.getElementById('showTokenModal').classList.add('hidden');
    }

    function copyTokenFromModal() {
        const token = $('#tokenText').val();
        copyToken(token); // از function copyToken موجود استفاده کن
    }

    function closeAddModal() {
        console.log('بستن مودال افزودن');
        document.getElementById('addCredentialModal').classList.add('hidden');
        $('#addCredentialForm')[0].reset();
        $('.error-name, .error-website, .error-password').addClass('hidden');
        $('input').removeClass('border-red-500');
    }

    function openEditModal() {
        document.getElementById('editCredentialModal').classList.remove('hidden');
    }

    function closeEditModal() {
        document.getElementById('editCredentialModal').classList.add('hidden');
        $('#editCredentialForm')[0].reset();
    }

    function editCredential(id) {
        $.ajax({
            // url: "{{ route('sms.credentials.json', ['id' => '5']) }}",
            url: `/sms/credentials/${id}/edit`,
            method: 'GET',
            success: function (response) {
                const credential = response.data.find(c => c.id === id);

                if (credential) {
                    $('#edit_credential_id').val(credential.id);
                    $('#edit_name').val(credential.name);
                    $('#edit_website').val(credential.website);
                    $('#edit_daily_limit').val(credential.daily_limit);
                    $('#edit_description').val(credential.description);
                    $('#edit_is_active').val(credential.is_active ? '1' : '0');
                    $('#edit_allowed_ip').val(credential.allowed_ip || '');
                    openEditModal();
                }
            }
        });
    }

    function toggleStatus(id) {
        $.ajax({
            url: `/sms/credentials/${id}/toggle-status`,
            method: 'POST',
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            },
            success: function (response) {
                if (response.success) {
                    credentialsTable.ajax.reload();

                    showSuccess(response.message);
                }
            }
        });
    }

    function deleteCredential(id) {
        Swal.fire({
            title: 'اطمینان دارید؟',
            text: 'این اعتبارنامه حذف خواهد شد',
            icon: 'warning',
            showCancelButton: true,
            confirmButtonText: 'بله، حذف کن',
            cancelButtonText: 'انصراف',
            confirmButtonColor: '#ef4444'
        }).then((result) => {
            if (result.isConfirmed) {
                $.ajax({
                    url: `/sms/credentials/${id}`,
                    method: 'DELETE',
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    },
                    success: function (response) {
                        if (response.success) {
                            credentialsTable.ajax.reload();
                            showSuccess(response.message);

                        }
                    }
                });
            }
        });
    }

    function copyToken(token) {
        if (navigator.clipboard && navigator.clipboard.writeText) {
            navigator.clipboard.writeText(token).then(() => {
                showSuccess('توکن در کلیپبورد کپی شد');
            });
        } else {
            // Fallback for older browsers
            const textArea = document.createElement('textarea');
            textArea.value = token;
            textArea.style.position = 'fixed';
            textArea.style.left = '-999999px';
            document.body.appendChild(textArea);
            textArea.select();
            try {
                document.execCommand('copy');
                showSuccess('کپی شد');
            } catch (err) {
                console.error('خطا در کپی:', err);
            }
            document.body.removeChild(textArea);
        }
    }

    // Close modal on ESC key
    document.addEventListener('keydown', function (e) {
        if (e.key === 'Escape') {
            closeAddModal();
            closeEditModal();
        }
    });

    // Close modal on backdrop click
    document.getElementById('addCredentialModal').addEventListener('click', function (e) {
        if (e.target === this) {
            closeAddModal();
        }
    });

    document.getElementById('editCredentialModal').addEventListener('click', function (e) {
        if (e.target === this) {
            closeEditModal();
        }
    });
</script>