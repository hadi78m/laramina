@extends('layouts.mclsApp')

@section('content')
<div id="admin-module" data-module="sms/sms-credentials"></div>
@endsection
@section('scripts')
@endsection