@extends('layouts.mclsApp')

@section('content')
    <x-elements.sidebar>
        <x-sidebars.sms />
    </x-elements.sidebar>
    <div id="admin-module" data-module="sms/providers"></div>

    @include('sms.providers.modal.providers-numbers-modal')

@endsection
@section('scripts')
    @include('sms.providers.script.providers-numbers-script')
@endsection