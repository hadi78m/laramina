<?php


use Illuminate\Support\Facades\Route;
use App\Http\Controllers\IconController;
use App\Http\Controllers\UserController;
use App\Http\Controllers\RolesController;
use App\Http\Controllers\DashbordController;
use App\Http\Controllers\PermissionController;
use Spatie\Permission\Middleware\RoleMiddleware;
use App\AdminPlatform\Controllers\ModuleController;




const ADMINS_ROLES = RoleMiddleware::class . ':Admin|SuperAdmin';
const SuperAdmin_ROLE = RoleMiddleware::class . ':SuperAdmin';
const Admin_ROLE = RoleMiddleware::class . ':Admin';


Route::get('/', [DashbordController::class, 'index'])
    ->middleware(['auth', 'verified'])
    ->name('dashboard');









/***
 * 
 * تعریف endpoint کشف ماژول‌ها (Laravel)
 */


// routes/web.php

// Route::get('/admin/modules', function () {

//     $base = public_path('js/modules');
//     $modules = [];

//     foreach (File::allFiles($base) as $file) {

//         if ($file->getFilename() === 'module.js') {

//             $relative = str_replace(public_path(), '', $file->getPathname());

//             // تبدیل backslash به slash
//             $relative = str_replace('\\', '/', $relative);

//             // اطمینان از شروع با /
//             if (!str_starts_with($relative, '/')) {
//                 $relative = '/' . $relative;
//             }

//             $modules[] = $relative;
//         }
//     }

//     return response()->json($modules);
// });


/****
 * 
 */



/*** admin platform  */


Route::get('/platform/modules', [ModuleController::class, 'index']);

/**** end admin platform */


require __DIR__ . '/auth.php';
require __DIR__ . '/sms.php';




Route::prefix('manage/')->middleware(['auth'])->name('manage.')->group(function () {
    Route::prefix('users')
        ->middleware(SuperAdmin_ROLE)->name('users.')->group(function () {
            // users Routes
            Route::get('/', [UserController::class, 'index'])->name('index');
            Route::get('/json', [UserController::class, 'json'])->name('json');
            Route::post('/', [UserController::class, 'store'])->name('store');
            // Route::get('/{id}/edit', [SmsCredentialController::class, 'edit'])->name('edit');
            Route::put('/update/{id}', [UserController::class, 'update'])->name('update');

            Route::delete('/destroy/{id}', [UserController::class, 'destroy'])->name('destroy');
            Route::post('/{id}/toggle-status', [UserController::class, 'toggleStatus'])->name('toggle-status');
        });
    Route::prefix('roles')
        ->middleware([SuperAdmin_ROLE])->name('roles.')->group(function () {
            // roles Routes
            Route::get('/', [RolesController::class, 'index'])->name('index');
            Route::get('/json', [RolesController::class, 'json'])->name('json');
            Route::post('/', [RolesController::class, 'store'])->name('store');
            // Route::get('/{id}/edit', [SmsCredentialController::class, 'edit'])->name('edit');
            Route::put('/update/{id}', [RolesController::class, 'update'])->name('update');
            Route::delete('/destroy/{id}', [RolesController::class, 'destroy'])->name('destroy');
            Route::post('/{id}/toggle-status', [RolesController::class, 'toggleStatus'])->name('toggle-status');
        });
    Route::prefix('permissions')
        ->middleware([SuperAdmin_ROLE])
        ->name('permissions.')->group(function () {
            // roles Routes
            Route::get('/', [PermissionController::class, 'index'])->name('index');
            Route::get('/json', [PermissionController::class, 'json'])->name('json');
            Route::post('/', [PermissionController::class, 'store'])->name('store');
            // Route::get('/{id}/edit', [SmsCredentialController::class, 'edit'])->name('edit');
            Route::put('/update/{id}', [PermissionController::class, 'update'])->name('update');
            Route::delete('/destroy/{id}', [PermissionController::class, 'destroy'])->name('destroy');
            Route::post('/{id}/toggle-status', [PermissionController::class, 'toggleStatus'])->name('toggle-status');
        });
    Route::get('/gradient', function () {
        return view('manager.gradient');
    })
        ->middleware(['auth', SuperAdmin_ROLE])->name('gradient-generator');
});
/* icons */
Route::get('/manage/icons', [IconController::class, 'index'])->middleware(['auth', SuperAdmin_ROLE])->name('icons.index');
Route::get('/api/icons/extract', [IconController::class, 'extractIcons'])->middleware(['auth', SuperAdmin_ROLE]);
Route::get('/api/icons/search', [IconController::class, 'search'])->middleware(['auth', SuperAdmin_ROLE]);
Route::post('/api/icons/copy', [IconController::class, 'copyToClipboard'])->middleware(['auth', SuperAdmin_ROLE]);
Route::get('/api/icons/{icon}', [IconController::class, 'getIconInfo'])->middleware(['auth', SuperAdmin_ROLE]);
    /* end icons */
