<?php

namespace App\Jobs\Sms;

use App\Models\Sms\Provider;
use App\Models\Sms\Message;
use App\Services\Sms\SmsSenderService;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Queue\SerializesModels;
use Illuminate\Support\Facades\Log;

class SendImmediateSmsJob implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;
    protected array $messageIds;

    /**
     * Create a new job instance.
     */
    public function __construct(array $messageIds)
    {
        $this->messageIds = $messageIds;
        $this->onQueue('sms-immediate'); // Assign to immediate SMS que
    }


    /**       
     * Execute the job.  
     *
     * @return void     
     */
    

    public function handle(SmsSenderService $smsSender)
    {
        // 1. Fetch Messages
        $messages = Message::whereIn('id', $this->messageIds)->get();

        // 2. دریافت Provider پیش‌فرض (این کار باید در Job انجام شود تا Service با Provider صحیح مقداردهی شود)
        // اگر Provider در مدل پیام ذخیره شده، از آن استفاده کنید. 
        // اگر نه، از Provider پیش‌فرض فعال استفاده کنید:
        try {
            $defaultProvider = Provider::where('is_active', true)
            ->where('is_default',true)->firstOrFail();
        } catch (\Exception $e) {
            // اگر Provider فعالی نباشد
            Log::error("No active SMS provider found for immediate messages.");
            // پیام‌ها با وضعیت failed ذخیره می‌شوند
            Message::whereIn('id', $this->messageIds)->update(['status' => 'failed', 'error_message' => 'No active provider configured.']);
            return;
        }

        $sender = new SmsSenderService($defaultProvider);

        foreach ($messages as $message) {
            try {
                if ($message->type === 'news') {
                    // ارسال پیام‌های خبری به SendSingleSmsJob با تأخیر 1 ساعته (یا هر مقدار دلخواه)
                    $delayInSeconds = now()->addHour()->diffInSeconds(now());
                    SendSingleSmsJob::dispatch($message->id)
                        ->delay($delayInSeconds)
                        ->onQueue('sms-scheduled');

                    $message->status = 'scheduled';
                    $message->save();
                    Log::info("SMS ID {$message->id} (Type: News) scheduled for later.");
                } else {
                    // 3. ارسال فوری با استفاده از سرویس مقداردهی شده
                    $sender->send($message);

                    // 4. Update Status on Success
                    $message->status = 'sent';
                    $message->sent_at = now();
                    $message->save();
                }
            } catch (\Exception $e) {
                // 5. Comprehensive Error Handling
                Log::error("Failed to process immediate SMS ID {$message->id}: " . $e->getMessage());
                $message->status = 'failed';
                $message->error_message = $e->getMessage();
                $message->save();
            }
        }
    }
}
