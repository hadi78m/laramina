# SMS Panel API Documentation

پنل مدیریت پیامک - مستندات API

> **آدرس API:** `http://sms.mcls.gov.test`

---

## فهرست مطالب

1. [دریافت آی پی کاربر](#۱-دریافت-آی-پی-کاربر)
2. [نحوه احراز هویت](#۲-نحوه-احراز-هویت)
3. [ارسال پیامک تکی / بالکی](#۳-ارسال-پیامک-تکی--بالکی)
4. [ارسال پیامک احراز هویت (OTP)](#۴-ارسال-پیامک-احراز-هویت-otp)
5. [جدول کدهای خطا](#جدول-کدهای-خطا-error-codes)
6. [راه‌اندازی Queue Worker](#راه‌اندازی-queue-worker)
7. [نکات مهم](#نکات-مهم)

---

## ۱. دریافت آی پی کاربر

```bash
curl --request GET \
  --url http://sms.mcls.gov.test/api/v1/sms/GetIp
```

```bash
http GET http://sms.mcls.gov.test/api/v1/sms/GetIp
```

### پاسخ:

```json
{
  "ip": "127.0.0.1"
}
```

---

## ۲. نحوه احراز هویت

احراز هویت API با استفاده از `static_token` انجام می‌شود. توکن را از پنل مدیریت Credentialها دریافت کنید.

### استفاده:

```bash
curl --request POST \
  --url http://sms.mcls.gov.test/api/v1/sms/send \
  --header 'Authorization: Bearer YOUR_STATIC_TOKEN' \
  --header 'Content-Type: application/json' \
  --data '{
    "recipients": ["09121234567"],
    "message": ["سلام"]
  }'
```

### نکات:
- `static_token` از پنل مدیریت > Credential > مشاهده توکن دریافت می‌شود
- توکن با اعتبار ۱ سال صادر می‌شود
- در صورت نیاز به تمدید، از پنل اقدام کنید

---

## ۳. ارسال پیامک تکی / بالکی

این endpoint هم برای ارسال تکی و هم بالکی استفاده می‌شود. اگر یک پیام باشد، تکی ارسال می‌شود. اگر چند پیام باشد، بالکی ارسال می‌شود.

> **احراز هویت:** Bearer Token الزامی است.

### پارامترها:

| پارامتر | نوع | الزامی | حداکثر | توضیح |
|---------|-----|--------|--------|-------|
| `recipients` | array | ✅ | ۱۰۰ | آرایه شماره‌های موبایل |
| `message` | array | ✅ | ۱۰۰ | آرایه متن پیام‌ها (حداکثر ۳۳۰ کاراکتر) |
| `type` | string | ❌ | — | نوع پیامک: `news` یا `default` |

### نمونه درخواست - ارسال تکی:

```bash
curl --request POST \
  --url http://sms.mcls.gov.test/api/v1/sms/send \
  --header 'Accept: application/json' \
  --header 'Authorization: Bearer 1|xY9zAbC123...' \
  --header 'Content-Type: application/json' \
  --data '{
    "recipients": ["09121234567"],
    "message": ["این یک پیام تستی است"]
  }'
```

```bash
http --json POST http://sms.mcls.gov.test/api/v1/sms/send \
  Authorization:"Bearer 1|xY9zAbC123..." \
  recipients:='["09121234567"]' \
  message:='["این یک پیام تستی است"]'
```

### نمونه درخواست - ارسال بالکی:

```bash
curl --request POST \
  --url http://sms.mcls.gov.test/api/v1/sms/send \
  --header 'Accept: application/json' \
  --header 'Authorization: Bearer 1|xY9zAbC123...' \
  --header 'Content-Type: application/json' \
  --data '{
    "recipients": ["09121234567", "09121111111"],
    "message": ["پیام اول", "پیام دوم"],
    "type": "news"
  }'
```

### نمونه درخواست - ارسال تکی با نوع خبری:

```bash
curl --request POST \
  --url http://sms.mcls.gov.test/api/v1/sms/send \
  --header 'Authorization: Bearer 1|xY9zAbC123...' \
  --header 'Content-Type: application/json' \
  --data '{
    "recipients": ["09121234567"],
    "message": ["این یک پیام خبری است"],
    "type": "news"
  }'
```

### پاسخ موفق (HTTP `202`):

```json
{
  "success": true,
  "message": "1 پیام با موفقیت در صف ارسال قرار گرفت",
  "total_requested": 1,
  "sent_count": 1,
  "blocked_count": 0
}
```

### پاسخ موفق - بالکی:

```json
{
  "success": true,
  "message": "2 پیام با موفقیت در صف ارسال قرار گرفت",
  "total_requested": 2,
  "sent_count": 2,
  "blocked_count": 0,
  "blocked_words": []
}
```

### نمونه پاسخ خطا - اعتبارسنجی:

```json
{
  "success": false,
  "error_code": "VALIDATION_ERROR",
  "message": "خطا در اطلاعات ارسالی",
  "errors": {
    "recipients": ["شماره گیرنده الزامی است."],
    "message": ["متن پیام الزامی است."]
  }
}
```

### نمونه پاسخ خطا - کلمات غیرمجاز:

```json
{
  "success": false,
  "error_code": "BLOCKED_WORDS",
  "message": "پیام شما دارای کلمات غیر مجاز است و مسدود شد",
  "blockedCount": 1,
  "blocked_words": ["تست"]
}
```

### پاسخ‌های خطای این endpoint:

| error_code | HTTP Code | پیام |
|------------|-----------|------|
| `UNAUTHORIZED` | `401` | توکن دسترسی نامعتبر یا منقضی شده است |
| `VALIDATION_ERROR` | `422` | خطا در اطلاعات ارسالی |
| `MESSAGE_COUNT_MISMATCH` | `403` | تعداد پیام و شماره نامتناسب |
| `BLOCKED_WORDS` | `422` | پیام حاوی کلمات غیرمجاز است |
| `DAILY_LIMIT_EXCEEDED` | `403` | محدودیت روزانه ارسال پیامک |
| `SERVER_ERROR` | `500` | خطای سرور |

---

## ۴. ارسال پیامک احراز هویت (OTP)

برای ارسال کد تأیید (OTP) استفاده می‌شود. ارسال **فوری** است (بدون صف).

> **احراز هویت:** Bearer Token الزامی است.

### پارامترها:

| پارامتر | نوع | الزامی | توضیح |
|---------|-----|--------|-------|
| `recipient` | string | ✅ | شماره موبایل (فرمت: 09xxxxxxxxx) |
| `message` | string | ✅ | کد OTP (شامل اعداد، ۴ تا ۶ رقم) |

> **نکته:** پارامتر `type` نیازی نیست - به صورت خودکار `otp` تنظیم می‌شود.

### نمونه درخواست:

```bash
curl --request POST \
  --url http://sms.mcls.gov.test/api/v1/sms/sendOtp \
  --header 'Accept: application/json' \
  --header 'Authorization: Bearer 1|xY9zAbC123...' \
  --header 'Content-Type: application/json' \
  --data '{
    "recipient": "09121234567",
    "message": "09523"
  }'
```

```bash
http --json POST http://sms.mcls.gov.test/api/v1/sms/sendOtp \
  Authorization:"Bearer 1|xY9zAbC123..." \
  recipient="09121234567" \
  message="09523"
```

### پاسخ موفق (HTTP `200`):

```json
{
  "success": true,
  "message": "پیامک با موفقیت ثبت و ارسال شد.",
  "request_id": 5
}
```

### نمونه پاسخ خطا - اعتبارسنجی:

```json
{
  "success": false,
  "error_code": "VALIDATION_ERROR",
  "message": "داده‌های ورودی نامعتبر است",
  "errors": {
    "recipient": ["فرمت شماره موبایل صحیح نیست."],
    "message": ["کد پیام باید شامل عدد باشد."]
  }
}
```

### پاسخ‌های خطای این endpoint:

| error_code | HTTP Code | پیام |
|------------|-----------|------|
| `UNAUTHORIZED` | `401` | توکن دسترسی نامعتبر یا منقضی شده است |
| `VALIDATION_ERROR` | `422` | داده‌های ورودی نامعتبر است |
| `DAILY_LIMIT_EXCEEDED` | `403` | محدودیت روزانه ارسال پیامک |
| `SERVER_ERROR` | `500` | خطای سرور |

---

## جدول کدهای خطا (Error Codes)

تمام خطاهای API با کد یکتا برمی‌گردند. کلاینت می‌تواند بر اساس `error_code` مدیریت خطا انجام دهد.

| error_code | HTTP Code | توضیح | endpoint |
|------------|-----------|-------|----------|
| `UNAUTHORIZED` | `401` | توکن نامعتبر یا منقضی | `send` / `sendOtp` |
| `VALIDATION_ERROR` | `422` | خطای اعتبارسنجی ورودی | `send` / `sendOtp` |
| `MESSAGE_COUNT_MISMATCH` | `403` | تعداد پیام و شماره نامتناسب | `send` |
| `BLOCKED_WORDS` | `422` | کلمات غیرمجاز در متن | `send` |
| `DAILY_LIMIT_EXCEEDED` | `403` | محدودیت روزانه پر شده | `send` / `sendOtp` |
| `SERVER_ERROR` | `500` | خطای داخلی سرور | همه |

### نمونه ساختار پاسخ خطا:

```json
{
  "success": false,
  "error_code": "UNAUTHORIZED",
  "message": "توکن دسترسی نامعتبر یا منقضی شده است.",
  "hint": "لطفا توکن خود را بررسی یا با ادمین تماس بگیرید."
}
```

> **نکته:** فیلد `hint` اختیاری است و فقط در برخی خطاها ارسال می‌شود.

---

## راه‌اندازی Queue Worker

برای ارسال پیامک‌هایی که از طریق Queue ثبت شده‌اند:

```bash
php artisan queue:work --queue=sms --tries=3
```

> **نکته:** ارسال OTP فوری است و نیازی به Queue Worker ندارد. فقط پیامک‌های عادی (`/send`) از Queue استفاده می‌کنند.

---

## نکات مهم

### حساسیت Case Sensitivity

لینوکس به بزرگی و کوچکی حروف حساس است:

- ✅ `/api/v1/sms/send`
- ❌ `/api/v1/SMS/Send`

### خلاصه Endpointها

| Method | URL | توضیح | احراز هویت |
|--------|-----|-------|------------|
| `GET` | `/api/v1/sms/GetIp` | دریافت آی پی | ❌ |
| `POST` | `/api/v1/sms/send` | ارسال پیامک تکی/بالکی | Bearer Token |
| `POST` | `/api/v1/sms/sendOtp` | ارسال OTP (فوری) | Bearer Token |

### تست با HTTPie

```bash
# دریافت آی پی
http GET http://sms.mcls.gov.test/api/v1/sms/GetIp

# ارسال پیامک تکی
http --json POST http://sms.mcls.gov.test/api/v1/sms/send \
  Authorization:"Bearer YOUR_TOKEN" \
  recipients:='["09121234567"]' \
  message:='["سلام"]'

# ارسال پیامک بالکی
http --json POST http://sms.mcls.gov.test/api/v1/sms/send \
  Authorization:"Bearer YOUR_TOKEN" \
  recipients:='["09121234567","09121111111"]' \
  message:='["پیام اول","پیام دوم"]' \
  type=news

# ارسال OTP
http --json POST http://sms.mcls.gov.test/api/v1/sms/sendOtp \
  Authorization:"Bearer YOUR_TOKEN" \
  recipient="09121234567" \
  message="1234"
```

### تست با cURL

```bash
# دریافت آی پی
curl http://sms.mcls.gov.test/api/v1/sms/GetIp

# ارسال پیامک تکی
curl --request POST \
  --url http://sms.mcls.gov.test/api/v1/sms/send \
  --header 'Content-Type: application/json' \
  --header 'Authorization: Bearer YOUR_STATIC_TOKEN' \
  --data '{"recipients":["09121234567"],"message":["سلام"]}'

# ارسال پیامک بالکی
curl --request POST \
  --url http://sms.mcls.gov.test/api/v1/sms/send \
  --header 'Content-Type: application/json' \
  --header 'Authorization: Bearer YOUR_STATIC_TOKEN' \
  --data '{"recipients":["09121234567","09121111111"],"message":["پیام اول","پیام دوم"],"type":"news"}'

# ارسال OTP
curl --request POST \
  --url http://sms.mcls.gov.test/api/v1/sms/sendOtp \
  --header 'Content-Type: application/json' \
  --header 'Authorization: Bearer YOUR_STATIC_TOKEN' \
  --data '{"recipient":"09121234567","message":"1234"}'
```
