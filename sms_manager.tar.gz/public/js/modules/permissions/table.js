import { createForm } from './forms/create-form.js'
import { permissionActions } from './actions.js'

const publicLang   = AdminLang.getNamespace('common');
const moduleFields = AdminLang.getNamespace('modules.permissions.fields');
const moduleActions = AdminLang.getNamespace('modules.permissions.actions');

export default {

    endpoint: 'manage.permissions.json',
    search: true,

    headerTitle: moduleFields.header_title || (publicLang.manage + ' ' + (moduleFields.title || 'permissions.permissions')),
    addButtonLabel: moduleActions.create || (publicLang.create + ' ' + (moduleActions.item || publicLang.item)),
    displayButton: true,

    actions: permissionActions,

    perPage: 10,

    modalTheme: 'light',


    modals: {
        create: {
            title: moduleActions.create || publicLang.create,
            width: '500px',
            form: createForm,
            roles:['SuperAdmin']
        },
        edit: {
            title: moduleActions.edit || publicLang.edit,
            width: '500px',
            form: createForm
        }
    },



    columns: [
        { key: 'id', label: publicLang.id, sortable: true },
        { key: 'name', label: publicLang.name, sortable: true },
        { key: 'created_at', label: publicLang.created_at, sortable: true },
        {
            label: publicLang.actions,
            type: 'actions',
            actions: ['edit', 'delete']
        }
    ],

}