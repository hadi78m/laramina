<?php

namespace App\Services\Sms;

use App\Helpers\RightelHelper;
use App\Models\Sms\Provider;
use App\Models\Sms\Message; // فرض بر این است که در جایی استفاده می‌شود
use GuzzleHttp\Client;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\RateLimiter;
use RuntimeException;

class SmsSenderService
{
    protected Provider $provider;
    protected Client $client;
    
    // تعریف متغیرهای خصوصی برای وضعیت OTP
    protected bool $isOtp = false;
    protected ?string $otpId = null;

    /**
     * سازنده سرویس ارسال پیامک.
     * Provider باید در زمان نمونه‌سازی تزریق شود.
     */
    public function __construct(?Provider $provider = null)
    {
        if (!$provider) {
             // این حالت باید در Job ها یا کنترلر با setProvider مدیریت شود، 
             // اما برای ایمنی یک استثنا در نظر گرفته می‌شود مگر اینکه به صورت دستی اینجکت شود.
             // برای سازگاری با تزریق DI لاراول، این قسمت را به سادگی تنظیم می‌کنیم.
             // در SendBulkSmsJob باید setProvider صدا زده شود.
        } else {
             $this->provider = $provider;
        }

        $this->client = new Client();
    }

    /**
     * ارسال پیامک با رعایت محدودیت‌های Rate Limiter
     */
    public function sendToProvider(string $recipient, string $message): array
    {
        if (!isset($this->provider)) {
            throw new RuntimeException("Provider not set on SmsSenderService instance.");
        }

        if ($this->provider->rate_unit === 'unlimited') {
            // مستقیم ارسال بدون RateLimiter
            return $this->executeSendRequest($recipient, $message);
        }

        $key = "sms_provider_{$this->provider->id}";

        // اجرای درخواست فقط اگر RateLimiter اجازه بده
        $executed = RateLimiter::attempt(
            key: $key,
            maxAttempts: 1, 
            callback: function () use ($recipient, $message) {
                return $this->executeSendRequest($recipient, $message);
            },
            decaySeconds: 60 // این مقدار باید بر اساس تنظیمات Rate Unit Provider تنظیم شود
        );


        if ($executed === false) { // RateLimiter::attempt در صورت محدودیت false برمی‌گرداند
            Log::warning("Rate limit exceeded for provider {$this->provider->name} (ID: {$this->provider->id})");

            return [
                'success' => false,
                'error' => 'Rate limit exceeded. Please try again later.',
                'gateway_id' => null,
            ];
        }

        // $executed نتیجه callback است (یعنی نتیجه ارسال واقعی)
        return $executed;
    }

    /**
     * اجرای واقعی درخواست ارسال پیامک به پرووایدر
     */
    private function executeSendRequest(string $recipient, string $message): array
    {
        // متغیرهای $this->isOtp و $this->otpId اکنون تعریف شده‌اند و قابل استفاده هستند
        $result = RightelHelper::send(
            $recipient,
            $message,
            $this->provider,
            $this->isOtp,
            $this->otpId
        );

        return [
            'success'    => $result['status'] === 'success',
            'gateway_id' => $result['message_id'] ?? null,
            'error'      => $result['status'] === 'error' ? $result['description'] : null,
        ];
    }

    /**
     * متد اصلی ارسال برای استفاده عمومی.
     * فرض می‌شود پارامترهای OTP (در صورت لزوم) قبل از این فراخوانی تنظیم شده‌اند.
     */
    public function send(string $recipient, string $message): array
    {
        return $this->sendToProvider($recipient, $message);
    }

    /**
     * تنظیم Provider روی نمونه سرویس موجود (برای استفاده در Jobها پس از DI)
     */
    public function setProvider(Provider $provider): self
    {
        $this->provider = $provider;
        return $this;
    }

    /**
     * تنظیم پارامترهای OTP برای استفاده در فراخوانی بعدی send.
     */
    public function setOtpParameters(bool $isOtp, ?string $otpId): self
    {
        $this->isOtp = $isOtp;
        $this->otpId = $otpId;
        return $this;
    }
}
