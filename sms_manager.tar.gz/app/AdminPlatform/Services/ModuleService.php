<?php

namespace App\AdminPlatform\Services;

use App\AdminPlatform\Support\ModuleRegistry;

class ModuleService
{
    protected ModuleRegistry $registry;

    public function __construct(ModuleRegistry $registry)
    {
        $this->registry = $registry;
    }

    public function getModules(): array
    {
        return $this->registry->all();
    }
}
