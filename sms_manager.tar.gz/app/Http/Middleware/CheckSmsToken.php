<?php

namespace App\Http\Middleware;

use App\Models\Sms\Credential;
use Illuminate\Http\Request;
use Closure;

class CheckSmsToken
{
    public function handle(Request $request, Closure $next)
    {
        $token = $request->bearerToken();
        if (!$token) {
            return response()->json(['success' => false, 'message' => 'توکن الزامی است'], 401);
        }

        $credential = Credential::where('current_access_token', $token)
            ->where('token_expires_at', '>', now())
            ->first();

        if (!$credential) {
            return response()->json(['success' => false, 'message' => 'توکن نامعتبر یا منقضی شده'], 401);
        }

        $request->merge(['auth_credential' => $credential]);
        return $next($request);
    }
}
