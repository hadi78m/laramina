<?php

namespace App\Models\Sms;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class SocialNumber extends Model
{
    use HasFactory;
    protected $table = 'social_numbers';


    protected $fillable = ['social_id', 'number', 'is_active'];
}
