<?php

namespace App\Models;

use App\AdminPlatform\Traits\AdminTableTrait;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Permission extends Model
{
    use HasFactory;
    use AdminTableTrait;


    /**
     * The attributes that are mass assignable.
     *
     * @var array<int, string>
     */
    protected $fillable = [
        'name',
        'guard_name',

    ];

    /**
     * رابطه چند به چند با کاربران
     *
     * @return \Illuminate\Database\Eloquent\Relations\BelongsToMany
     */
    public function users()
    {
        return $this->belongsToMany(User::class, 'user_permission');
    }

    /**
     * رابطه چند به چند با نقش‌ها
     *
     * @return \Illuminate\Database\Eloquent\Relations\BelongsToMany
     */
    public function roles()
    {
        return $this->belongsToMany(Role::class, 'role_permission');
    }

    public static function adminTransform($cred)
    {
        return [
            'id'                  => $cred->id,
            'name'                => $cred->name,
            'created_at'          => "<div dir='ltr' class='text-center'>"
                . verta($cred->created_at)->format('Y/m/d H:i')
                . "</div>",
        ];
    }
}
