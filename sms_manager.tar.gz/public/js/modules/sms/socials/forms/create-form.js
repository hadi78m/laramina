const publicLang = AdminLang.getNamespace('common');
const moduleFields = AdminLang.getNamespace('modules.socials.fields');
const moduleActions = AdminLang.getNamespace('modules.socials.actions');

export const createForm = {

    endpoint: 'sms.socials.store',
    updateEndpoint: 'sms.socials.update',
    deleteEndpoint: 'sms.socials.destroy',

    title: moduleActions.create || publicLang.create,

    fields: [
        // {
        //     name: 'created_by',
        //     label: publicLang.created_by,
        //     type: 'text'
        // },
        {
            name: 'name',
            label: publicLang.name + ' ' + moduleFields.social,
            type: 'text',
            required: true,
        },
        {
            type: 'group',
            group: [
                {
                    name: 'user',
                    label: publicLang.username,
                    type: 'text'
                },
                {
                    name: 'password',
                    label: publicLang.password,
                    type: 'text'
                }],
        },
        {
            name: 'token',
            label: publicLang.token || moduleFields.token,
            type: 'text'
        },
        {
            name: 'url',
            label: publicLang.address + ' API ',
            type: 'text'
        },
        {
            type: 'group',
            group: [
                {
                    name: 'rate_unit',
                    label: publicLang.rate_unit || moduleFields.rate_unit,
                    type: 'select',
                    required: true,
                    options:
                        [
                            { value: "unlimited", label: 'نامحدود' },
                            { value: "per_second", label: 'در ثانیه' },
                            { value: "per_minute", label: 'در دقیقه' },
                            { value: "per_hour", label: 'در ساعت' },
                        ],
                },
                {
                    name: 'send_rate',
                    label: publicLang.send_rate || moduleFields.send_rate,
                    type: 'number',


                },
            ]
        },
        {
            name: 'is_default',
            label: publicLang.is_default,
            type: 'checkbox'
        },
        {
            name: 'is_active',
            label: publicLang.is_active,
            type: 'checkbox'
        },
    ],

    buttons: {
        submit: publicLang.save,
        cancel: publicLang.cancel,
    }
};