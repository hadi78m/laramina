@extends('layouts.mclsApp')

@section('content',)
    <x-elements.sidebar>
        <x-sidebars.sms />
    </x-elements.sidebar>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #1a1a2e 0%, #16213e 50%, #0f3460 100%) !important;
            min-height: 100vh;
            color: #fff;
            padding: 20px;
        }

        .container {
            max-width: 1200px;
            margin: 0 auto;
        }

        h1 {
            text-align: center;
            margin-bottom: 30px;
            font-size: 2.5rem;
            background: linear-gradient(90deg, #e94560, #ff6b6b, #feca57);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
        }

        .main-grid {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 30px;
            margin-bottom: 30px;
        }

        @media (max-width: 768px) {
            .main-grid {
                grid-template-columns: 1fr;
            }
        }

        .panel {
            background: rgba(255, 255, 255, 0.1);
            backdrop-filter: blur(10px);
            border-radius: 20px;
            padding: 25px;
            border: 1px solid rgba(255, 255, 255, 0.2);
        }

        .panel h2 {
            margin-bottom: 20px;
            font-size: 1.3rem;
            color: #e94560;
        }

        .preview-area {
            min-height: 300px;
            border-radius: 15px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.2rem;
            text-shadow: 2px 2px 4px rgba(0, 0, 0, 0.5);
            transition: all 0.3s ease;
            position: relative;
            overflow: hidden;
        }

        .preview-area::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background:
                linear-gradient(45deg, #ccc 25%, transparent 25%),
                linear-gradient(-45deg, #ccc 25%, transparent 25%),
                linear-gradient(45deg, transparent 75%, #ccc 75%),
                linear-gradient(-45deg, transparent 75%, #ccc 75%);
            background-size: 20px 20px;
            background-position: 0 0, 0 10px, 10px -10px, -10px 0px;
            opacity: 0.3;
            z-index: -1;
        }

        .control-group {
            margin-bottom: 20px;
        }

        .control-group label {
            display: block;
            margin-bottom: 8px;
            font-weight: 500;
            color: #ddd;
        }

        select,
        input[type="range"],
        input[type="number"] {
            width: 100%;
            padding: 10px;
            border-radius: 8px;
            border: 1px solid rgba(255, 255, 255, 0.3);
            background: rgba(0, 0, 0, 0.3);
            color: #fff;
            font-size: 1rem;
        }

        select:focus,
        input:focus {
            outline: none;
            border-color: #e94560;
        }

        input[type="range"] {
            padding: 5px;
            cursor: pointer;
        }

        .color-stops {
            margin-bottom: 20px;
        }

        .color-stop {
            display: flex;
            align-items: center;
            gap: 10px;
            margin-bottom: 10px;
            padding: 10px;
            background: rgba(0, 0, 0, 0.2);
            border-radius: 10px;
        }

        .color-stop input[type="color"] {
            width: 50px;
            height: 40px;
            border: none;
            border-radius: 8px;
            cursor: pointer;
        }

        .color-stop input[type="range"] {
            flex: 1;
        }

        .color-stop .position-value {
            min-width: 45px;
            text-align: center;
            font-size: 0.9rem;
        }

        .btn {
            padding: 12px 24px;
            border: none;
            border-radius: 10px;
            cursor: pointer;
            font-size: 1rem;
            font-weight: 600;
            transition: all 0.3s ease;
            margin-right: 10px;
            margin-bottom: 10px;
        }

        .btn-primary {
            background: linear-gradient(135deg, #e94560, #ff6b6b);
            color: white;
        }

        .btn-primary:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 20px rgba(233, 69, 96, 0.4);
        }

        .btn-secondary {
            background: rgba(255, 255, 255, 0.2);
            color: white;
            border: 1px solid rgba(255, 255, 255, 0.3);
        }

        .btn-secondary:hover {
            background: rgba(255, 255, 255, 0.3);
        }

        .btn-danger {
            background: rgba(255, 0, 0, 0.3);
            color: white;
            padding: 8px 16px;
            font-size: 0.9rem;
        }

        .btn-danger:hover {
            background: rgba(255, 0, 0, 0.5);
        }

        .code-output {
            background: #1a1a2e;
            border-radius: 15px;
            padding: 20px;
            margin-top: 20px;
            position: relative;
        }

        .code-output h3 {
            margin-bottom: 15px;
            color: #e94560;
        }

        .code-block {
            background: #0f0f1e;
            border-radius: 10px;
            padding: 15px;
            font-family: 'Courier New', monospace;
            font-size: 0.9rem;
            color: #a8d8ea;
            overflow-x: auto;
            white-space: pre-wrap;
            word-wrap: break-word;
            line-height: 1.6;
        }

        .copy-btn {
            position: absolute;
            top: 20px;
            right: 20px;
            background: rgba(255, 255, 255, 0.1);
            border: 1px solid rgba(255, 255, 255, 0.3);
            color: white;
            padding: 8px 16px;
            border-radius: 8px;
            cursor: pointer;
            font-size: 0.9rem;
            transition: all 0.3s ease;
        }

        .copy-btn:hover {
            background: rgba(255, 255, 255, 0.2);
        }

        .copy-btn.copied {
            background: #4caf50;
            border-color: #4caf50;
        }

        .presets {
            display: flex;
            flex-wrap: wrap;
            gap: 10px;
            margin-bottom: 20px;
        }

        .preset {
            width: 50px;
            height: 50px;
            border-radius: 10px;
            cursor: pointer;
            border: 2px solid transparent;
            transition: all 0.3s ease;
        }

        .preset:hover {
            transform: scale(1.1);
            border-color: #fff;
        }

        .range-value {
            display: inline-block;
            margin-left: 10px;
            color: #e94560;
            font-weight: bold;
        }

        .export-section {
            margin-top: 20px;
            padding-top: 20px;
            border-top: 1px solid rgba(255, 255, 255, 0.2);
        }

        .export-options {
            display: flex;
            gap: 10px;
            flex-wrap: wrap;
        }

        .toast {
            position: fixed;
            bottom: 30px;
            right: 30px;
            background: #4caf50;
            color: white;
            padding: 15px 25px;
            border-radius: 10px;
            box-shadow: 0 5px 20px rgba(0, 0, 0, 0.3);
            transform: translateY(100px);
            opacity: 0;
            transition: all 0.3s ease;
            z-index: 1000;
        }

        .toast.show {
            transform: translateY(0);
            opacity: 1;
        }
    </style>
    <div class="container bg-black p-8" dir="ltr">
        <h1>🎨 CSS Gradient Generator</h1>

        <div class="main-grid">
            <div class="panel">
                <h2>⚙️ Controls</h2>

                <div class="control-group">
                    <label>Gradient Type</label>
                    <select id="gradientType">
                        <option value="linear">Linear Gradient</option>
                        <option value="radial">Radial Gradient</option>
                        <option value="conic">Conic Gradient</option>
                    </select>
                </div>

                <div class="control-group" id="angleControl">
                    <label>Angle <span class="range-value" id="angleValue">90°</span></label>
                    <input type="range" id="angle" min="0" max="360" value="90">
                </div>

                <div class="control-group" id="shapeControl" style="display: none;">
                    <label>Shape</label>
                    <select id="shape">
                        <option value="circle">Circle</option>
                        <option value="ellipse">Ellipse</option>
                    </select>
                </div>

                <div class="control-group">
                    <label>Color Stops</label>
                    <div class="color-stops" id="colorStops">
                        <!-- Color stops will be generated here -->
                    </div>
                    <button class="btn btn-secondary" onclick="addColorStop()">+ Add Color Stop</button>
                </div>

                <div class="control-group">
                    <label>Presets</label>
                    <div class="presets" id="presets">
                        <!-- Presets will be generated here -->
                    </div>
                </div>
            </div>

            <div class="panel">
                <h2>👁️ Live Preview</h2>
                <div class="preview-area" id="preview">
                    Preview Your Gradient
                </div>

                <div class="export-section">
                    <h3 style="margin-bottom: 15px; color: #e94560;">📤 Export Options</h3>
                    <div class="export-options">
                        <button class="btn btn-primary" onclick="exportCSS()">Export .css File</button>
                        <button class="btn btn-secondary" onclick="copyCSS()">Copy CSS Code</button>
                    </div>
                </div>
            </div>
        </div>

        <div class="code-output">
            <h3>📝 Generated CSS</h3>
            <button class="copy-btn" onclick="copyCode()">Copy</button>
            <div class="code-block" id="codeOutput"></div>
        </div>
    </div>

    <div class="toast" id="toast">Copied to clipboard!</div>

    <script>
        // State
        let colorStops = [
            { color: '#e94560', position: 0 },
            { color: '#0f3460', position: 100 }
        ];

        const presets = [
            { name: 'Sunset', stops: [{ color: '#ff6b6b', position: 0 }, { color: '#feca57', position: 100 }] },
            { name: 'Ocean', stops: [{ color: '#00d2ff', position: 0 }, { color: '#3a7bd5', position: 100 }] },
            { name: 'Forest', stops: [{ color: '#11998e', position: 0 }, { color: '#38ef7d', position: 100 }] },
            { name: 'Purple', stops: [{ color: '#667eea', position: 0 }, { color: '#764ba2', position: 100 }] },
            { name: 'Dark', stops: [{ color: '#232526', position: 0 }, { color: '#414345', position: 100 }] },
            { name: 'Berry', stops: [{ color: '#8e2de2', position: 0 }, { color: '#4a00e0', position: 100 }] },
            { name: 'Fire', stops: [{ color: '#f83600', position: 0 }, { color: '#f9d423', position: 100 }] },
            { name: 'Ice', stops: [{ color: '#e0c3fc', position: 0 }, { color: '#8ec5fc', position: 100 }] }
        ];

        // Initialize
        function init() {
            renderColorStops();
            renderPresets();
            updateGradient();

            // Event listeners
            document.getElementById('gradientType').addEventListener('change', handleTypeChange);
            document.getElementById('angle').addEventListener('input', updateAngle);
            document.getElementById('shape').addEventListener('change', updateGradient);
        }

        function renderColorStops() {
            const container = document.getElementById('colorStops');
            container.innerHTML = '';

            colorStops.forEach((stop, index) => {
                const div = document.createElement('div');
                div.className = 'color-stop';
                div.innerHTML = `
                        <input type="color" value="${stop.color}" onchange="updateColor(${index}, this.value)">
                        <input type="range" min="0" max="100" value="${stop.position}" 
                               oninput="updatePosition(${index}, this.value)">
                        <span class="position-value">${stop.position}%</span>
                        ${colorStops.length > 2 ? `<button class="btn btn-danger" onclick="removeColorStop(${index})">×</button>` : ''}
                    `;
                container.appendChild(div);
            });
        }

        function renderPresets() {
            const container = document.getElementById('presets');
            container.innerHTML = '';

            presets.forEach((preset, index) => {
                const div = document.createElement('div');
                div.className = 'preset';
                div.style.background = generateGradientString('linear', 90, preset.stops);
                div.title = preset.name;
                div.onclick = () => loadPreset(index);
                container.appendChild(div);
            });
        }

        function loadPreset(index) {
            colorStops = JSON.parse(JSON.stringify(presets[index].stops));
            renderColorStops();
            updateGradient();
        }

        function addColorStop() {
            const lastStop = colorStops[colorStops.length - 1];
            const newPosition = Math.min(100, lastStop.position + 10);
            colorStops.push({
                color: '#ffffff',
                position: newPosition
            });
            colorStops.sort((a, b) => a.position - b.position);
            renderColorStops();
            updateGradient();
        }

        function removeColorStop(index) {
            colorStops.splice(index, 1);
            renderColorStops();
            updateGradient();
        }

        function updateColor(index, value) {
            colorStops[index].color = value;
            updateGradient();
        }

        function updatePosition(index, value) {
            colorStops[index].position = parseInt(value);
            renderColorStops();
            updateGradient();
        }

        function updateAngle() {
            const angle = document.getElementById('angle').value;
            document.getElementById('angleValue').textContent = angle + '°';
            updateGradient();
        }

        function handleTypeChange() {
            const type = document.getElementById('gradientType').value;
            document.getElementById('angleControl').style.display = type === 'linear' ? 'block' : 'none';
            document.getElementById('shapeControl').style.display = type === 'radial' ? 'block' : 'none';
            updateGradient();
        }

        function generateGradientString(type, angle, stops) {
            const sortedStops = [...stops].sort((a, b) => a.position - b.position);
            const stopString = sortedStops.map(s => `${s.color} ${s.position}%`).join(', ');

            if (type === 'linear') {
                return `linear-gradient(${angle}deg, ${stopString})`;
            } else if (type === 'radial') {
                const shape = document.getElementById('shape').value;
                return `radial-gradient(${shape}, ${stopString})`;
            } else if (type === 'conic') {
                return `conic-gradient(${stopString})`;
            }
        }

        function updateGradient() {
            const type = document.getElementById('gradientType').value;
            const angle = document.getElementById('angle').value;

            const gradient = generateGradientString(type, angle, colorStops);

            document.getElementById('preview').style.background = gradient;

            const css = generateCSS(gradient);
            document.getElementById('codeOutput').textContent = css;
        }

        function generateCSS(gradient) {
            return `/* Generated CSS Gradient */
    .gradient-background {
        background: ${gradient};
        /* Fallback for older browsers */
        background-color: ${colorStops[0].color};
    }

    /* For text gradient effect */
    .gradient-text {
        background: ${gradient};
        -webkit-background-clip: text;
        -webkit-text-fill-color: transparent;
        background-clip: text;
    }`;
        }

        function copyCode() {
            const code = document.getElementById('codeOutput').textContent;
            navigator.clipboard.writeText(code).then(() => {
                showToast('Code copied to clipboard!');
                const btn = document.querySelector('.copy-btn');
                btn.textContent = 'Copied!';
                btn.classList.add('copied');
                setTimeout(() => {
                    btn.textContent = 'Copy';
                    btn.classList.remove('copied');
                }, 2000);
            });
        }

        function copyCSS() {
            const code = document.getElementById('codeOutput').textContent;
            navigator.clipboard.writeText(code).then(() => {
                showToast('CSS copied to clipboard!');
            });
        }

        function exportCSS() {
            const code = document.getElementById('codeOutput').textContent;
            const blob = new Blob([code], { type: 'text/css' });
            const url = URL.createObjectURL(blob);
            const a = document.createElement('a');
            a.href = url;
            a.download = 'gradient.css';
            document.body.appendChild(a);
            a.click();
            document.body.removeChild(a);
            URL.revokeObjectURL(url);
            showToast('CSS file exported!');
        }

        function showToast(message) {
            const toast = document.getElementById('toast');
            toast.textContent = message;
            toast.classList.add('show');
            setTimeout(() => {
                toast.classList.remove('show');
            }, 3000);
        }

        // Initialize on load
        init();
    </script>
@endsection