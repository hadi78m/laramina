<?php

namespace App\Http\Controllers;

use App\Models\Permission;
use App\Models\Role;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class RolesController extends Controller
{
    //

    public function index()
    {
        $roles = Role::all();
        return view('roles.index', compact('roles'));
    }

    public function json(Request $request)
    {
        $data =  Role::adminTable($request, [
            'search' => ['name'],
            'filters' => ['name'],
        ]);

        return $data;
    }

    public function rolesList()
    {
        return Role::select('name')->orderBy('name')->get();
    }

    public function store(Request $request)
    {


        $request->validate([
            'name' => 'required|min:4'
        ], [

            'name.required' => 'نام اجباری است',
            'name.min' => ' نام حداقل 4 رقم می باشد',
        ]);
        DB::beginTransaction();

        $role =  Role::create(
            [
                'name' =>  $request->name,
                'guard_name' => 'web'
            ]
        );
        DB::commit();


        if ($role) {
            return response()->json([
                'success' => true,
                'message' => 'نقش با موفقیت اضافه شد.',
            ], 200);
        } else {
            return response()->json([
                'success' => false,
                'message' => 'خطا در افزودن نقش',
            ], 400);
        }
    }

    public function update(Request $request, $id)
    {
        $role = Role::findOrFail($id);

        $request->validate([
            'name' => 'required|min:4'
        ], [
            'name.required' => 'نام اجباری است',
            'name.min' => ' نام حداقل 4 رقم می باشد',
        ]);
        DB::beginTransaction();

        $role->update(
            [
                'name' =>  $request->name,
            ]
        );
        DB::commit();

        if ($role) {
            return response()->json([
                'success' => true,
                'message' => 'به روز رسانی نقش با موفقیت انجام شد.',
            ], 200);
        } else {
            return response()->json([
                'success' => false,
                'message' => 'خطا در انجام عملیات',
            ], 400);
        }
    }

    public function destroy($id)
    {
        $role = Role::find($id);
        if ($role->name == 'SuperAdmin') {
            return response()->json([
                'success' => false,
                'message' => 'نقش اصلی قابل حذف نمی باشد',
            ], 400);
        }
        $count = User::role($role->name)->count();

        if ($count > 0) {
            return response()->json([
                'success' => false,
                'message' => 'نقش موجود دارای کاربر فعال است و قابل حذف نمی باشد',
            ], 400);
        }

        Role::destroy($id);
        return response()->json([
            'success' => true,
            'message' => 'حذف نقش با موفقیت انجام شد.',
        ], 200);
    }
}
