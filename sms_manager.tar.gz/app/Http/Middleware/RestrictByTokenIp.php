<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Laravel\Sanctum\PersonalAccessToken;

class RestrictByTokenIp
{
    public function handle(Request $request, Closure $next)
    {
        $token = $request->bearerToken();

        if ($token) {
            $accessToken = PersonalAccessToken::findToken($token);

            if ($accessToken) {
                $credential = $accessToken->tokenable;

                if ($credential && $credential->allowed_ip) {
                    if ($request->ip() !== $credential->allowed_ip) {
                        return response()->json([
                            'success' => false,
                            'message' => 'آی‌پی مجاز نیست برای این توکن',
                        ], 403);
                    }
                }
            }
        }

        return $next($request);
    }
}