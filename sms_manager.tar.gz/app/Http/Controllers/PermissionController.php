<?php

namespace App\Http\Controllers;

use App\Models\Permission;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class PermissionController extends Controller
{
    //

    public function index()
    {
        $permissions = Permission::all();
        return view('permissions.index', compact('permissions'));
    }

    public function json(Request $request)
    {
        $data =  Permission::adminTable($request, [
            'search' => ['name'],
            'filters' => ['name'],
        ]);

        return $data;
    }



    public function permissionsList()
    {
        return Permission::select('name','id')->orderBy('name')->get();
    }

    public function store(Request $request)
    {
        $request->validate([
            'name' => 'required|min:4'
        ], [

            'name.required' => 'نام اجباری است',
            'name.min' => ' نام حداقل 4 رقم می باشد',
        ]);
        DB::beginTransaction();
        $permission = Permission::create(
            [
                'name' =>  $request->name,
                'guard_name' => 'web'
            ]
        );
        DB::commit();


        // $permission->syncRoles($request->roles);

        if ($permission) {
            return response()->json([
                'success' => true,
                'message' => 'دسترسی با موفقیت اضافه شد.',
            ], 200);
        } else {
            return response()->json([
                'success' => false,
                'message' => 'خطا در افزودن دسترسی',
            ], 200);
        }
    }

    public function update(Request $request, $id)
    {
        $permission = Permission::findOrFail($id);

        $request->validate([
            'name' => 'required|min:4'
        ], [
            'name.required' => 'نام اجباری است',
            'name.min' => ' نام حداقل 4 رقم می باشد',
        ]);
        DB::beginTransaction();

        $permission->update(
            [
                'name' =>  $request->name,
            ]
        );
        DB::commit();

        if ($permission) {
            return response()->json([
                'success' => true,
                'message' => 'به روز رسانی دسترسی با موفقیت انجام شد.',
            ], 200);
        } else {
            return response()->json([
                'success' => false,
                'message' => 'خطا در انجام عملیات',
            ], 400);
        }
    }

    /**
     * destroy
     *
     * @param  mixed $id
     * 
     */
    public function destroy($id)
    {
        $role = Permission::find($id);

        $count = User::permission($role->name)->count();

        if ($count > 0) {
            return response()->json([
                'success' => false,
                'message' => 'دسترسی موجود دارای کاربر فعال است و قابل حذف نمی باشد',
            ], 400);
        }

        Permission::destroy($id);
        return response()->json([
            'success' => true,
            'message' => 'حذف دسترسی با موفقیت انجام شد.',
        ], 200);
    }
}
