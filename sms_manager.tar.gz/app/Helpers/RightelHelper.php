<?php

namespace App\Helpers;

use App\Models\Sms\Provider;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;

class RightelHelper
{

    /**
     * متد جامع ارسال (معمولی و OTP)
     */
    public static function send($to, $message, Provider $provider, $isOtp = false, $otpId = null)
    {
        // ۱. انتخاب شماره رندوم از شماره‌های فعال پروایدر
        $randomRow = $provider->numbers()->where('is_active', true)->inRandomOrder()->first();

        if (!$randomRow) {
            return ['status' => 'error', 'description' => 'هیچ شماره فعالی برای این پروایدر یافت نشد.'];
        }

        // ۲. تعیین آدرس و بدنه درخواست بر اساس نوع ارسال
        $endpoint = $isOtp ? "/Messages/SendOtp" : "/Messages/Send";
        $url = rtrim($provider->url, '/') . $endpoint;

        // ساخت پیام بر اساس نوع
        if ($isOtp) {
            // OTP: اضافه کردن پیشوند احراز هویت
            $otpMessage = "وزارت تعاون کار و رفاه اجتماعی، کد سامانه احراز هویت: $message";
            $payload = [
                'senderNumber'     => (string) $randomRow->number,
                'recipientNumbers' => (array) $to,
                'otpId'            => (int) $otpId,
                'parameters'       => [(string) $otpMessage],
            ];
        } else {
            // پیامک معمولی: بدون پیشوند
            $payload = [
                'senderNumber'     => (string) $randomRow->number,
                'recipientNumbers' => (array) $to,
                'messageBodies'    => [(string) $message],
            ];
        }

        try {
            /****use online */
            // verify: false → غیرفعال کردن بررسی SSL فقط در شرایط زیر مجاز است:
            // ۱. محیط توسعه محلی (local) با گواهی self-signed
            // ۲. تست اتصال به API با گواهی نامعتبر
            // ⚠️ در محیط production حتماً verify را true بگذارید
            $response = Http::withHeaders([
                'Authorization'        => $provider->token,
                'Content-Type' => 'application/json',
            ])->withOptions(['verify' => false])->post($url, $payload);


            $res = $response->json();
            /***end use online */
            /**
             *  use local
             */
            // $res = self::localResponse('otp');
            /**
             * end use local
             */


            $statusCode = $res['statusCode'] ?? null;

            // ۳. بررسی موفقیت (۱ و ۲ برای معمولی، ۳۲ برای OTP)
            $isSuccessful = $isOtp ? ($statusCode == 32) : in_array($statusCode, [1, 2]);

            return [
                'status'      => $isSuccessful ? 'success' : 'error',
                'message_id'  => $res['messageId'] ?? null,
                'description' => self::getPersianMessage($statusCode),
                'full_res'    => $res
            ];
        } catch (\Exception $e) {
            Log::error("Rightel API Error: " . $e->getMessage());
            return ['status' => 'error', 'description' => 'خطا در اتصال به سرویس‌دهنده'];
        }
    }



    private static function getPersianMessage($code)
    {
        $statusMessages = [
            // کدهای موفقیت
            '1'  => 'ارسال تکی انجام شده است',
            '2'  => 'ارسال نظیر به نظیر انجام شده است',
            '32' => 'ارسال پیامک احرازهویت (OTP) انجام شده است',

            // کدهای خطا (بر اساس فایل های ارسالی شما)
            '4'  => 'تعداد گیرندگان با تعداد پیامک همخوانی ندارد',
            '5'  => 'متن پیامک دارای کلمه(کلمات) فیلتر شده است',
            '6'  => 'مجاز به ارسال لینک در متن پیام نمی باشید',
            '7'  => 'لیست گیرندگان خالی است',
            '8'  => 'سازمان یافت نشد یا غیر فعال است یا احراز هویت نشده',
            '9'  => 'سازمان غیر فعال است',
            '10' => 'سازمان منقضی شده است',
            '11' => 'سازمان جاری یا یکی از سازمان های پدر غیرفعال است',
            '12' => 'زمان ارسال خارج از بازه مجاز سازمان می باشد',
            '13' => 'ارسال کاربر غیر فعال است',
            '14' => 'کاربر منقضی شده است',
            '15' => 'اطلاعات کاربر پیدا نشد یا احراز هویت انجام نشده است',
            '16' => 'سازمان والد منقضی شده است',
            '17' => 'شماره فرستنده معتبر یا فعال نیست یا خط منقضی شده است',
            '18' => 'شماره فرستنده غیرفعال است',
            '21' => 'خطا در ثبت در صف ارسال',
            '22' => 'لیست گیرندگان با توجه به لیست سیاه خالی است',
            '23' => 'تعداد گیرندگان با توجه با بخش های پیامک بیشتر از 100 است',
            '24' => 'متن پیامک خالی است',
            '25' => 'عملیات ناموفق',
            '26' => 'تعداد گیرندگان بیشتر از 100 است',
            '27' => 'خطا در ثبت در صف',
            '29' => 'پارامترها با پیام تعریف شده همخوانی ندارد',
            '30' => 'پارامترهای پیام نامعتبر (OTP)',
            '31' => 'اطلاعات قالب پیامک احرازهویت یافت نشد',
            '33' => 'توکن خالی است',
            '34' => 'توکن نامعتبر است',
            '35' => 'توکن منقضی شده است',
        ];

        return $statusMessages[(string)$code] ?? "خطای ناشناخته (کد: $code)";
    }

    public static function localResponse($type = 'otp')
    {

        if ($type == 'otp') {

            return [
                "messageId" => 9611,
                "statusCode" => 32,
                "blackListCount" => 0
            ];
        } elseif ($type == 'bale') {
            return [
                "message_id" => "523e6875-7c41-491b-8460-04b33039d7fc",
                // "error_data" => null
            ];
        } elseif ($type == 'sms') {
            return [
                "messageId" => 17688,
                "statusCode" => 1,
                "blackListCount" => 0
            ];
        }
    }
}
