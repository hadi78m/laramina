# SMS Manager

پنل مدیریت پیامک - سامانه ارسال و مدیریت پیامک‌های تکی، بالکی و احراز هویت (OTP)

---

## قابلیت‌ها

### مدیریت پیامک
- ارسال پیامک تکی و بالکی (حداکثر ۱۰۰ شماره)
- ارسال فوری پیامک احراز هویت (OTP)
- صف ارسال پیامک با Queue Worker
- مدیریت محدودیت روزانه ارسال

### مدیریت پروایدرها
- پشتیبانی از پروایدرهای متنوع (رایتل، چلچل، مجفا و...)
- افزودن و ویرایش پروایدرها (فقط سوپر ادمین)
- مدیریت شماره‌های هر پروایدر
- تست اتصال به پروایدر
- تعیین پروایدر پیش‌فرض

### مدیریت پیام‌رسان‌ها
- پشتیبانی از پیام‌رسان بله
- افزودن و ویرایش پیام‌رسان‌ها (فقط سوپر ادمین)
- ارسال همزمان به پیام‌رسان و پروایدر پیامکی

### مدیریت کلمات غیرمجاز
- تعریف کلمات ممنوعه
- بررسی خودکار متن پیامک قبل از ارسال
- مسدود کردن پیامک‌های حاوی کلمات غیرمجاز

### مدیریت کاربران
- سیستم نقش و دسترسی (SuperAdmin, Admin, User)
- ایجاد و مدیریت Credential (static_token برای احراز هویت API)
- توکن دسترسی با اعتبار ۱ سال
- محدودیت دسترسی IP (اختیاری)

### API
- RESTful API برای ارسال پیامک
- مستندات کامل در `README-API-new.md`

---

## تکنولوژی‌ها

| بخش | تکنولوژی |
|-----|----------|
| فریمورک | Laravel 12 |
| PHP | 8.2 |
| دیتابیس | MySQL 8.0 |
| فرانت‌اند | Livewire, Blade, Tailwind CSS |
| Queue | Database |
| احراز هویت | Sanctum |
| نقش و دسترسی | Spatie Permission |
| مانیتورینگ | Telescope, Pulse |

---

## نصب و راه‌اندازی

### روش ۱: Docker (پیشنهادی)

```bash
# کپی فایل محیطی
cp .env.docker .env

# اجرای کانتینرها
docker-compose up -d

# نصب پکیج‌ها
docker-compose exec app composer install
docker-compose exec app php artisan key:generate
docker-compose exec app php artisan migrate --force
docker-compose exec app php artisan storage:link

# ساخت assets
docker-compose run --rm node npm install
docker-compose run --rm node npm run build
```

آدرس: `http://localhost:8080`

> راهنمای کامل Docker در `DOCKER_README.md`

### روش ۲: دستی (WSL/Linux)

```bash
# نصب پیش‌نیازها
sudo apt install -y php8.2 php8.2-mysql php8.2-mbstring php8.2-xml php8.2-curl php8.2-gd php8.2-zip mysql-server apache2 libapache2-mod-php8.2

# کپی پروژه
cd /home/hadii/www
git clone <repository-url> sms_manager_full
cd sms_manager_full

# نصب پکیج‌ها
composer install
npm install
npm run build

# تنظیمات
cp .env.example .env
php artisan key:generate
php artisan migrate --force
php artisan storage:link

# دسترسی‌ها
sudo chown -R hadii:www-data storage bootstrap/cache
sudo chmod -R 775 storage bootstrap/cache
sudo chmod o+x /home/hadii
```

> راهنمای کامل در `WSL_SETUP_GUIDE.md`

### روش ۳: artisan serve

```bash
php artisan serve --host=0.0.0.0 --port=8000
```

آدرس: `http://localhost:8000`

---

## ساختار پروژه

```
sms_manager_full/
├── app/
│   ├── Http/Controllers/Sms/   # کنترلرهای API و مدیریت
│   ├── Models/Sms/             # مدل‌های دیتابیس
│   ├── Helpers/                # هلپرهای پروایدرها
│   ├── Services/Sms/           # سرویس‌های ارسال
│   └── Jobs/Sms/               # Job‌های Queue
├── config/sms/                 # تنظیمات پروایدرها
├── database/migrations/        # مایگریشن‌ها
├── docker/                     # تنظیمات Docker
├── public/                     # فایل‌های استاتیک
├── resources/views/            # قالب‌های Blade
└── routes/                     # مسیرها
```

---

## مسیرهای اصلی

### مدیریت
| مسیر | توضیح | دسترسی |
|------|-------|--------|
| `/sms/credentials` | مدیریت Credentialها | Admin, SuperAdmin |
| `/sms/providers` | مدیریت پروایدرها | SuperAdmin |
| `/sms/socials` | مدیریت پیام‌رسان‌ها | SuperAdmin |
| `/sms/messages` | مشاهده پیامک‌ها | Admin, SuperAdmin |
| `/sms/blocked-words` | مدیریت کلمات ممنوعه | Admin, SuperAdmin |

### API
| مسیر | توضیح | احراز هویت |
|------|-------|------------|
| `GET /api/v1/sms/GetIp` | دریافت آی پی | ❌ |
| `POST /api/v1/sms/send` | ارسال پیامک تکی/بالکی | Bearer Token |
| `POST /api/v1/sms/sendOtp` | ارسال OTP | Bearer Token |

> احراز هویت با `static_token` (Bearer Token) انجام می‌شود. مستندات کامل در `README-API-new.md`

---

## نقش‌ها و دسترسی‌ها

| نقش | دسترسی |
|-----|--------|
| **SuperAdmin** | دسترسی کامل + مدیریت پروایدرها و پیام‌رسان‌ها |
| **Admin** | مدیریت Credentialها، مشاهده پیامک‌ها، مدیریت کلمات ممنوعه |
| **User** | مشاهده داشبورد |

---

## متغیرهای محیطی مهم

```env
# آدرس اپلیکیشن
APP_URL=http://sms.mcls.gov.test

# دیتابیس
DB_CONNECTION=mysql
DB_HOST=127.0.0.1
DB_DATABASE=sms_panel
DB_USERNAME=sms_user
DB_PASSWORD=Ss@123456

# Queue
QUEUE_CONNECTION=database

# Cache
CACHE_STORE=file
```

---

## دستورات مفید

```bash
# اجرای Queue Worker
php artisan queue:work --queue=sms --tries=3

# پاک کردن کش
php artisan config:clear
php artisan cache:clear

# مشاهده لاگ‌ها
tail -f storage/logs/laravel.log

# بررسی مسیرها
php artisan route:list --path=api
```

---

## عیب‌یابی

### خطای `The MAC is invalid`
APP_KEY با دیتابیس مطابقت ندارد. APP_KEY محیط قبلی را در `.env` قرار دهید.

### خطای `419` (CSRF)
`SESSION_DOMAIN` را بررسی کنید. برای HTTP مقدار `null` مناسب است.

### خطای `403` (Forbidden)
```bash
sudo chmod o+x /home/hadii
sudo chown -R hadii:www-data storage bootstrap/cache
```

---

## مجوز

MIT License
