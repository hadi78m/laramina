<?php
use Illuminate\Support\Facades\Request;

$page = explode('/', Request::path());

$page0 = $page[0] ?? '';
$page1 = $page[1] ?? '';
$page2 = $page[2] ?? '';
$page3 = $page[3] ?? '';
$page_slug = $page1 . '/' . $page2;
?>

@hasanyrole(['Admin','SuperAdmin'])
{{-- @hasrole('SuperAdmin|Admin') --}}
<li class="{{ $page1 == 'credentials' ? 'bg-teal-50' : '' }}">
    <a @if ($page1 != 'credentials') href="{{ route('sms.credentials.index') }}" @endif
        class="flex items-center block p-2 hover:bg-blue-50 hover:text-red-400 rounded text-gray-700">
        <x-bi-list-check />
        <span class="mr-3">
            @lang('app.accounts')
        </span>
    </a>
</li>
@endhasanyrole

@hasanyrole(['Admin','SuperAdmin'])
<li class="{{ $page1 == 'blocked-words' ? 'bg-teal-50' : '' }}">
    <a @if ($page1 != 'records') href="{{ route('sms.blocked-words.index') }}" @endif
        class="flex items-center block p-2 hover:bg-blue-50 hover:text-red-400 rounded text-gray-700">
        <x-bi-list-check />
        <span class="mr-3">
            @lang('app.filter')
            @lang('app.words')
        </span>
    </a>
</li>
@endhasrole
@hasrole(['SuperAdmin'])
<li class="{{ $page1 == 'messages' ? 'bg-teal-50' : '' }}">
    <a @if ($page1 != 'records') href="{{ route('sms.messages.index') }}" @endif
        class="flex items-center block p-2 hover:bg-blue-50 hover:text-red-400 rounded text-gray-700">
        <x-bi-list-check />
        <span class="mr-3">
            @lang('app.list')
            @lang('app.sms.sms')
        </span>
    </a>
</li>
@endhasrole
@hasrole(['SuperAdmin'])
<li class="{{ $page1 == 'socials' ? 'bg-teal-50' : '' }}">
    <a @if ($page1 != 'socials') href="{{ route('sms.socials.index') }}" @endif class="flex items-center block
        p-2 hover:bg-blue-50 hover:text-red-400 rounded text-gray-700">
        <x-bi-list-check />
        <span class="mr-3">
            {{-- @lang('app.manager') --}}
            @lang('app.social.socials')
        </span>
    </a>
</li>
@endhasrole
@hasanyrole(['SuperAdmin'])
<li class="{{ $page1 == 'providers' ? 'bg-teal-50' : '' }}">
    <a @if ($page1 != 'providers') href="{{ route('sms.providers.index') }}" @endif
        class="flex items-center block p-2 hover:bg-blue-50 hover:text-red-400 rounded text-gray-700">
        <x-bi-list-check />
        <span class="mr-3">
            {{-- @lang('app.manager') --}}
            @lang('app.sms.providers')
        </span>
    </a>
</li>

@endhasrole
@hasanyrole(['SuperAdmin'])
@php
    // تعیین وضعیت باز بودن منو بر اساس زیرصفحات فعال (اختیاری)
    $isManagerActive = ($page1 == 'manage' || $page1 == 'users' || $page1 == 'roles' || $page1 == 'permissions' || $page1 == 'gradient' || $page1 == 'icons');
@endphp

<li x-data="{ open: {{ $isManagerActive ? 'true' : 'false' }} }" class="{{ $isManagerActive ? 'bg-teal-50' : '' }}">
    {{-- دکمه اصلی منو --}}
    <button @click="open = !open"
        class=" {{ $isManagerActive ? 'bg-teal-50' : '' }} flex items-center justify-between w-full p-2 hover:bg-blue-50 hover:text-red-400 rounded text-gray-700">
        <div class="flex items-center">
            <x-bi-list-check />
            <span class="mr-3">@lang('app.manage')</span>
        </div>
        {{-- آیکون فلش (جهت باز/بسته) --}}
        <svg x-show="!open" class="w-4 h-4 transition-transform" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7"></path>
        </svg>
        <svg x-show="open" class="w-4 h-4 transition-transform" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 15l7-7 7 7"></path>
        </svg>
    </button>

    {{-- زیرمنو (با x-show نمایش داده می‌شود) --}}
    <ul x-show="open" x-transition:enter="transition ease-out duration-200"
        x-transition:enter-start="opacity-0 transform -translate-y-2"
        x-transition:enter-end="opacity-100 transform translate-y-0"
        x-transition:leave="transition ease-in duration-150"
        x-transition:leave-start="opacity-100 transform translate-y-0"
        x-transition:leave-end="opacity-0 transform -translate-y-2" class="mr-6 mt-1 space-y-1">

        {{-- آیتم کاربران --}}
        <li>
            <a href="{{ route('manage.users.index') }}"
                class="block p-2 pr-8 hover:bg-blue-50 hover:text-red-400 rounded text-gray-700 {{ $page1 == 'users' ? 'bg-blue-100 text-red-500' : '' }}">
                <span>@lang('app.users')</span>
            </a>
        </li>

        {{-- آیتم نقش‌ها --}}
        <li>
            <a href="{{ route('manage.roles.index') }}"
                class="block p-2 pr-8 hover:bg-blue-50 hover:text-red-400 rounded text-gray-700 {{ $page1 == 'roles' ? 'bg-blue-100 text-red-500' : '' }}">
                <span>@lang('app.roles')</span>
            </a>
        </li>
        <li>
            <a href="{{ route('manage.permissions.index') }}"
                class="block p-2 pr-8 hover:bg-blue-50 hover:text-red-400 rounded text-gray-700 {{ $page1 == 'permissions' ? 'bg-blue-100 text-red-500' : '' }}">
                <span>@lang('app.permissions')</span>
            </a>
        </li>
        <li>
            <a href="{{ route('manage.gradient-generator') }}"
                class="block p-2 pr-8 hover:bg-blue-50 hover:text-red-400 rounded text-gray-700 {{ $page1 == 'gradient' ? 'bg-blue-100 text-red-500' : '' }}">
                <span>@lang('app.gradient')</span>
            </a>
        </li>
        <li>
            <a href="{{ route('icons.index') }}"
                class="block p-2 pr-8 hover:bg-blue-50 hover:text-red-400 rounded text-gray-700 {{ $page1 == 'icons' ? 'bg-blue-100 text-red-500' : '' }}">
                <span>@lang('app.icons')</span>
            </a>
        </li>
    </ul>
</li>
@endhasanyrole

