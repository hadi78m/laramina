<script>
    /*!
     | showalert.production.js
     | Enterprise SweetAlert + Ajax Helper
     | Namespace: AppAlert (Backward Compatible)
     | Requires: jQuery, SweetAlert2
     | V 0.1
     | 2026/03/11
     | github: hadi78m
     */

    window.AppAlert = (function ($, Swal) {
        'use strict';

        if (!$) throw new Error('AppAlert requires jQuery');
        if (!Swal) throw new Error('AppAlert requires SweetAlert2');

        let loadingCount = 0;
        let activeRequests = {};

        /* =========================
         * Utils
         * ========================= */

        function csrfToken() {
            return $('meta[name="csrf-token"]').attr('content') || '';
        }

        function isFormData(data) {
            return typeof FormData !== 'undefined' && data instanceof FormData;
        }

        function jq(el) {
            if (!el) return null;
            return el instanceof jQuery ? el : $(el);
        }

        function escapeHtml(str) {
            return String(str ?? '')
                .replace(/&/g, '&amp;')
                .replace(/</g, '&lt;')
                .replace(/>/g, '&gt;')
                .replace(/"/g, '&quot;')
                .replace(/'/g, '&#039;');
        }

        /* =========================
         * SweetAlert Base
         * ========================= */

        const SwalBase = Swal.mixin({
            customClass: {
                popup: 'rtl text-center',
                title: 'text-center',
                htmlContainer: 'text-center',
                confirmButton: 'btn btn-primary mx-1',
                cancelButton: 'btn btn-secondary mx-1'
            },
            buttonsStyling: false,
            reverseButtons: true
        });

        const ToastBase = Swal.mixin({
            toast: true,
            position: 'top-end',
            showConfirmButton: false,
            timer: 3000,
            timerProgressBar: true,
            customClass: { popup: 'rtl' }
        });

        /* =========================
         * Alerts
         * ========================= */

        function showToast(icon = 'success', title) {
            return ToastBase.fire({ icon, title });
        }

        function showSuccess(message = 'عملیات با موفقیت انجام شد') {
            return Swal.fire({
                icon: 'success',
                title: 'موفق',
                text: message,
                confirmButtonText: 'باشه'
            });
        }

        function showError(message = 'خطایی رخ داده است') {
            return Swal.fire({
                icon: 'error',
                title: 'خطا',
                html: message,
                confirmButtonText: 'متوجه شدم'
            });
        }

        function showLoading(title = 'در حال پردازش...') {
            loadingCount++;
            if (Swal.isVisible()) return;

            Swal.fire({
                title,
                allowOutsideClick: false,
                allowEscapeKey: false,
                showConfirmButton: false,
                didOpen: () => Swal.showLoading()
            });
        }

        function hideLoading(force = false) {
            if (force) {
                loadingCount = 0;
                Swal.close();
                return;
            }
            loadingCount = Math.max(loadingCount - 1, 0);
            if (loadingCount === 0) Swal.close();
        }

        /* =========================
         * Validation
         * ========================= */

        function clearValidation(form) {
            const $f = jq(form);
            if (!$f) return;

            $f.find('.is-invalid').removeClass('is-invalid');
            $f.find('.invalid-feedback.ajax').remove();
        }

        function showValidationErrors(form, errors) {
            const $f = jq(form);
            if (!$f || !errors) return;

            $.each(errors, function (field, messages) {
                const msg = Array.isArray(messages) ? messages[0] : messages;
                const $input = $f.find(`[name="${field}"], [name="${field}[]"]`).first();

                if ($input.length) {
                    $input.addClass('is-invalid');
                    $input.after(
                        `<div class="invalid-feedback ajax">${escapeHtml(msg)}</div>`
                    );
                }
            });
        }

        function parseValidationErrors(errors) {
            let html = '<ul class="text-start">';
            $.each(errors, function (_, msgs) {
                (Array.isArray(msgs) ? msgs : [msgs]).forEach(m => {
                    html += `<li>${escapeHtml(m)}</li>`;
                });
            });
            return html + '</ul>';
        }

        /* =========================
         * Ajax Core
         * ========================= */

        function handleAjaxError(xhr, options = {}) {
            if (xhr.status === 422 && xhr.responseJSON?.errors) {
                if (options.form) {
                    clearValidation(options.form);
                    showValidationErrors(options.form, xhr.responseJSON.errors);
                }
                showError(parseValidationErrors(xhr.responseJSON.errors));
                return;
            }

            let msg = xhr.responseJSON?.message || 'خطای سرور رخ داده است';

            if (xhr.status === 401) msg = 'دسترسی غیرمجاز';
            if (xhr.status === 403) msg = 'عدم دسترسی';
            if (xhr.status === 419) msg = 'نشست منقضی شده است';
            if (xhr.status === 500) msg = 'خطای داخلی سرور';

            showError(msg);
        }

        function ajax(url, options = {}) {
            const opts = $.extend(true, {
                method: 'POST',
                data: {},
                form: null,
                button: null,
                loading: true,
                successAlert: false,
                successMessage: null,
                reloadTable: null
            }, options);

            const key = `${opts.method}:${url}`;
            if (activeRequests[key]) return;

            activeRequests[key] = true;

            if (opts.form) clearValidation(opts.form);
            if (opts.loading) showLoading();

            return $.ajax({
                url,
                type: opts.method,
                data: opts.data,
                processData: !isFormData(opts.data),
                contentType: isFormData(opts.data) ? false : undefined,
                headers: { 'X-CSRF-TOKEN': csrfToken() },
                success(res) {
                    if (opts.successAlert) {
                        showSuccess(opts.successMessage || res.message);
                    }
                    if (opts.reloadTable) {
                        reloadDataTable(opts.reloadTable);
                    }
                    opts.success && opts.success(res);
                },
                error(xhr) {
                    handleAjaxError(xhr, opts);
                },
                complete() {
                    delete activeRequests[key];
                    hideLoading();
                }
            });
        }

        /* =========================
         * Helpers
         * ========================= */

        function post(url, data, options = {}) {
            return ajax(url, $.extend(options, { method: 'POST', data }));
        }

        function del(url, data, options = {}) {
            return ajax(url, $.extend(options, { method: 'DELETE', data }));
        }

        function confirmDelete(url, options = {}) {
            return Swal.fire({
                title: options.title || 'حذف شود؟',
                text: options.text || 'این عملیات قابل بازگشت نیست',
                icon: 'warning',
                showCancelButton: true,
                confirmButtonText: 'بله',
                cancelButtonText: 'انصراف'
            }).then(res => {
                if (res.isConfirmed) {
                    return del(url, options.data || {}, options);
                }
            });
        }

        function ajaxForm(form, options = {}) {
            const $f = jq(form);
            if (!$f) return;

            $f.on('submit.appAlert', function (e) {
                e.preventDefault();
                const hasFile = $f.find('input[type=file]').length > 0;
                const data = hasFile ? new FormData(this) : $f.serialize();

                ajax($f.attr('action'), $.extend(options, {
                    method: $f.attr('method') || 'POST',
                    data,
                    form: $f
                }));
            });
        }

        function reloadDataTable(table) {
            if ($.fn.DataTable && table instanceof $.fn.dataTable.Api) {
                table.ajax.reload();
            } else {
                const $t = jq(table);
                if ($t && $.fn.DataTable.isDataTable($t)) {
                    $t.DataTable().ajax.reload();
                }
            }
        }

        /* =========================
         * Public API
         * ========================= */

        return {
            SwalBase,
            ToastBase,

            showToast,
            showSuccess,
            showError,
            showLoading,
            hideLoading,

            clearValidation,
            showValidationErrors,
            handleAjaxError,

            ajax,
            post,
            delete: del,
            confirmDelete,
            ajaxForm,
            reloadDataTable
        };

    })(jQuery, Swal);
</script>