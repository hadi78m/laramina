<?php

namespace App\Jobs\Sms;

use App\Models\Sms\Message;
use App\Services\Sms\SmsSenderService;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Queue\SerializesModels;
use Illuminate\Support\Facades\Log;

class SendSingleSmsJob implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    public $tries = 3;           // حداکثر ۳ بار تلاش
    public $backoff = [10, 30, 60]; // فاصله بین تلاش‌ها
    public $timeout = 30;          // حداکثر ۳۰ ثانیه برای هر پیام

    protected $messageId;

    public function __construct($messageId)
    {
        $this->messageId = $messageId;
    }

    public function handle(SmsSenderService $sender)
    {
        $message = Message::find($this->messageId);

        if (!$message || $message->status !== 'pending') {
            return; // قبلاً ارسال شده یا بلاک شده
        }
        Log::info("Sending SMS of type {$message->type} to {$message->recipient}");

        $result = $sender->sendToProvider($message->recipient, $message->message);

        if ($result['success']) {
            $message->markAsSent($result['gateway_id']);
        } else {
            $message->markAsFailed($result['error'] ?? 'خطای ناشناخته در ارسال');
            
            // اگر خطای موقت بود (مثل timeout) دوباره تلاش می‌شود
            if ($this->attempts() >= $this->tries) {
                Log::warning('ارسال پیامک ناموفق پس از چند تلاش', [
                    'message_id' => $message->id,
                    'error' => $result['error']
                ]);
            }
        }
    }

    // اگر بعد از ۳ تلاش هم نشد، اینجا مدیریت کنید (مثلاً ایمیل به ادمین)
    public function failed(\Throwable $exception)
    {
        $message = Message::find($this->messageId);
        if ($message) {
            $message->markAsFailed('خطا در ارسال پس از چند تلاش: ' . $exception->getMessage());
        }
    }
}