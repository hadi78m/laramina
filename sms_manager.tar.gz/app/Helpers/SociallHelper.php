<?php

namespace App\Helpers;

use App\Models\Sms\Social;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;

class SociallHelper
{

    /**
     * متد جامع ارسال (معمولی و OTP) با پیام رسان بله 
     */
    public static function send($to, $message, Social $Social, $isOtp = false)
    {

        // تصحیح و بررسی شماره های ورودی
        $to = '98' . NumbersHelper::normalizeMobile($to);
        $payload = [
            'phone_number' => $to,
            // 'message_data' => ['otp_message' => ['otp' => $message]]
        ];

        if ($isOtp) {
            $payload['message_data'] = ['otp_message' => ['otp' => $message]]; // در OTP، پیام همان آرایه پارامترهاست
        }
        // else {
        //     $payload['messageBodies'] = (array) $message;
        // }

        try {
            /****use online */
            // $response = Http::withHeaders([
            //     'Authorization'        => $Social->token,
            //     'Content-Type' => 'application/json',
            // ])->withOptions(['verify' => false])->post($Social->url, $payload);


            // $res = $response->json();
            /***end use online */
            /**
             *  use local
             */
            $res = self::localResponse('bale');
            /**
             * end use local
             */


            $statusCode = $res['error_data'] ?? null;

            // ۳. بررسی موفقیت (۱ و ۲ برای معمولی، ۳۲ برای OTP)
            $isSuccessful = $isOtp ? ($statusCode == null) : $statusCode;

            return [
                'status'      => $isSuccessful ? 'success' : 'error',
                'message_id'  => $res['message_id'] ?? null,
                'description' => self::getPersianMessage($statusCode),
                'full_res'    => $res
            ];
        } catch (\Exception $e) {
            Log::error("Social (Bale) API Error: " . $e->getMessage());
            return ['status' => 'error', 'description' => 'خطا در اتصال به سرویس‌دهنده'];
        }
    }


    private static function getPersianMessage($code)
    {
        $statusMessages = [
            '2' =>    'خطای داخلی سرور',
            '3' =>    'بیش از حد مجاز پیام ارسال شده',
            '4' =>    'ورودی JSON نامعتبر',
            '8' =>    'شماره اشتباه است',
            '17' =>    'کاربر اکانت بله ندارد',
            '20' =>    'اعتبار کافی وجود ندارد',
        ];

        return $statusMessages[(string)$code] ?? "خطای ناشناخته (کد: $code)";
    }

    public static function localResponse($type = 'bale')
    {
        if ($type == 'bale') {
            return [
                "message_id" => "523e6875-7c41-491b-8460-04b33039d7fc",
                // "error_data" => null
            ];
        }

        return null;
    }
}
