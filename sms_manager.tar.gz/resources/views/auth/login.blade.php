<x-guest-layout>

    <div class="relative z-10 w-full max-w-2xl min-h-[960px] flex items-center justify-center">
        <div
            class="bg-white/95 backdrop-blur-md w-full rounded-3xl shadow-2xl overflow-hidden border border-white/30 flex flex-col max-h-[900px]">
            <!-- Header -->
            <div class="bg-gradient-to-br from-primary to-secondary p-10 pb-16 text-white relative overflow-hidden">
                <div class="absolute -top-12 -right-12 w-48 h-48 bg-white/10 rounded-full"></div>
                <div class="absolute -bottom-8 -left-8 w-36 h-36 bg-white/5 rounded-full"></div>

                <div class="flex items-center gap-3 mb-5">
                    <div class="bg-white/20 p-2.5 rounded-xl flex items-center justify-center text-center">
                        <i class="material-icons text-white">notifications_active</i>

                    </div>
                    <span class="text-2xl font-bold tracking-tight text-center">@lang('app.login_title')</span>
                </div>
            </div>

            <!-- Body -->
            <div class="flex-1 px-10 pb-10 -mt-8 flex flex-col">
                <div class="bg-white rounded-2xl shadow-sm p-8 border border-gray-200 mt-4">
                    <h2 class="text-2xl font-bold mb-6 text-center text-gray-900">@lang('app.login_to_account')</h2>

                    <form method="POST" action="{{ route('login') }}">
                        @csrf
                        <div class="mb-5 relative">
                            <label for="email" class="block text-sm font-medium text-gray-900 mb-2"> @lang('app.email')
                                :
                            </label>
                            <i class="material-icons absolute left-4 top-10 text-gray-500 text-xl">email</i>

                            <input dir="ltr" type="email" name="email" :value="old('email')" required autofocus
                                autocomplete="off"
                                class="w-full py-3.5 pl-12 pr-4 border-2 border-gray-200 rounded-xl text-base focus:outline-none focus:border-primary focus:bg-white bg-gray-50 transition-all"
                                placeholder="admin@company.com">
                            <x-input-error :messages="$errors->get('email')" class="mt-2"></x-input-error>
                        </div>

                        <div class="mb-5 relative">
                            <label for="password" class="block text-sm font-medium text-gray-900 mb-2">
                                @lang('app.password'):
                            </label>
                            <i class="material-icons absolute left-4 top-10 text-gray-500 text-xl">lock</i>

                            <input dir="ltr" type="password" id="password" name="password" required
                                autocomplete="current-password"
                                class="w-full py-3.5 pl-12 pr-4 border-2 border-gray-200 rounded-xl text-base focus:outline-none focus:border-primary focus:bg-white bg-gray-50 transition-all"
                                placeholder="••••••••">
                            <x-input-error :messages="$errors->get('password')" class="mt-2"></x-input-error>

                        </div>
                        <button type="submit"
                            class="w-full py-4 bg-primary text-white rounded-xl text-base font-semibold cursor-pointer hover:bg-primary-hover transition-all flex items-center justify-center gap-2 shadow-lg hover:shadow-xl hover:-translate-y-0.5">
                            @lang('app.login')
                            <i class="material-icons">arrow_forward</i>
                        </button>
                    </form>

                </div>

                <div class="mt-8 text-center border-t border-dashed border-gray-200 pt-5">
                    <div
                        class="w-full h-44 rounded-2xl overflow-hidden relative bg-gray-100 flex items-center justify-center">
                        <img src="{{asset('img/phone.png')}}" alt="Device Authentication"
                            class="w-full  object-cover object-center">
                    </div>
                </div>
            </div>
        </div>
    </div>

</x-guest-layout>