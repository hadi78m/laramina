<?php

namespace App\Models\Sms;

use Illuminate\Bus\Batchable;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Message extends Model
{
    use HasFactory, Batchable;

    protected $table = 'sms_messages';
    protected $fillable = [
        'sms_credential_id',
        'recipient',
        'message',
        'status',
        'status_reason',
        'blocked_reason',
        'blocked_words',
        'gateway_message_id',
        'sent_at',
        'type',
        'social',
        'social_status',
        'social_message_id',
    ];

    protected $casts = [
        'type' => 'string',
        'blocked_words' => 'array',
        'sent_at' => 'datetime',
    ];

    /**
     * رابطه با اعتبارنامه
     */
    public function credential()
    {
        return $this->belongsTo(Credential::class, 'sms_credential_id');
    }

    /**
     * تنظیم وضعیت مسدود شده
     */
    public function markAsBlocked($reason, $blockedWords = [])
    {
        $this->update([
            'status' => 'blocked',
            'blocked_reason' => $reason,
            'blocked_words' => $blockedWords,
        ]);
    }

    /**
     * تنظیم وضعیت در انتظار ارسال
     */
    public function markAsPending()
    {
        $this->update([
            'status' => 'pending',
        ]);
    }

    /**
     * تنظیم وضعیت ارسال شده
     */
    public function markAsSent($messageId = null)
    {
        $this->update([
            'status' => 'sent',
            'gateway_message_id' => $messageId,
            'sent_at' => now(),
        ]);
    }

    /**
     * تنظیم وضعیت خطا
     */
    public function markAsFailed($reason)
    {
        $this->update([
            'status' => 'failed',
            'status_reason' => $reason,
        ]);
    }
    /**
     * تنظیم وضعیت ارسال با پیام رسان
     */
    public function markAsSocial($status = null, $social = null, $messageId = null)
    {
        
        $this->update([
            'social_status' => $status,
            'social' => $social,
            'social_message_id' => $messageId,
        ]);
    }
}
