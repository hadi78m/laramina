<?php

namespace App\Models\Sms;

use App\AdminPlatform\Traits\AdminTableTrait;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Contracts\Auth\Authenticatable;
use Illuminate\Auth\Authenticatable as AuthenticatableTrait;
use Laravel\Sanctum\HasApiTokens;
use Laravel\Sanctum\PersonalAccessToken;

class Credential extends Model implements Authenticatable
{
    use HasFactory, AuthenticatableTrait, HasApiTokens;

    use AdminTableTrait;
    protected $table = 'sms_credentials';
    protected $fillable = [
        'name',
        'website',
        'password',
        'description',
        'is_active',
        'daily_limit',
        'messages_sent_today',
        'last_reset_date',
        'static_token',
        'allowed_ip',
        'static_token_plain'

    ];

    protected $casts = [
        'is_active' => 'boolean',
        'daily_limit' => 'integer',
        'messages_sent_today' => 'integer',
        'static_token_plain' => 'encrypted', // Laravel 9+ به صورت خودکار encrypt/decrypt می‌کند


    ];

    public function messages()
    {
        return $this->hasMany(Message::class, 'sms_credential_id');
    }


    // بقیه متدهای canSendMessage و ... مثل قبل
    public function canSendMessage($count = 1)
    {
        if (!$this->is_active) {
            return ['can_send' => false, 'reason' => 'حساب کاربری شما غیرفعال است'];
        }

        $this->resetDailyCountIfNeeded();

        // ارسال نامحدود 
        if ($this->daily_limit == 0 || $this->daily_limit == null) {
            return ['can_send' => true];
        }
        // بررسی محدودیت ارسال 
        if (($this->messages_sent_today + $count) > $this->daily_limit) {
            return ['can_send' => false, 'reason' => 'شما به محدودیت روزانه رسیده اید.'];
        }

        return ['can_send' => true];
    }

    public function incrementDailyCount($count = 1)
    {

        $this->resetDailyCountIfNeeded();
        $this->increment('messages_sent_today', $count);
    }

    private function resetDailyCountIfNeeded()
    {
        $today = now()->toDateString();
        if ($this->last_reset_date != $today) {
            $this->update([
                'messages_sent_today' => 0,
                'last_reset_date' => $today,
            ]);
        }
    }

    // متدهای احراز هویت
    public function getAuthIdentifierName()
    {
        return 'website';
    }
    public function getAuthIdentifier()
    {
        return $this->website;
    }
    public function getAuthPassword()
    {
        return $this->password;
    }
    public function getRememberToken()
    {
        return $this->remember_token;
    }
    public function setRememberToken($value)
    {
        $this->remember_token = $value;
    }
    public function getRememberTokenName()
    {
        return 'remember_token';
    }

    // public function tokens()
    // {
    //     return $this->hasMany(\Laravel\Sanctum\PersonalAccessToken::class, 'tokenable_id')
    //         ->where('tokenable_type', self::class);
    // }


    public function tokens()
    {
        return $this->morphMany(PersonalAccessToken::class, 'tokenable');
    }

    // یا اگر می‌خواهید فقط توکن‌های مربوط به این مدل را بگیرید:
    public function personalAccessTokens()
    {
        return $this->hasMany(PersonalAccessToken::class, 'tokenable_id')
            ->where('tokenable_type', get_class($this));
    }

    public static function adminTransform($cred)
    {
        // تعداد توکن‌های فعال
        $activeTokens = $cred->tokens()->where('expires_at', '>', now())->count();

        // تاریخ انقضای آخرین توکن

        $lastToken    = $cred->tokens()
            ->where('expires_at', '>', now())
            ->latest()->first();

        // مقداردهی امن برای last_token_expires_at
        if ($lastToken && $lastToken->expires_at) {
            $lastTokenExpiresAt =  "<div dir='ltr' class='text-center'>"
                . verta($lastToken->expires_at)->format('Y/m/d H:i')
                . "</div>";
        } else {
            $lastTokenExpiresAt = '<span class="text-gray-600  p-1 rounded-md"> ندارد </span>';
        }

        if ($activeTokens === 0 || $lastToken->name !== 'static-token') {
            $generateStatickToken = '<button id="createStaticToken" data-id="' . $cred->id . '" onclick="createStaticToken(' . $cred->id . ')" class="px-2 py-1 bg-purple-600 text-white rounded text-sm ml-1" title="ایجاد توکن استاتیک">
                        <i class="fas fa-key"></i>
                    </button>';
        } else {
            $generateStatickToken = '<button id="createStaticToken" data-id="' . $cred->id . '" onclick="createStaticToken(' . $cred->id . ')" class="px-2 py-1 bg-yellow-500 text-white rounded text-sm ml-1" title="بازسازی توکن استاتیک">
                       <i class="fas fa-sync"></i>
                    </button>
            <button onclick="extendToken(' . $cred->id . ')" data-id="' . $cred->id . '" class="px-2 py-1 bg-indigo-500 text-white rounded text-sm ml-1" title="تمدید انقضای توکن">
                        <i class="fas fa-clock"></i>
                    </button>';
        }
        return [
            'id'                  => $cred->id,
            'name'                => $cred->name,
            'website'             => $cred->website,
            'is_active'           => $cred->is_active ? 1 : 0,
            'daily_limit'         => $cred->daily_limit,
            'description'         => $cred->description,
            'allowed_ip'          => $cred->allowed_ip,
            'messages_sent_today' => $cred->messages()
                ->whereDate('created_at', today())
                ->count(),
            // 'created_at'          => "<div dir='ltr' class='text-center'>"
            //     . verta($cred->created_at)->format('Y/m/d H:i')
            //     . "</div>",

            'token_type'          => $lastToken
                ? ($lastToken->name === 'static-token'
                    ? '<span class="text-green-600 bg-gray-200 p-1 rounded-md"> استاتیک </span>'
                    : '<span class="text-blue-600 bg-gray-200 p-1 rounded-md"> داینامیک </span>')
                : '<span class="text-red-600 bg-gray-200 p-1 rounded-md"> نامشخص </span>',
            'static_token_exists' => !empty($cred->static_token_plain),
            'allowed_ip_show'     => $cred->allowed_ip ? "<span class='text-green-600 bg-gray-200 p-1 rounded-md'> $cred->allowed_ip </span>" : "<span class='text-gray-600 bg-gray-200 p-1 rounded-md'>  بدون محدودیت  </span>",

            'active_tokens_count'   => $activeTokens,
            'last_token_expires_at' => $lastTokenExpiresAt,
            'has_token'          => $activeTokens,
            'token_status'          => $activeTokens > 0
                ? '<span class="text-green-600 bg-green-300 p-1 rounded-md"> فعال </span>'
                : '<span class="text-red-600 bg-gray-200 p-1 rounded-md"> منقضی یا ندارد </span>',
            'generateStatickToken' => $generateStatickToken,
        ];
    }
}
