<?php

namespace App\Providers;

use Illuminate\Cache\RateLimiting\Limit;
use Illuminate\Support\Facades\RateLimiter;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\Event;
use App\Models\Sms\Provider;
use App\Events\ProviderUpdated; // این ایونت رو بعداً می‌سازیم
use Illuminate\Support\ServiceProvider;

class SmsRateLimiterServiceProvider extends ServiceProvider
{
    /**
     * Register any application services.
     */
    public function register(): void
    {
        //
    }

    /**
     * Bootstrap any application services.
     */
    public function boot(): void
    {
        $this->configureRateLimiters();

        // وقتی پرووایدر تغییر کرد (create/update/delete)، کش و RateLimiter رو ریفرش کن
        Event::listen([
            'eloquent.saved: ' . Provider::class,
            'eloquent.deleted: ' . Provider::class,
        ], function ($model) {
            if ($model instanceof Provider) {
                $this->clearProviderRateLimiterCache($model->id);
            }
        });
    }

    /**
     * تنظیم RateLimiterها برای تمام پرووایدرهای فعال
     */
    protected function configureRateLimiters(): void
    {
        // کش کردن لیست پرووایدرها برای ۵ دقیقه (یا بیشتر در پروداکشن)
        $providers = Cache::remember('sms_providers_for_rate_limiting', now()->addMinutes(5), function () {
            return Provider::where('is_active', true)
                ->where('rate_unit', '!=', 'unlimited') // skip unlimited
                ->select('id', 'name', 'send_rate', 'rate_unit')
                ->get();
        });

        foreach ($providers as $provider) {
            $key = "sms_provider_{$provider->id}";

            RateLimiter::for($key, function () use ($provider) {
                return match ($provider->rate_unit) {
                    'per_second' => Limit::perMinute($provider->send_rate * 60)->by($provider->id),
                    'per_minute' => Limit::perMinute($provider->send_rate)->by($provider->id),
                    'per_hour' => Limit::perHour($provider->send_rate)->by($provider->id),
                    default => Limit::perMinute($provider->send_rate)->by($provider->id),
                };
            });
        }

        // RateLimiter پیش‌فرض برای حالتی که هیچ پرووایدری وجود نداشته باشد
        RateLimiter::for('sms_default', function () {
            return Limit::perMinute(5); // نرخ ایمن پیش‌فرض
        });
    }

    /**
     * پاک کردن کش و RateLimiter برای یک پرووایدر خاص
     */
    protected function clearProviderRateLimiterCache(int $providerId): void
    {
        $key = "sms_provider_{$providerId}";

        // پاک کردن RateLimiter (Laravel این متد رو داره)
        RateLimiter::clear($key);

        // پاک کردن کش لیست پرووایدرها تا دفعه بعدی تازه لود بشه
        Cache::forget('sms_providers_for_rate_limiting');
    }
}