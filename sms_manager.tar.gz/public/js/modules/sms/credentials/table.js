import { createForm } from './forms/create-form.js'
import { credentialActions } from './actions.js'

const publicLang = AdminLang.getNamespace('common');
const moduleFields = AdminLang.getNamespace('modules.credentials.fields');
const moduleActions = AdminLang.getNamespace('modules.credentials.actions');

export default {

    endpoint: 'sms.credentials.json',
    search: true,

    headerTitle: moduleFields.header_title || (publicLang.manage + ' ' + (moduleFields.title || 'sms.credentials')),
    addButtonLabel: moduleActions.create || (publicLang.create + ' ' + (moduleActions.item || publicLang.item)),
    displayButton: true,
    actions: credentialActions,

    modalTheme: 'light',


    perPage: 10,

    modals: {
        create: {
            title: publicLang.create,
            name: publicLang.create,
            width: '500px',
            form: createForm
        },
        edit: {
            title: publicLang.edit,
            width: '500px',
            form: createForm
        }
    },

    filters: [
        {
            key: 'is_active',
            label: publicLang.status,
            type: 'select',
            options: {
                1: publicLang.active,
                0: publicLang.inactive,
            }
        },
    ],


    columns: [
        // { key: 'id', label: publicLang.id, sortable: true },
        { key: 'name', label: publicLang.name, sortable: true },
        { key: 'website', label: publicLang.website },
        { key: 'token_type', label: moduleFields.token_type },
        {
            key: 'static_token_exists',
            label: 'توکن',
            type: 'actions',
            actions: ['copyStaticToken', 'curlStaticToken'],
            visible: row => row.has_token === 1,
            roles: ['SuperAdmin', 'Admin'],
        },
        { key: 'allowed_ip_show', label: publicLang.allowed_ip || moduleFields.allowed_ip },
        { key: 'last_token_expires_at', label: publicLang.last_token_expires_at || moduleFields.last_token_expires_at },

        {
            key: 'is_active',
            label: publicLang.status || moduleFields.status,
            type: 'action-toggle',
            endpoint: 'sms.credentials.toggle-status',
            confirmTitle: publicLang.confirm_toggle_status || moduleActions.confirm_toggle_status,
            // map: {
            //     true: { label: publicLang.active, color: 'green' },
            //     false: { label: publicLang.inactive, color: 'gray' }
            // },
            icons: {
                true: { html: '<i class="fa-solid fa-toggle-on  text-lg"></i>', color: 'green' },
                false: { html: '<i class="fa-solid fa-toggle-off  text-lg"></i>', color: 'red' }
            }

        },
        { key: 'daily_limit', label: publicLang.daily_limit || moduleFields.daily_limit },
        { key: 'generateStatickToken', label: 'ایجاد توکن', roles: ['SuperAdmin', 'Admin'], },
        { key: 'messages_sent_today', label: publicLang.messages_sent_today || moduleFields.messages_sent_today },
        {
            label: publicLang.actions,
            type: 'actions',
            actions: ['edit', 'delete', 'regenerateStaticToken']
        }
    ],


}