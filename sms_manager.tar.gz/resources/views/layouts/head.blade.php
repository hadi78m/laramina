<link rel="stylesheet" href="{{ asset('css/custom.css') }}" />
<link rel="stylesheet" href="{{ asset('css/fonts.css') }}" />

{{-- <!-- SweetAlert2 --> --}}
{{-- install by npm --}}
{{-- <link rel="stylesheet" href="{{ asset('css/sweetalert/sweetalert2@11.14.4.min.css') }}"> --}}
{{-- <script src="{{ asset('js/sweetalert/sweetalert2@11.14.4.js') }}"></script> --}}


{{-- dataTables --}}
<link href="{{ asset('dist/dataTables/2.3.0/css/dataTables.dataTables.min.css') }}" rel="stylesheet">

{{-- Buttons --}}
<link rel="stylesheet" type="text/css" href="{{ asset('dist/dataTables/buttons/3.2.3/css/buttons.dataTables.min.css') }}">



{{-- select2 --}}
<link href="{{asset('css/select2/4.1.0/select2.min.css')}}" rel="stylesheet" />
{{-- persianDatepicker --}}
<link rel="stylesheet" href="{{asset('css/persianDatepicker/persianDatepicker-default.css')}}" />
