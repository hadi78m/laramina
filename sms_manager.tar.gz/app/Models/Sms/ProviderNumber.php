<?php

namespace App\Models\Sms;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class ProviderNumber extends Model
{
    use HasFactory;
    protected $table = 'provider_numbers';


    protected $fillable = ['provider_id', 'number', 'is_active'];



}
