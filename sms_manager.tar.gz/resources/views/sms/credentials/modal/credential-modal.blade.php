<!-- Modal نمایش / کپی توکن استاتیک -->
<div id="showStaticTokenModal"
    class="hidden fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center p-4">
    <div class="bg-white rounded-xl shadow-2xl w-full max-w-lg transform transition-all">
        <div
            class="bg-gradient-to-r from-purple-600 to-indigo-600 text-white px-6 py-4 rounded-t-xl flex justify-between items-center">
            <h5 class="text-lg font-bold " id="modalHeader">توکن استاتیک</h5>
            <button onclick="closeStaticTokenModal()" class="text-white hover:text-gray-200">
                <i class="fas fa-times text-xl"></i>
            </button>
        </div>
        <div class="p-6">
            <p class="text-sm text-gray-600 mb-4">این اطلاعات بلندمدت است. آن را در جای امن نگه دارید.</p>
            <div class="relative">
                <textarea id="staticTokenText" readonly
                    class="w-full px-4 py-3 border border-gray-300 rounded-lg bg-gray-50 font-mono text-sm resize-none"
                    rows="3"></textarea>

            </div>
            <p id="tokenExpiresInfo" class="mt-3 text-sm text-gray-600"></p>
            <div class="mt-6 flex gap-3">
                <button onclick="copyStaticToken()"
                    class="flex-1 px-4 py-2 bg-blue-600 text-white text-xs rounded hover:bg-blue-700">
                    کپی
                </button>
                <button onclick="closeStaticTokenModal()"
                    class="flex-1 px-4 py-2 bg-red-200 text-gray-700 rounded-lg hover:bg-gray-300">
                    بستن
                </button>
            </div>
        </div>
    </div>
</div>