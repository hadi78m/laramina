<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('social_numbers', function (Blueprint $table) {
            $table->id();
            $table->foreignId('social_id')->constrained('socials')->onDelete('cascade');
            $table->string('number'); // مثلاً 50003
            $table->boolean('is_active')->default(true);
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('social_numbers');
    }
};
