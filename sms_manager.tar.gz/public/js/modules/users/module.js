import tableConfig from './table.js'

export default {
    name: 'manage.users',

    table: tableConfig,

    init() {
        console.log('manage.users module loaded')
    }
}