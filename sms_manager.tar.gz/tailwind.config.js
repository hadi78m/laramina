import defaultTheme from "tailwindcss/defaultTheme";
import forms from "@tailwindcss/forms";
import defaultTheme from "tailwindcss/defaultTheme";
import forms from "@tailwindcss/forms";
import typography from "@tailwindcss/typography";
import line_clamp from "@tailwindcss/line-clamp";

/** @type {import('tailwindcss').Config} */
export default {
    darkMode: "class", // یا 'media' برای استفاده از تنظیمات سیستم
    content: [
        "./vendor/laravel/framework/src/Illuminate/Pagination/resources/views/*.blade.php",
        "./storage/framework/views/*.php",
        "./resources/views/**/*.blade.php",
        "./resources/**/*.js",
        "./resources/**/*.vue",
        "*.{js,jsx,ts,tsx,mdx}",
        "app/**/*.{ts,tsx}",
        "components/**/*.{ts,tsx}",

    ],

    theme: {
        extend: {
            // fontFamily: {
            //             sans: ['Inter', 'sans-serif'],
            //         },
            colors: {
                primary: '#4F46E5',
                'primary-hover': '#4338CA',
                secondary: '#06B6D4',
            }
            // maxWidth: {
            //     64: "16rem", // دقیقاً 64 پیکسل (1rem = 4px)
            // },
            // fontFamily: {
            //     sans: ['Figtree', ...defaultTheme.fontFamily.sans],
            // },
        },
        lineClamp: {
            7: "7",
            8: "8",
            9: "9",
            10: "10",
        },
    },
    variants: {
        lineClamp: ["responsive", "hover"],
    },
    plugins: [forms],
};
