    <div {{$attributes->class(['form-check form-switch rounded h-20 py-3'])}}>
        @isset($label)
        <label {{$label->attributes->class(['form-check-label  text-gray-800 mb-5'])}} for="flexSwitchCheckDefault">
            {{$label}}
        </label>
        @endisset
        <br>
        @isset($input)
        <input
          {{$input->attributes->class(['form-check-input appearance-none w-9  rounded-full justify-center mt-10 h-5 align-top bg-gray-600 bg-no-repeat bg-contain bg-gray-300 focus:outline-none cursor-pointer shadow-sm'])}}
            type="checkbox" role="switch" id="flexSwitchCheckDefault">
        @endisset
    </div>
