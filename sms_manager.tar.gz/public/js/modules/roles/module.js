import tableConfig from './table.js'

export default {
    name: 'roles.roles',

    table: tableConfig,

    init() {
        console.log('manage.roles module loaded')
    }
}