# مدیریت یکپارچه Ajax + ShowAlert + Datatable

###  راهنمای استفاده و مستندسازی تیم

### مستندات کاربردی - Ajax/SweetAlert Enterprise Helper

##### این راهنما برای تیم توسعه توضیح می‌دهد ابزارهای AppAjax چگونه استفاده و شخصی‌سازی می‌شوند.

---------

#### امکانات:
###### * تعریف بندی در namespace (window.AppAjax)
###### * نمایش پیام موفقیت/خطا با SweetAlert
###### * مدیریت اتوماتیک دکمه (غیرفعالسازی/فعالسازی هنگام ارسال)
###### * مانیتورینگ loading سراسری
###### * نمایش و انتخاب reload خودکار دیتا تیبل یا آپدیت بخش
###### * پشتیبانی فرمهای ساده وFormData(آپلود فایل)
###### * استخراج خطاهای (Laravel )error 422 و هایالیت ورودیها روی فرم
###### * مدیریت خطاهای متداول (422, 403, 401, 500) و نمایش کاربر-پسند
###### * ساخت رویداد سفارشیAppAjax:completeهنگام اتمام درخواست
###### * امکان تنظیم پیامها و رفتار پیشفرض به صورت اختیاری
------
### راه اندازی
#### اسکریپت را لود کنید

```php
<script src="/js/appajax.enterprise.js"></script>
```

---
### لیست توابع

#### 1. ارسال فرم با مدیریت همه موارد (با دکمه و نمایش پیام موفقیت)

```javascript
AppAjax.submitForm(form, options)
```

##### مثال

```javascript
AppAjax.submitForm($('#formId'), {

  button: '#btnSubmit',           // رفع دوبار کلیک
  reloadTable: window.myTable,  // اختیاری: جدول دیتاتیبل جهت reload یا false
  success: function(res) { /*۲۰۰ موفق*/ },
  error: function(xhr) { /*هر خطای سرور*/ },
});
```
#### 2. ارسال درخواست POST با مدیریت پیامها و دکمه.

```javascript
AppAjax.post(url, data, options)
```

##### مثال

```javascript
AppAjax.post('/accounts/add', {name: 'Ali'}, {
  button: '#btnSave',
  reloadTable: false,
  success: function(res) {},
});
```

#### 3. دیالوگ تایید حذف با اجرای Ajax و مدیریت دکمه و رفرش جدول.

```javascript
AppAjax.confirmAndDelete(url,options)
```

##### مثال

```javascript
AppAjax.confirmAndDelete('/items/5/delete', {
  reloadTable: myTable,
  confirmText: 'حذف قطعی!',
  success: res => { },
})
```


#### 4. تغییر پیامها و مقادیر پیشفرض به صورت لحظهای یا دائمی.

```javascript
AppAjax.setDefault(options)
```

##### مثال 

```javascript
AppAjax.setDefault({
  loadingMsg: 'لطفا صبر کنید...',
  successMsg: 'با موفقیت انجام شد!',
  errorMsg: 'خطای پیش‌بینی نشده',
})

```
#### 5. مدیریت تخصصی خطاها برای سایر درخواستها یا توسعه شخصی.

```javascript
AppAjax.handleAjaxError(xhr, form)
```

##### مثال

```javascript
```

---
### نکات تخصصی

###### *    می‌توانید هر دکمه‌ای که در رویداد Ajax دخیل است به آرگومان button بدهید تا خودکار غیرفعال شود و بعد دوباره فعال

###### *    اگر پارامتر reloadTable مقداردهی شود (به نوع DataTable یا selector جدول)، پس از موفقیت درخواست، جدول reload می‌شود

###### *    اگر فرم ارسال می‌کنید، خطاهای دریافت شده روی input های مربوطه در فرم highlight و پیام خطا کنار input نمایش داده می‌شود (در صورت داشتن کلاس Bootstrap یا مشابه)

###### *    اگر به توابع خاص‌تری نیاز دارید: تابع AppAjax.handleAjaxError(xhr, form) به شما امکان مدیریت خطا در ajaxهای خاص را می‌دهد.

###### *    این helper تمام کدهای Ajax و SweetAlert شما را بسیار کوتاه و امن می‌کند.

---
#### توجه: ابتدا باید jQuery و sweetalert2 را لود کنید.

---------

## شیوه استفاده از ShowAlert

### پیام موفق

```javascript
AppAlert.showSuccess('با موفقیت ذخیره شد');
```
#### function

```javascript
function (message = 'عملیات با موفقیت انجام شد')
```

### پیام خطا

```javascript
AppAlert.showError('مشکلی رخ داد');
```

#### function

```javascript
function (message = 'خطایی رخ داد')
```

### Toast

#### 1. مثال ها
```javascript
AppAlert.showToast('ذخیره شد');
```

```javascript
AppAlert.showToast('info','ذخیره شد');
```


#### function

```javascript
function showToast(icon = 'success', title)
```


### تایید حذف

```javascript
confirmDelete(() => {
    $.post('/delete-url', {_token: csrf}, res => {
        showSuccess(res.message);
    });
});
```

#### function

```javascript
function (callback)
```



### تایید عملیات

```javascript
confirmAction(
    'تغییر پیش‌فرض؟',
    'این پروایدر پیش‌فرض می‌شود',
    () => {
        $.post(`${providersBaseUrl}/${id}/set-default`, {_token: csrf}, res => {
            showSuccess(res.message);
        });
    }
);
```

#### function

```javascript
function (title, text, callback)
```




## شیوه استفاده از Ajax

#### حذف رکورد


```javascript
deleteAjax(`/providers/${id}/delete`, providersTable);
```

##### function

```javascript
function (url, table = null)
```

#### تغییر پیش‌فرض

```javascript
confirmAjax(
    'تغییر پیش‌فرض؟',
    'این پروایدر پیش‌فرض می‌شود',
    `${providersBaseUrl}/${id}/set-default`,
    {},
    providersTable
);
```
##### function

```javascript
function (title, text, url, data = {}, table = null)
```

### ارسال Ajax ساده

#### مثال اول
```javascript
postAjax('/providers/store', formData, function(res){
    providersTable.ajax.reload();
});
```
#### مثال دوم 

```javascript
postAjax('/providers/store', {name: 'test'}, function(res) {
    reloadDataTable(providersTable);
});
```


##### function

```javascript
function (url, data = {}, successCallback = null)
function (url, data = {}, successCallback = null, options = {})
```


### Submit فرم Ajax



##### function

```javascript
ajaxForm('#providerForm', function(res, form) {
    $('#providerModal').modal('hide');
    providersTable.ajax.reload();
});


```

```javascript
function (formSelector, successCallback = null, options = {})
```