# راه‌اندازی با Docker

## پیش‌نیازها

- [Docker Desktop](https://www.docker.com/products/docker-desktop) نصب شده باشد
- [Docker Compose](https://docs.docker.com/compose/install/) در دسترس باشد

---

## راه‌اندازی سریع

```bash
# ۱. کپی فایل محیطی
cp .env.docker .env

# ۲. ساخت و اجرای کانتینرها
docker-compose up -d

# ۳. نصب پکیج‌های Composer
docker-compose exec app composer install

# ۴. تولید کلید اپلیکیشن
docker-compose exec app php artisan key:generate

# ۵. اجرای migrationها
docker-compose exec app php artisan migrate --force

# ۶. ایجاد symlink storage
docker-compose exec app php artisan storage:link

# ۷. نصب پکیج‌های Node.js (اختیاری)
docker-compose run --rm node npm install
docker-compose run --rm node npm run build
```

حالا در مرورگر باز کنید:
```
http://localhost:8080
```

---

## دستورات مفید

```bash
# مشاهده لاگ‌های آپلیکیشن
docker-compose logs -f app

# مشاهده لاگ‌های MySQL
docker-compose logs -f mysql

# ورود به کانتینر آپلیکیشن
docker-compose exec app bash

# اجرای artisan
docker-compose exec app php artisan <command>

# اجرای Queue Worker
docker-compose exec app php artisan queue:work --tries=3

# پاک کردن کش
docker-compose exec app php artisan config:clear
docker-compose exec app php artisan cache:clear

# ساخت مجدد assets
docker-compose run --rm node npm run build

# توقف کانتینرها
docker-compose down

# حذف کانتینرها و حجم‌ها
docker-compose down -v
```

---

## ساختار پروژه

```
sms_manager_full/
├── docker/
│   └── apache/
│       └── vhost.conf
├── docker-compose.yml
├── Dockerfile
├── .dockerignore
├── .env.docker
└── ...
```

---

## پورت‌ها

| سرویس | پورت | توضیح |
|-------|------|-------|
| آپلیکیشن | 8080 | Laravel + Apache |
| MySQL | 3306 | دیتابیس |
| Redis | 6379 | کش و Session |

---

## عیب‌یابی

### مشکل: کانتینر MySQL شروع نمی‌شود
```bash
docker-compose down -v
docker-compose up -d mysql
docker-compose logs mysql
```

### مشکل: خطای permission
```bash
docker-compose exec app chown -R www-data:www-data storage bootstrap/cache
docker-compose exec app chmod -R 775 storage bootstrap/cache
```

### مشکل: خطای database connection
```bash
# بررسی اجرای MySQL
docker-compose ps mysql

# تست اتصال
docker-compose exec mysql mysql -u sms_user -p'Ss@123456' sms_panel
```

### مشکل: خطای Redis
```bash
# بررسی اتصال Redis
docker-compose exec redis redis-cli ping
```

---

## محیط توسعه vs Production

### توسعه (پیش‌فرض)
```bash
docker-compose up -d
```

### Production
```bash
# ساخت تصویر production
docker build -t sms-manager:latest .

# اجرا با متغیرهای production
docker run -d \
  --name sms-manager \
  -p 80:80 \
  -e APP_ENV=production \
  -e APP_DEBUG=false \
  -e APP_URL=https://sms.mcls.gov.test \
  sms-manager:latest
```

---

## به‌روزرسانی

```bash
# توقف کانتینرها
docker-compose down

# کشیدن تصویر جدید
docker-compose pull

# ساخت مجدد
docker-compose build --no-cache

# اجرای مجدد
docker-compose up -d

# نصب پکیج‌های جدید
docker-compose exec app composer install

# اجرای migration
docker-compose exec app php artisan migrate --force

# پاک کردن کش
docker-compose exec app php artisan config:clear
docker-compose exec app php artisan cache:clear
```
