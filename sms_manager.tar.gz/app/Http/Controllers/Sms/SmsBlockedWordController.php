<?php

namespace App\Http\Controllers\Sms;

use App\Http\Controllers\Controller;
use App\Models\Sms\BlockedWord;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Auth;

class SmsBlockedWordController extends Controller
{
    /**
     * نمایش صفحه مدیریت کلمات غیرمجاز
     */
    public function index()
    {
        return view('sms.blocked-words.bloked-words-index');
    }

    /**
     * دریافت لیست کلمات غیرمجاز
     */
    public function getWords()
    {
        try {
            $words = BlockedWord::with('creator:id,name')
                ->orderBy('created_at', 'desc')
                ->get();

            return response()->json([
                'success' => true,
                'data' => $words->map(function ($word) {
                    return [
                        'id' => $word->id,
                        'word' => $word->word,
                        'description' => $word->description,
                        'is_active' => $word->is_active,
                        'created_by' => $word->creator ? $word->creator->name : 'نامشخص',
                        'created_at' => verta($word->created_at)->format('Y/m/d H:i'),
                    ];
                }),
            ]);
        } catch (\Exception $e) {
            Log::error('خطا در دریافت لیست کلمات غیرمجاز: ' . $e->getMessage());

            return response()->json([
                'success' => false,
                'message' => 'خطا در دریافت لیست کلمات غیرمجاز',
            ], 500);
        }
    }

    /**
     * ذخیره کلمه غیرمجاز جدید
     */
    public function store(Request $request)
    {
        try {
            $validator = Validator::make($request->all(), [
                'word' => 'required|string|max:255',
                'description' => 'nullable|string',
            ], [
                'word.required' => 'کلمه الزامی است',
            ]);

            if ($validator->fails()) {
                return response()->json([
                    'success' => false,
                    'message' => $validator->errors()->first(),
                    'errors' => $validator->errors(),
                ], 422);
            }

            // بررسی تکراری بودن
            $exists = BlockedWord::where('word', $request->word)->exists();
            if ($exists) {
                return response()->json([
                    'success' => false,
                    'message' => 'این کلمه قبلاً به لیست اضافه شده است',
                ], 422);
            }

            DB::beginTransaction();

            $word = BlockedWord::create([
                'word' => $request->word,
                'description' => $request->description,
                'created_by' => Auth::id(),
                'is_active' => true,
            ]);

            DB::commit();

            return response()->json([
                'success' => true,
                'message' => 'کلمه با موفقیت به لیست اضافه شد',
                'data' => [
                    'id' => $word->id,
                    'word' => $word->word,
                ],
            ]);
        } catch (\Exception $e) {
            DB::rollBack();
            Log::error('خطا در افزودن کلمه غیرمجاز: ' . $e->getMessage());

            return response()->json([
                'success' => false,
                'message' => 'خطا در افزودن کلمه غیرمجاز',
            ], 500);
        }
    }

    /**
     * به‌روزرسانی کلمه غیرمجاز
     */
    public function update(Request $request, $id)
    {
        try {
            $word = BlockedWord::findOrFail($id);

            $validator = Validator::make($request->all(), [
                'word' => 'required|string|max:255',
                'description' => 'nullable|string',
                'is_active' => 'required|boolean',
            ], [
                'word.required' => 'کلمه الزامی است',
                'is_active.required' => 'وضعیت الزامی است',
            ]);

            if ($validator->fails()) {
                return response()->json([
                    'success' => false,
                    'message' => $validator->errors()->first(),
                    'errors' => $validator->errors(),
                ], 422);
            }

            DB::beginTransaction();

            $word->update([
                'word' => $request->word,
                'description' => $request->description,
                'is_active' => $request->is_active,
            ]);

            DB::commit();

            return response()->json([
                'success' => true,
                'message' => 'کلمه با موفقیت به‌روزرسانی شد',
            ]);
        } catch (\Exception $e) {
            DB::rollBack();
            Log::error('خطا در به‌روزرسانی کلمه غیرمجاز: ' . $e->getMessage());

            return response()->json([
                'success' => false,
                'message' => 'خطا در به‌روزرسانی کلمه غیرمجاز',
            ], 500);
        }
    }

    /**
     * حذف کلمه غیرمجاز
     */
    public function destroy($id)
    {
        try {
            $word = BlockedWord::findOrFail($id);

            DB::beginTransaction();

            $word->delete();

            DB::commit();

            return response()->json([
                'success' => true,
                'message' => 'کلمه با موفقیت حذف شد',
            ]);
        } catch (\Exception $e) {
            DB::rollBack();
            Log::error('خطا در حذف کلمه غیرمجاز: ' . $e->getMessage());

            return response()->json([
                'success' => false,
                'message' => 'خطا در حذف کلمه غیرمجاز',
            ], 500);
        }
    }

    /**
     * تغییر وضعیت فعال/غیرفعال
     */
    public function toggleStatus($id)
    {
        try {
            $word = BlockedWord::findOrFail($id);
            $word->is_active = !$word->is_active;
            $word->save();

            return response()->json([
                'success' => true,
                'message' => 'وضعیت با موفقیت تغییر کرد',
                'is_active' => $word->is_active,
            ]);
        } catch (\Exception $e) {
            Log::error('خطا در تغییر وضعیت: ' . $e->getMessage());

            return response()->json([
                'success' => false,
                'message' => 'خطا در تغییر وضعیت',
            ], 500);
        }
    }

    /**
     * بررسی متن برای کلمات غیرمجاز
     */
    public function checkText(Request $request)
    {
        try {
            $validator = Validator::make($request->all(), [
                'text' => 'required|string',
            ], [
                'text.required' => 'متن الزامی است',
            ]);
            if ($validator->fails()) {
                return response()->json([
                    'success' => false,
                    'message' => $validator->errors()->first(),
                    'errors' => $validator->errors(),
                ], 422);
            }

            $foundWords = BlockedWord::checkMessage($request->text);

            if (count($foundWords) > 0) {
                return response()->json([
                    'success' => true,
                    'data' => [
                        'has_blocked_words' => true,
                        'blocked_words' => $foundWords,
                    ],
                ]);
            } else {

                return response()->json([
                    'success' => true,
                    'data' => $foundWords,
                ]);
            }
        } catch (\Exception $e) {
            Log::error('خطا در بررسی متن: ' . $e->getMessage());

            return response()->json([
                'success' => false,
                'message' => 'خطا در بررسی متن',
            ], 500);
        }
    }
}
