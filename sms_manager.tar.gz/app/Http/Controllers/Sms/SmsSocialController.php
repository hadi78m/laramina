<?php

namespace App\Http\Controllers\Sms;

use App\Http\Controllers\Controller;
use App\Models\Sms\Social;
use App\Models\Sms\SocialNumber;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Crypt;

class SmsSocialController extends Controller
{
    public function index()
    {
        return view('sms.socials.index');
    }

    public function _json()
    {
        $socials = Social::with('creator')->orderByDesc('id')->get();

        return response()->json(['data' => $socials]);
    }
    public function json()
    {
        $socials = Social::orderByDesc('id')
            ->get();


        return response()->json([
            'success' => true,
            'data' => $socials->map(function ($cred) {
                return [
                    'id' => $cred->id,
                    'name' => $cred->name,
                    // 'user' => $cred->user,
                    'is_active' => $cred->is_active,
                    'is_default' => $cred->is_default,
                    'rate_unit' => $cred->rate_unit,
                    'url' => $cred->url,
                    'send_rate' => $cred->send_rate,
                    'created_at' => "<div dir='ltr' class='text-center'>" . verta($cred->created_at)->format('Y/m/d') ?? '' . "</div>",
                ];
            })
        ]);
    }

    public function store(Request $request)
    {
        $request->validate([
            'name' => 'required|string|max:255|unique:socials,name',
            'user' => 'nullable|string|max:255',
            'password' => 'nullable|string|min:4',
            'url' => 'nullable|url',
            'rate_unit' => 'required|in:per_second,per_minute,per_hour,unlimited',
            // 'send_rate' => 'required_unless:rate_unit,unlimited|nullable|integer|min:1', // اگر unlimited باشه، send_rate لازم نیست
        ], [
            'name.required' => 'نام الزامی است.',
            'name.unique' => 'نام قبلاً استفاده شده است.',
            'password.min' => 'رمز عبور باید حداقل ۴ کاراکتر باشد ',
            'send_rate.required_unless' => 'نرخ ارسال الزامی است',
            'url.url'=>'فرمت آدرس API صحیح نمی باشد'
        ]);

        $data = $request->only(['name', 'user', 'url', 'token']);
        $data['created_by'] = Auth::id();
        $data['send_rate'] = $request->rate_unit !== 'unlimited' ? $request->send_rate : 0;
        $data['rate_unit'] = $request->rate_unit;
        $data['is_default'] = $request->is_default ? true : false;
        $data['is_active'] = $request->is_default ? true : false;

        if ($request->filled('password')) {
            $data['password'] = Crypt::encrypt($request->password);
        }

        $social = Social::create($data);

        if ($request->has('is_default')) {
            Social::setAsDefault($social->id);
        }

        return response()->json([
            'success' => true,
            'message' => 'پروایدر با موفقیت اضافه شد.',
        ]);
    }

    public function edit($id)
    {
        $social = Social::findOrFail($id);

        // از ارسال هش پسورد به کلاینت خودداری می‌کنیم
        $social->makeHidden('password');

        return response()->json([
            'success' => true,
            'social' => $social
        ]);
    }
    public function update(Request $request, $id)
    {
        $social = Social::findOrFail($id);

        $request->validate([
            'name' => 'required|string|max:255|unique:socials,name,' . $id,
            'user' => 'nullable|string|max:255',
            'password' => 'nullable|string|min:4',
            'url' => 'nullable|url',
            'send_rate' => 'required_unless:rate_unit,unlimited|nullable|integer|min:1', // اگر unlimited باشه، send_rate لازم نیست
            'rate_unit' => 'required|in:per_second,per_minute,per_hour,unlimited',
        ]);

        $data = $request->only(['name', 'user', 'url', 'token']);
        $data['send_rate'] = $request->rate_unit !== 'unlimited' ? $request->send_rate : 0;
        $data['rate_unit'] = $request->rate_unit;
        $data['is_default'] = $request->is_default ? true : false;

        if ($request->filled('password')) {
            $data['password'] = Crypt::encrypt($request->password);
        }

        $social->update($data);

        // اصلاح مهم: حفظ وضعیت قبلی اگر چک‌باکس ارسال نشده باشد
        $social->is_active = $request->has('is_active');

        // جلوگیری از غیرفعال کردن پیش‌فرض
        if (!$social->is_active && $social->is_default) {
            return response()->json(['success' => false, 'message' => 'پروایدر پیش‌فرض را نمی‌توان غیرفعال باشد.'], 400);
        }

        $social->save();

        if ($request->has('is_default') && $social->is_active) {
            Social::setAsDefault($social->id);
        }

        return response()->json(['success' => true, 'message' => 'پروایدر با موفقیت به‌روزرسانی شد.']);
    }

    public function destroy($id)
    {
        $social = Social::findOrFail($id);

        if ($social->is_default) {
            return response()->json([
                'success' => false,
                'message' => 'پروایدر پیش‌فرض قابل حذف نیست. ابتدا پروایدر دیگری را پیش‌فرض کنید.'
            ], 400);
        }

        $social->delete();

        // اگر بعد از حذف هیچ پیش‌فرضی نبود، اولین فعال رو پیش‌فرض کن
        if (!Social::where('is_default', true)->exists()) {
            Social::where('is_active', true)->first()?->update(['is_default' => true]);
        }

        return response()->json([
            'success' => true,
            'message' => 'پروایدر با موفقیت حذف شد.'
        ]);
    }

    public function setDefault($id)
    {
        try {
            Social::setAsDefault($id);
            $social = Social::find($id);
            return response()->json([
                'success' => true,
                'message' => "پروایدر «{$social->name}» به عنوان پیش‌فرض تنظیم شد."
            ]);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => $e->getMessage()
            ], 400);
        }
    }

    // تغییر وضعیت فعال/غیرفعال
    public function toggleStatus($id)
    {
        $social = Social::findOrFail($id);

        try {
            $social->toggleStatus();
            return response()->json([
                'success' => true,
                'message' => $social->is_active ? 'پروایدر فعال شد.' : 'پروایدر غیرفعال شد.'
            ]);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => $e->getMessage()
            ], 400);
        }
    }
    public function testConnection($id)
    {
        $social = Social::findOrFail($id);

        if (!$social->url) {
            return response()->json([
                'success' => false,
                'message' => 'آدرس API تنظیم نشده است.'
            ], 400);
        }

        if (!$social->is_active) {
            return response()->json([
                'success' => false,
                'message' => 'این پروایدر غیرفعال است.'
            ], 400);
        }

        $start = microtime(true);

        try {
            $client = new \GuzzleHttp\Client([
                'timeout' => 10,
                'verify' => false, // فقط برای تست محلی - در پروداکشن حذف کنید
                'headers' => [
                    'User-Agent' => 'MCLS-SMS-Test/1.0',
                    'Accept' => 'application/json',
                ]
            ]);

            $options = ['http_errors' => false];

            // اگر نام کاربری و رمز عبور داره → Basic Auth
            if ($social->user && $social->password) {
                $options['auth'] = [$social->user, Crypt::decrypt($social->password)];
            }

            $response = $client->get($social->url, $options);

            $time = round((microtime(true) - $start) * 1000, 2);

            $statusCode = $response->getStatusCode();
            $body = $response->getBody()->getContents();

            if ($statusCode >= 200 && $statusCode < 300) {
                return response()->json([
                    'success' => true,
                    'social' => $social,
                    'response_time' => $time,
                    'message' => $this->extractMessageFromResponse($body),
                ]);
            } else {
                return response()->json([
                    'success' => false,
                    'message' => "کد پاسخ: {$statusCode} — ممکن است آدرس یا احراز هویت اشتباه باشد."
                ], 400);
            }
        } catch (\GuzzleHttp\Exception\ConnectException $e) {
            return response()->json([
                'success' => false,
                'message' => 'عدم اتصال به سرور پروایدر. آدرس یا پورت اشتباه است.'
            ], 400);
        } catch (\GuzzleHttp\Exception\RequestException $e) {
            return response()->json([
                'success' => false,
                'message' => 'خطا در درخواست: ' . $e->getMessage()
            ], 400);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'خطای غیرمنتظره: ' . $e->getMessage()
            ], 400);
        }
    }

    /**
     * extractMessageFromResponse
     * کمک برای استخراج پیام از پاسخ JSON    
     * تست اتصال از طریق API
     * @param  mixed $body
     * @return mixed
     */
    private function extractMessageFromResponse($body)
    {
        if (empty($body))
            return null;

        $data = json_decode($body, true);
        if (json_last_error() !== JSON_ERROR_NONE)
            return null;

        // پیام‌های رایج در پنل‌های ایرانی
        return $data['message'] ?? $data['msg'] ?? $data['text'] ?? $data['status'] ?? null;
    }


    // ... کدهای قبلی کنترلر باقی می‌ماند ...

    // متد جدید: لیست شماره‌های یک پروایدر
    public function numbers($socialId)
    {
        $numbers = SocialNumber::where('social_id', $socialId)->get();
        return response()->json(['success' => true, 'numbers' => $numbers]);
    }

    // متد جدید: ذخیره شماره جدید
    public function storeNumber(Request $request, $socialId)
    {
        $request->validate([
            'number' => 'required|string|max:255|unique:social_numbers,number,NULL,id,social_id,' . $socialId,
        ]);

        $number = SocialNumber::create([
            'social_id' => $socialId,
            'number' => $request->number,
            'is_active' => true,
        ]);

        return response()->json(['success' => true, 'message' => 'شماره با موفقیت اضافه شد.', 'number' => $number]);
    }

    // متد جدید: بروزرسانی وضعیت فعال/غیرفعال
    public function toggleNumberStatus($socialId, $numberId)
    {
        $number = SocialNumber::where('social_id', $socialId)->findOrFail($numberId);
        $number->is_active = !$number->is_active;
        $number->save();

        return response()->json(['success' => true, 'message' => $number->is_active ? 'شماره فعال شد.' : 'شماره غیرفعال شد.']);
    }

    // متد جدید: حذف شماره
    public function destroyNumber($socialId, $numberId)
    {
        $number = SocialNumber::where('social_id', $socialId)->findOrFail($numberId);
        $number->delete();

        return response()->json(['success' => true, 'message' => 'شماره با موفقیت حذف شد.']);
    }
}
