<?php

namespace App\Providers;

use Illuminate\Support\ServiceProvider;

use App\Console\Commands\MakeAdminUI;

class AdminPlatformServiceProvider extends ServiceProvider
{
    public function boot()
    {
        if ($this->app->runningInConsole()) {
            $this->commands([
                MakeAdminUI::class
            ]);
        }
    }
}
