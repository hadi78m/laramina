<?php

namespace App\Models;

use App\AdminPlatform\Traits\AdminTableTrait;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;
use Spatie\Permission\Traits\HasRoles;

class User extends Authenticatable
{
    use HasFactory, Notifiable, HasRoles; // تریت HasRoles تمام متدهای لازم را اضافه می‌کند
    use AdminTableTrait;

    protected $fillable = [
        'name',
        'email',
        'password',
        'is_active',
        'national_code'
    ];

    protected $hidden = [
        'password',
        'remember_token',
    ];

    protected $casts = [
        'is_active' => 'boolean',
        'email_verified_at' => 'datetime',
        'password' => 'hashed',
    ];

    // متد toggleStatus مشکلی ندارد و می‌تواند بماند
    public function toggleStatus()
    {
        $this->is_active = !$this->is_active;
        $this->save();
    }

    public static function adminTransform($cred)
    {
        // با حذف متدهای دستی، این خطوط همچنان درست کار می‌کنند
        // چون تریت HasRoles رابطه permissions و roles را فراهم می‌کند
        $roleNames = $cred->roles->pluck('name')->toArray(); 
        $permissions = $cred->permissions->pluck('name')->toArray(); 

        $primaryRole = $cred->roles->first()?->name;
        
        return [
            'id'           => $cred->id,
            'name'         => $cred->name,
            'email'        => $cred->email,
            'is_active'    => $cred->is_active,
            'national_code'=> $cred->national_code,
            'created_at'   => "<div dir='ltr' class='text-center'>"
                             . verta($cred->created_at)->format('Y/m/d H:i')
                             . "</div>",
            'roles'        => $roleNames,
            'role'         => $primaryRole,
            'permissions'  => $permissions,
        ];
    }
}
