@extends('errors::minimal')

@section('title', __('خطای 429 - تعداد درخواست‌ها زیاد'))
@section('code', '429')
{{-- @section('message', __('Too Many Requests')) --}}
@php
    // $message = 'تعداد درخواست زیاد غیر مجاز';

    // $uri = "$_SERVER[REQUEST_URI]";
    // if (strpos($uri, 'admin')) {
    //     $route = 'logout';
    //     $app = 'app.logout';
    //     $method = 'post';
    // } else {
    //     $route = 'client.home';
    //     $app = 'app.home';
    //     $method = 'get';
    // }
@endphp
@section('message')
<style>
    .bounce {
        animation: bounce 2s infinite;
    }
    @keyframes bounce {
        0%, 20%, 50%, 80%, 100% {transform: translateY(0);}
        40% {transform: translateY(-20px);}
        60% {transform: translateY(-10px);}
    }
    .progress {
        animation: progress 60s linear forwards;
    }
    @keyframes progress {
        from {width: 100%;}
        to {width: 0%;}
    }
</style>
    <div class="max-w-lg w-full bg-white rounded-xl shadow-2xl overflow-hidden">
        <div class="bg-gradient-to-r from-amber-500 to-yellow-600 p-6 text-center">
            <div class="bounce inline-block">
                <svg xmlns="http://www.w3.org/2000/svg" class="h-20 w-20 mx-auto text-white" fill="none" viewBox="0 0 24 24"
                    stroke="currentColor">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                        d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
                </svg>
            </div>
            <h1 class="text-3xl font-bold text-white mt-4">429 - درخواست‌های زیاد</h1>
        </div>

        <div class="p-8 text-center">
            <p class="text-gray-700 mb-6">شما درخواست‌های زیادی ارسال کرده‌اید!</p>

            <div class="bg-amber-50 border border-amber-200 text-amber-700 px-4 py-3 rounded mb-6">
                <div class="flex items-center justify-center space-x-2">
                    <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
                        <path fill-rule="evenodd"
                            d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7-4a1 1 0 11-2 0 1 1 0 012 0zM9 9a1 1 0 000 2v3a1 1 0 001 1h1a1 1 0 100-2h-1V9z"
                            clip-rule="evenodd" />
                    </svg>
                    <span>لطفاً <span class="font-bold" id="countdown">1 دقیقه</span> دیگر مجدداً تلاش کنید</span>
                </div>
            </div>

            <div class="mb-6">
                <div class="w-full bg-gray-200 rounded-full h-2.5 overflow-hidden">
                    <div class="bg-amber-500 h-2.5 rounded-full progress"></div>
                </div>
            </div>

            <div class="space-y-3">
                <p class="text-sm text-gray-600">توصیه هایی برای جلوگیری از محدودیت:</p>
                <ul class="text-sm text-gray-600 text-right space-y-1 list-disc pr-4">
                    <li>سرعت درخواست‌ها را کاهش دهید</li>
                    <li>از اسکریپت‌های خودکار استفاده نکنید</li>
                </ul>
            </div>

            <div class="mt-6 flex flex-col space-y-3">
                <a href="/"
                    class="bg-amber-600 hover:bg-amber-700 text-white font-medium py-2 px-4 rounded-lg transition duration-200">
                    بازگشت به صفحه اصلی
                </a>
                <a href="{{ url()->previous() }}"
                    class="text-amber-600 hover:text-amber-800 font-medium py-2 px-4 rounded-lg transition duration-200">
                    بازگشت به صفحه قبل
                </a>
            </div>
        </div>
    </div>

    <script>
        // Countdown timer
        let timeLeft = 60;
        const countdownElement = document.getElementById('countdown');

        const timer = setInterval(() => {
            timeLeft--;

            if (timeLeft <= 0) {
                clearInterval(timer);
                countdownElement.textContent = 'هم اکنون';
                document.querySelector('.progress').style.width = '0%';
            } else {
                countdownElement.textContent = timeLeft + ' ثانیه';
            }
        }, 1000);
    </script>
@endsection
