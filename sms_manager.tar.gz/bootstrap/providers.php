<?php

return [
    App\Providers\AppServiceProvider::class,
    App\Providers\SmsRateLimiterServiceProvider::class,
    App\Providers\TelescopeServiceProvider::class,
    Spatie\Permission\PermissionServiceProvider::class,
    Yajra\DataTables\DataTablesServiceProvider::class,
    App\Providers\AdminPlatformServiceProvider::class,
    // App\AdminPlatform\AdminPlatformServiceProvider::class,


];
