import tableConfig from './table.js'

export default {

    name: 'sms.providers',

    table: tableConfig,

    init() {

        console.log('sms providers module loaded')

    }

}
