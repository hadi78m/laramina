<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('socials', function (Blueprint $table) {
            $table->id();
            $table->foreignId('created_by')->constrained('users')->onDelete('cascade');
            $table->string('name')->comment('نام پیام رسان');
            $table->string('user')->comment('نام کاربری پیام رسان')->nullable();
            $table->string('password')->comment('رمز عبور پیام رسان')->nullable();
            $table->string('token')->comment('توکن  پیام رسان')->nullable();
            $table->string('url')->comment('آدرسApi پیام رسان')->nullable();
            $table->boolean('is_default')->default(false)->comment('پیام رسان پیش فرض');
            $table->boolean('is_active')->default(true);
            $table->integer('send_rate')->default(10)->nullable(); // مثلاً 10 پیامک
            $table->string('rate_unit')->default('per_minute'); // 'per_second', 'per_minute', 'per_hour'
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('socails');
    }
};
