import { defineConfig } from "vite";
import laravel from "laravel-vite-plugin";

export default defineConfig({
    plugins: [
        laravel({
            input: ["resources/css/app.css", "resources/js/app.js"],
            refresh: true,
        }),
    ],
    resolve: {
        alias: {
            jquery: 'jquery/dist/jquery.min.js'
        },
        },
    server: {
        host: "0.0.0.0", // اجازه دسترسی از همه IPها
        port: 5174,
        strictPort: true,
        hmr: {
            host: process.env.VITE_HMR_HOST || "localhost", // دامنه سفارشی شما
            protocol: "http",
        },
        cors: {
            origin: [process.env.APP_URL || "http://sms.mcls.gov.test"], // دامنه لاراول
        },
    },
});
