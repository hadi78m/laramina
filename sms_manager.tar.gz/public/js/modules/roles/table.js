import { createForm } from './forms/create-form.js'
import { roleActions } from './actions.js'

const publicLang   = AdminLang.getNamespace('common');
const moduleFields = AdminLang.getNamespace('modules.roles.fields');
const moduleActions = AdminLang.getNamespace('modules.roles.actions');

export default {

    endpoint: 'manage.roles.json',
    search: true,

    headerTitle: moduleFields.header_title || (publicLang.manage + ' ' + (moduleFields.title || 'roles.roles')),
    addButtonLabel: moduleActions.create || (publicLang.create + ' ' + (moduleActions.item || publicLang.item)),
    displayButton: true,

    actions: roleActions,

    perPage: 10,

    modalTheme: 'light',


    modals: {
        create: {
            title: moduleActions.create || publicLang.create,
            width: '500px',
            form: createForm,
            roles: ['SuperAdmin']
        },
        edit: {
            title: moduleActions.edit || publicLang.edit,
            width: '500px',
            form: createForm,
        }
    },

    columns: [
        { key: 'id', label: publicLang.id, sortable: true },
        { key: 'name', label: publicLang.name, sortable: true },
        { key: 'guard_name', label: publicLang.guard_name || moduleFields.guard_name },
        { key: 'created_at', label: publicLang.created_at, sortable: true },
        {
            label: publicLang.actions,
            type: 'actions',
            actions: ['edit', 'delete']
        }
    ],

}