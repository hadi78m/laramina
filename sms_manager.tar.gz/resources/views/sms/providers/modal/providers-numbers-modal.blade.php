{{-- دکمه‌ای برای باز کردن مودال لیست شماره‌ها --}}
<button type="button" class="btn btn-outline-primary hidden" id="btn-show-numbers">
    لیست شماره‌ها
</button>


{{-- مودال ساده --}}


<div id="numbersModal" class="hidden fixed inset-0 bg-black bg-opacity-50 z-50 items-center justify-center p-4">
    <div class="bg-white rounded-xl shadow-2xl w-full max-w-lg transform transition-all">
        <div
            class="bg-gradient-to-r from-indigo-600 to-purple-600 text-white px-6 py-4 rounded-t-xl flex justify-between items-center">
            <h5 class="text-lg font-bold">مدیریت شماره‌های پروایدر</h5>
            <button onclick="closeNumbersModal()" class="text-white hover:text-gray-200"><i
                    class="fas fa-times text-xl"></i></button>
        </div>
        <div class="p-6 space-y-5">
            <!-- فرم افزودن شماره جدید -->
            <form id="addNumberForm" class="space-y-4">
                @csrf
                <input type="hidden" id="current_provider_id" name="provider_id">
                <div>
                    <label class="block text-sm font-semibold text-gray-700 mb-2">شماره جدید <span
                            class="text-red-500">*</span></label>
                    <input type="text" name="number" required autocomplate="off"
                        class="number w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500"
                        placeholder="مثال: 50003">
                </div>
                <button type="submit"
                    class="w-full px-4 py-2 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 font-semibold">افزودن
                    شماره</button>
            </form>

            {{-- loding --}}
            <div id="numbersLoading" class="text-center py-10 hidden">
                <div
                    class="inline-block animate-spin rounded-full h-10 w-10 border-4 border-indigo-500 border-t-transparent">
                </div>
                <p class="mt-4 text-gray-600 font-medium">در حال بارگذاری شماره‌ها...</p>
            </div>
            <!-- لیست شماره‌ها -->
            <div class="mt-6  hidden" id="numbersTableDiv">
                <h6 class="text-md font-bold mb-3 text-center">شماره‌های موجود</h6>
                <table id="numbersTable" class="w-full text-sm">
                    <thead>
                        <tr class="bg-gray-50">
                            <th class="px-4 py-2 text-right">شماره</th>
                            <th class="px-4 py-2 text-right">وضعیت</th>
                            <th class="px-4 py-2 text-right">عملیات</th>
                        </tr>
                    </thead>
                    <tbody></tbody>
                </table>
            </div>
        </div>
    </div>
</div>