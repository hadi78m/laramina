# راهنمای راه‌اندازی پروژه SMS Manager روی WSL ویندوز

## مسیر پروژه: `/home/hadii/www`

> **چرا این مسیر؟**
> - نیاز به sudo ندارد
> - مدیریت دسترسی‌ها ساده‌تر است
> - برای توسعه مناسب‌تر است
> - امنیت بیشتر (خارج از web root)

---

## فهرست مطالب

1. [نصب WSL](#مرحله-۱-نصب-wsl)
2. [نصب پیش‌نیازها](#مرحله-۲-نصب-پیش‌نیازها)
3. [انتقال پروژه](#مرحله-۳-انتقال-پروژه-به-wsl)
4. [تنظیم دیتابیس](#مرحله-۴-تنظیم-دیتابیس)
5. [تنظیم .env](#مرحله-۵-تنظیم-فایل-env)
6. [نصب پکیج‌ها](#مرحله-۶-نصب-پکیج‌ها-و-راه‌اندازی)
7. [دسترسی پوشه‌ها](#مرحله-۷-دسترسی-پوشه‌ها)
8. [اجرا](#مرحله-۸-اجرای-برنامه)
9. [راه‌اندازی آپاچی](#راه‌اندازی-با-آپاچی-هاست-مجازی)
10. [راه‌اندازی SSL با mkcert](#راه‌اندازی-ssl-با-mkcert)
11. [جابه‌جایی بین HTTP و HTTPS](#جابه‌جایی-بین-http-و-https)
12. [عیب‌یابی](#عیب‌یابی-سریع)

---

## مرحله ۱: نصب WSL

در PowerShell (Admin) اجرا کنید:
```powershell
wsl --install
```
پس از نصب، ری‌استارت کنید و Ubuntu را باز کنید. نام کاربری و رمز عبور تنظیم کنید.

---

## مرحله ۲: نصب پیش‌نیازها

در ترمینال Ubuntu (WSL) اجرا کنید:

```bash
# بروزرسانی پکیج‌ها
sudo apt update && sudo apt upgrade -y

# نصب PHP 8.2 و اکستنشن‌ها
sudo apt install -y software-properties-common
sudo add-apt-repository ppa:ondrej/php -y
sudo apt update
sudo apt install -y php8.2 php8.2-cli php8.2-mbstring php8.2-xml php8.2-curl php8.2-mysql php8.2-sqlite3 php8.2-bcmath php8.2-zip php8.2-gd php8.2-redis php8.2-intl php8.2-fileinfo

# نصب Composer
sudo apt install -y unzip
curl -sS https://getcomposer.org/installer | php
sudo mv composer.phar /usr/local/bin/composer

# نصب Node.js و npm
sudo apt install -y nodejs npm

# نصب MySQL
sudo apt install -y mysql-server
sudo mysql_secure_installation

# نصب Redis
sudo apt install -y redis-server
sudo systemctl start redis-server
sudo systemctl enable redis-server
```

---

## مرحله ۳: انتقال پروژه به WSL

```bash
# ایجاد پوشه پروژه در مسیر کاربر
mkdir -p /home/hadii/www

# کپی پروژه از ویندوز (مسیر WSL از درایو D)
cp -r /mnt/d/PhpWebStudy-Data/server/www/sms_manager_full /home/hadii/www/

# رفتن به پوشه پروژه
cd /home/hadii/www/sms_manager_full
```

یا اگر می‌خواهید از همان مسیر ویندوز استفاده کنید (کندتر ولی بدون کپی):
```bash
cd /mnt/d/PhpWebStudy-Data/server/www/sms_manager_full
```

> **نکته مهم در مورد Case Sensitivity:** لینوکس به بزرگی و کوچکی حروف حساس است. اگر پروژه از ویندوز کپی شده، ممکن است فایل‌هایی با نام‌هایی مثل `Index.js` و `index.js` وجود داشته باشند. اگر مرورگر خطای MIME type یا 404 برای فایل‌های JS می‌دهد، احتمالاً مشکل case sensitivity است. راه‌حل:
> ```bash
> # بررسی فایل‌های تکراری با case متفاوت
> find public/js -name "*.js" | while read f; do basename "$f"; done | sort -f | uniq -di
> ```

---

## مرحله ۴: تنظیم دیتابیس

```bash
# ورود به MySQL
sudo mysql -u root

# ایجاد دیتابیس
CREATE DATABASE sms_panel CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
CREATE USER 'sms_user'@'localhost' IDENTIFIED BY 'secret_password';
GRANT ALL PRIVILEGES ON sms_panel.* TO 'sms_user'@'localhost';
FLUSH_PRIVILEGES;
EXIT;
```

---

## مرحله ۵: تنظیم فایل .env

```bash
# رفتن به پوشه پروژه
cd /home/hadii/www/sms_manager_full

# ویرایش فایل .env
nano .env
```

محتوای `.env` را به صورت زیر تغییر دهید:

```env
APP_NAME="SMS Manager"
APP_ENV=local
APP_KEY=
APP_DEBUG=true
APP_URL=http://sms.mcls.gov.test

DB_CONNECTION=mysql
DB_HOST=127.0.0.1
DB_PORT=3306
DB_DATABASE=sms_panel
DB_USERNAME=sms_user
DB_PASSWORD=secret_password

SESSION_DRIVER=file
QUEUE_CONNECTION=database
CACHE_STORE=file
```

نکات مهم:
- `APP_KEY` را خالی بگذارید (خودش تولید می‌شود)
- `SESSION_DRIVER=file` (بدون نیاز به Redis برای شروع)
- `QUEUE_CONNECTION=database` (بدون نیاز به Redis برای شروع)
- `CACHE_STORE=file` (بدون نیاز به Redis برای شروع)

> **نکته در مورد APP_KEY:** اگر پروژه را از محیط دیگری کپی کرده‌اید و دیتابیس را هم انتقال داده‌اید، حتماً APP_KEY محیط قبلی را در فایل `.env` قرار دهید. اگر APP_KEY جدید تولید کنید، داده‌های رمزنگاری‌شده (مثل API keys در جدول credentials) قابل خواندن نخواهند بود و خطای `The MAC is invalid` دریافت می‌کنید.

---

## مرحله ۶: نصب پکیج‌ها و راه‌اندازی

```bash
# مطمئن شوید در پوشه پروژه هستید
cd /home/hadii/www/sms_manager_full

# نصب پکیج‌های Composer
composer install

# تولید کلید اپلیکیشن
php artisan key:generate

# اجرای migrationها
php artisan migrate --force

# ایجاد symlink برای storage
php artisan storage:link

# نصب پکیج‌های Node.js (برای فرانت‌اند)
npm install

# ساخت فایل‌های CSS/JS
npm run build
```

---

## مرحله ۷: دسترسی پوشه‌ها

```bash
# تغییر مالکیت storage و cache به www-data (برای نوشتن آپاچی)
sudo chown -R hadii:www-data storage bootstrap/cache
sudo chmod -R 775 storage bootstrap/cache
```

> **نکته:** مالکیت `storage` و `bootstrap/cache` باید `hadii:www-data` باشد. کاربر `hadii` مالک باشد تا بتوانید از ترمینال ویرایش کنید و گروه `www-data` باشد تا آپاچی بتواند بنویسد.

---

## مرحله ۸: اجرای برنامه

```bash
# مطمئن شوید در پوشه پروژه هستید
cd /home/hadii/www/sms_manager_full

# اجرای سرور Laravel
php artisan serve --host=0.0.0.0 --port=8000
```

حالا در مرورگر ویندوز باز کنید:
```
http://localhost:8000
```

---

## مرحله ۹ (اختیاری): اجرای Queue Worker

اگر می‌خواهید پیامک‌ها از طریق Queue ارسال شوند، ترمینال دومی باز کنید:

```bash
cd /home/hadii/www/sms_manager_full
php artisan queue:work --tries=3
```

---

## عیب‌یابی سریع

### مشکل: دسترسی به پورت 8000
در مرورگر از `http://127.0.0.1:8000` استفاده کنید.

### مشکل: خطای دیتابیس
```bash
sudo service mysql status
sudo service mysql start
```

### مشکل: خطای permission
```bash
sudo chown -R hadii:www-data storage bootstrap/cache
sudo chmod -R 775 storage bootstrap/cache
```

### مشکل: خطای Composer
```bash
composer clear-cache
composer install
```

### مشکل: خطای Node.js
```bash
rm -rf node_modules package-lock.json
npm install
npm run build
```

### مشکل: خطای `The MAC is invalid`
دلیل: APP_KEY با داده‌های رمزنگاری‌شده در دیتابیس مطابقت ندارد.
```bash
# APP_KEY قبلی (از محیط ویندوز) را در فایل .env قرار دهید
php artisan config:clear
php artisan cache:clear
```

### مشکل: خطای `tempnam(): file created in the system's temporary directory`
این یک Warning PHP است که با `APP_DEBUG=true` نمایش داده می‌شود. روی عملکرد تأثیری ندارد.

### مشکل: خطای `NS_ERROR_CORRUPTED_CONTENT` یا MIME type برای فایل‌های JS
دلیل: حساسیت case در لینوکس.
```bash
find public/js -name "*.js" | while read f; do basename "$f"; done | sort -f | uniq -di
```

---

## دستورات مفید

```bash
# پاک کردن کش
php artisan config:clear
php artisan cache:clear
php artisan route:clear
php artisan view:clear

# مشاهده لاگ‌ها
tail -f storage/logs/laravel.log

# ورود به Tinker
php artisan tinker

# بررسی وضعیت Queue
php artisan queue:failed
```

---

## خلاصه دستورات (کپی-پیست)

```bash
sudo apt update && sudo apt upgrade -y
sudo apt install -y software-properties-common
sudo add-apt-repository ppa:ondrej/php -y
sudo apt update
sudo apt install -y php8.2 php8.2-cli php8.2-mbstring php8.2-xml php8.2-curl php8.2-mysql php8.2-sqlite3 php8.2-bcmath php8.2-zip php8.2-gd php8.2-redis php8.2-intl php8.2-fileinfo unzip redis-server mysql-server
curl -sS https://getcomposer.org/installer | php
sudo mv composer.phar /usr/local/bin/composer
sudo apt install -y nodejs npm
sudo systemctl start redis-server
sudo systemctl enable redis-server

mkdir -p /home/hadii/www
cp -r /mnt/d/PhpWebStudy-Data/server/www/sms_manager_full /home/hadii/www/
cd /home/hadii/www/sms_manager_full
composer install
php artisan key:generate
php artisan migrate --force
php artisan storage:link
npm install
npm run build
sudo chown -R hadii:www-data storage bootstrap/cache
sudo chmod -R 775 storage bootstrap/cache
php artisan serve --host=0.0.0.0 --port=8000
```

---

# راه‌اندازی با آپاچی (هاست مجازی)

اگر می‌خواهید پروژه را با آپاچی (Apache) و Virtual Host اجرا کنید، مراحل زیر را دنبال کنید.

---

## مرحله A1: نصب آپاچی و ماژول PHP

```bash
sudo apt install -y apache2
sudo apt install -y libapache2-mod-php8.2
sudo a2enmod rewrite
sudo a2enmod headers
sudo a2enmod ssl
```

---

## مرحله A2: دسترسی پوشه‌ها برای آپاچی

> **نکته مهم:** فقط پوشه‌هایی که آپاچی باید در آن‌ها بنویسد (`storage` و `bootstrap/cache`) نیاز به تغییر مالکیت دارند.

```bash
# تغییر مالکیت فقط برای storage و bootstrap/cache
sudo chown -R hadii:www-data /home/hadii/www/sms_manager_full/storage
sudo chown -R hadii:www-data /home/hadii/www/sms_manager_full/bootstrap/cache

# دادن دسترسی
sudo chmod -R 775 /home/hadii/www/sms_manager_full/storage
sudo chmod -R 775 /home/hadii/www/sms_manager_full/bootstrap/cache

# اجازه عبور www-data از پوشه خانه (برای WSL الزامی است)
sudo chmod o+x /home/hadii
```

> **خطای Forbidden:** اگر خطای `You don't have permission to access this resource` را دیدید، دلیل آن این است که کاربر `www-data` نمی‌تواند از پوشه `/home/hadii` عبور کند. دستور `sudo chmod o+x /home/hadii` را اجرا کنید.

---

## مرحله A3: ایجاد Virtual Host

```bash
sudo nano /etc/apache2/sites-available/sms-manager.conf
```

```apache
<VirtualHost *:80>
    ServerName sms.mcls.gov.test
    ServerAlias www.sms.mcls.gov.test

    DocumentRoot /home/hadii/www/sms_manager_full/public

    <Directory /home/hadii/www/sms_manager_full/public>
        AllowOverride All
        Require all granted
        Options -Indexes +FollowSymLinks
    </Directory>

    <IfModule mod_expires.c>
        ExpiresActive On
        ExpiresByType image/jpg "access plus 1 year"
        ExpiresByType image/jpeg "access plus 1 year"
        ExpiresByType image/gif "access plus 1 year"
        ExpiresByType image/png "access plus 1 year"
        ExpiresByType text/css "access plus 1 month"
        ExpiresByType application/javascript "access plus 1 month"
    </IfModule>

    ErrorLog ${APACHE_LOG_DIR}/sms-manager-error.log
    CustomLog ${APACHE_LOG_DIR}/sms-manager-access.log combined
</VirtualHost>
```

---

## مرحله A4: فعال‌سازی Virtual Host

```bash
sudo a2ensite sms-manager.conf
sudo a2dissite 000-default.conf
sudo apache2ctl configtest
sudo systemctl restart apache2
```

---

## مرحله A5: تنظیم hosts فایل ویندوز

فایل `C:\Windows\System32\drivers\etc\hosts` را با دسترسی Admin ویرایش کنید:

```
127.0.0.1   sms.mcls.gov.test
127.0.0.1   www.sms.mcls.gov.test
```

---

## مرحله A6: تنظیم .env برای آپاچی

```env
APP_URL=http://sms.mcls.gov.test
SANCTUM_STATEFUL_DOMAINS=localhost,127.0.0.1,sms.mcls.gov.test,::1
```

---

## مرحله A7: تست راه‌اندازی

```bash
sudo systemctl status apache2
```

در مرورگر:
```
http://sms.mcls.gov.test
```

---

## خلاصه دستورات آپاچی (کپی-پیست)

```bash
sudo apt install -y apache2 libapache2-mod-php8.2
sudo a2enmod rewrite headers ssl

sudo chown -R hadii:www-data /home/hadii/www/sms_manager_full/storage
sudo chown -R hadii:www-data /home/hadii/www/sms_manager_full/bootstrap/cache
sudo chmod -R 775 /home/hadii/www/sms_manager_full/storage
sudo chmod -R 775 /home/hadii/www/sms_manager_full/bootstrap/cache
sudo chmod o+x /home/hadii

sudo nano /etc/apache2/sites-available/sms-manager.conf
# (محتوای بالا را قرار دهید)

sudo a2ensite sms-manager.conf
sudo a2dissite 000-default.conf
sudo apache2ctl configtest
sudo systemctl restart apache2
```

---

## مقایسه دو روش اجرا

| ویژگی | artisan serve | آپاچی |
|-------|---------------|-------|
| سرعت راه‌اندازی | سریع | کمی کندتر |
| عملکرد | مناسب توسعه | بهتر برای تست |
| نیاز به sudo | ندارد | دارد |
| پورت | 8000 | 80 |
| آدرس | localhost:8000 | sms.mcls.gov.test |

> **توصیه:** برای توسعه روزانه از `php artisan serve` و برای تست نهایی از آپاچی استفاده کنید.

---

# راه‌اندازی SSL با mkcert

**mkcert** ابزاری است که گواهی‌های SSL محلی ایجاد می‌کند که مرورگر به آن‌ها اعتماد دارد. برخلاف گواهی Self-Signed، نیازی به نصب دستی در مرورگر نیست.

> **چرا mkcert بهتر از Self-Signed است؟**
> - مرورگر و HTTPie بدون هشدار کار می‌کنند
> - نیازی به `--insecure` یا `--verify=no` نیست
> - تا ۲ سال اعتبار دارد

---

## مرحله S1: نصب mkcert

```bash
# نصب پیش‌نیاز
sudo apt install -y libnss3-tools

# دانلود و نصب mkcert
curl -JLO "https://dl.filippo.io/mkcert/latest?for=linux/amd64"
chmod +x mkcert-v*-linux-amd64
sudo mv mkcert-v*-linux-amd64 /usr/local/bin/mkcert

# تست نصب
mkcert --version
```

---

## مرحله S2: نصب CA محلی

```bash
# نصب CA در سیستم‌عامل
mkcert -install
```

> **نکته مهم:** این دستور CA را فقط در WSL نصب می‌کند. برای اعتماد مرورگر **ویندوز**، باید CA را دستی در ویندوز نصب کنید (مرحله S2b).

---

## مرحله S2b: نصب CA در ویندوز

فایل CA را از WSL به ویندوز کپی کنید:

```bash
cp ~/.local/share/mkcert/rootCA.pem /mnt/c/Users/<نام_کاربر_ویندوز>/Desktop/rootCA.crt
```

سپس در **PowerShell (Run as Administrator)**:

```powershell
Import-Certificate -FilePath "C:\Users\<نام_کاربر_ویندوز>\Desktop\rootCA.crt" -CertStoreLocation Cert:\LocalMachine\Root
```

> اگر گزینه `Local Machine` دردسترس نیست، `Cert:\CurrentUser\Root` استفاده کنید.

پس از نصب، **مرورگر را کاملاً ببندید** و دوباره باز کنید.

---

## مرحله S3: تولید گواهی SSL

```bash
# ایجاد پوشه گواهی‌ها
sudo mkdir -p /etc/apache2/ssl

# تولید گواهی برای دامنه‌های مورد نیاز
mkcert sms.mcls.gov.test www.sms.mcls.gov.test localhost 127.0.0.1 ::1

# کپی به پوشه آپاچی
sudo cp sms.mcls.gov.test+4.pem /etc/apache2/ssl/server.crt
sudo cp sms.mcls.gov.test+4-key.pem /etc/apache2/ssl/server.key

# پاک کردن فایل‌های موقت
rm -f sms.mcls.gov.test+4.pem sms.mcls.gov.test+4-key.pem
```

> **نکته:** گواهی تولید شده تا **۲ سال** اعتبار دارد.

---

## مرحله S4: ایجاد Virtual Host SSL

```bash
sudo nano /etc/apache2/sites-available/sms-manager-ssl.conf
```

```apache
# ریدایرکت HTTP به HTTPS
<VirtualHost *:80>
    ServerName sms.mcls.gov.test
    ServerAlias www.sms.mcls.gov.test
    Redirect permanent / https://sms.mcls.gov.test/
</VirtualHost>

# سایت اصلی با SSL
<VirtualHost *:443>
    ServerName sms.mcls.gov.test
    ServerAlias www.sms.mcls.gov.test

    DocumentRoot /home/hadii/www/sms_manager_full/public

    SSLEngine on
    SSLCertificateFile /etc/apache2/ssl/server.crt
    SSLCertificateKeyFile /etc/apache2/ssl/server.key

    <Directory /home/hadii/www/sms_manager_full/public>
        AllowOverride All
        Require all granted
        Options -Indexes +FollowSymLinks
    </Directory>

    ErrorLog ${APACHE_LOG_DIR}/sms-manager-ssl-error.log
    CustomLog ${APACHE_LOG_DIR}/sms-manager-ssl-access.log combined
</VirtualHost>
```

---

## مرحله S5: فعال‌سازی سایت SSL

```bash
# فعال‌سازی سایت SSL
sudo a2ensite sms-manager-ssl.conf

# غیرفعال‌سازی سایت HTTP (مهم: فقط یکی فعال باشد)
sudo a2dissite sms-manager.conf

# بررسی تنظیمات
sudo apache2ctl configtest

# ری‌استارت آپاچی
sudo systemctl restart apache2
```

---

## مرحله S6: تنظیم .env برای HTTPS

```env
APP_URL=https://sms.mcls.gov.test
SESSION_SECURE_COOKIE=true
SANCTUM_STATEFUL_DOMAINS=localhost,127.0.0.1,sms.mcls.gov.test,::1
SESSION_DOMAIN=null
```

---

## مرحله S7: پاک کردن کش

```bash
cd /home/hadii/www/sms_manager_full
php artisan config:clear
php artisan cache:clear
php artisan route:clear
php artisan view:clear
```

---

## مرحله S8: فعال‌سازی `forceScheme` برای HTTPS

در فایل `app/Providers/AppServiceProvider.php` مطمئن شوید:

```php
// فقط در production فعال باشد
if (app()->environment('production')) {
    URL::forceScheme('https');
}
```

> **نکته:** در محیط local نیازی به `forceScheme('https')` نیست. فقط در production فعال کنید.

---

## مرحله S9: تست

در مرورگر:
```
https://sms.mcls.gov.test
```

در HTTPie:
```bash
http GET https://sms.mcls.gov.test/api/v1/sms/GetIp
```

> با mkcert نیازی به `--insecure` یا `--verify=no` نیست.

---

# جابه‌جایی بین HTTP و HTTPS

## فعال‌سازی HTTPS

**۱. فعال‌سازی سایت SSL در آپاچی:**
```bash
sudo a2ensite sms-manager-ssl.conf
sudo a2dissite sms-manager.conf
sudo systemctl restart apache2
```

**۲. تنظیم .env:**
```env
APP_URL=https://sms.mcls.gov.test
SESSION_SECURE_COOKIE=true
SESSION_DOMAIN=null
```

**۳. فعال‌سازی forceScheme در `app/Providers/AppServiceProvider.php`:**
```php
if (app()->environment('production')) {
    URL::forceScheme('https');
}
```

**۴. پاک کردن کش:**
```bash
php artisan config:clear
php artisan cache:clear
```

---

## غیرفعال‌سازی HTTPS (بازگشت به HTTP)

**۱. فعال‌سازی سایت HTTP در آپاچی:**
```bash
sudo a2dissite sms-manager-ssl.conf
sudo a2ensite sms-manager.conf
sudo systemctl restart apache2
```

**۲. تنظیم .env:**
```env
APP_URL=http://sms.mcls.gov.test
SESSION_SECURE_COOKIE=false
```

**۳. غیرفعال‌سازی forceScheme در `app/Providers/AppServiceProvider.php`:**
```php
// حذف یا کامنت کردن خط URL::forceScheme('https');
```

**۴. پاک کردن کش:**
```bash
php artisan config:clear
php artisan cache:clear
```

---

## خلاصه تغییرات

| تنغییر | HTTP | HTTPS |
|-------|------|-------|
| `APP_URL` | `http://sms.mcls.gov.test` | `https://sms.mcls.gov.test` |
| `SESSION_SECURE_COOKIE` | `false` | `true` |
| `URL::forceScheme` | حذف/کامنت | `URL::forceScheme('https')` |
| سایت آپاچی | `sms-manager.conf` | `sms-manager-ssl.conf` |
| پورت | 80 | 443 |

---

## بررسی وضعیت فعلی

```bash
# بررسی سایت فعال آپاچی
ls /etc/apache2/sites-enabled/

# بررسی .env
grep "APP_URL" .env
grep "SESSION_SECURE" .env

# بررسی forceScheme
grep "forceScheme" app/Providers/AppServiceProvider.php
```

---

## عیب‌یابی SSL

### خطای `SSL_ERROR_RX_RECORD_TOO_LONG`
مرورگر روی پورت 443 درخواست می‌فرستد ولی آپاچی با HTTP پاسخ می‌دهد:
```bash
sudo a2enmod ssl
sudo a2ensite sms-manager-ssl.conf
sudo a2dissite sms-manager.conf
sudo systemctl restart apache2
```

### خطای `ERR_SSL_PROTOCOL_ERROR` برای فایل‌های CSS/JS
مرورگر لینک‌های HTTPS قدیمی را کش کرده:
```bash
# بازسازی assets
npm run build

# رفرش کامل مرورگر
# Chrome/Edge: Ctrl+Shift+R
# Firefox: Ctrl+F5
```

### ریدایرکت خودکار به HTTPS
مرورگر HSTS را کش کرده یا `URL::forceScheme('https')` فعال است. بررسی کنید:
```bash
grep "forceScheme" app/Providers/AppServiceProvider.php
```

---

# عیب‌یابی آپاچی

### مشکل: خطای Forbidden
```bash
sudo chmod o+x /home/hadii
sudo chown -R hadii:www-data /home/hadii/www/sms_manager_full/storage
sudo chmod -R 775 /home/hadii/www/sms_manager_full/storage
```

### مشکل: صفحه خالی یا خطای 500
```bash
sudo tail -f /var/log/apache2/sms-manager-error.log
tail -f /home/hadii/www/sms_manager_full/storage/logs/laravel.log
```

### مشکل: rewrite کار نمی‌کند
```bash
sudo a2enmod rewrite
sudo systemctl restart apache2
```

### مشکل: فایل .htaccess خوانده نمی‌شود
مطمئن شوید در `/etc/apache2/apache2.conf`:
```apache
<Directory /var/www/>
    Options Indexes FollowSymLinks
    AllowOverride All
    Require all granted
</Directory>
```

### مشکل: خطای `The MAC is invalid`
APP_KEY محیط قبلی را در `.env` قرار دهید.

---

## خلاصه دستورات SSL (کپی-پیست)

```bash
# نصب mkcert
sudo apt install -y libnss3-tools
curl -JLO "https://dl.filippo.io/mkcert/latest?for=linux/amd64"
chmod +x mkcert-v*-linux-amd64
sudo mv mkcert-v*-linux-amd64 /usr/local/bin/mkcert
mkcert -install

# تولید گواهی
sudo mkdir -p /etc/apache2/ssl
mkcert sms.mcls.gov.test www.sms.mcls.gov.test localhost 127.0.0.1 ::1
sudo cp sms.mcls.gov.test+4.pem /etc/apache2/ssl/server.crt
sudo cp sms.mcls.gov.test+4-key.pem /etc/apache2/ssl/server.key
rm -f sms.mcls.gov.test+4.pem sms.mcls.gov.test+4-key.pem

# فعال‌سازی سایت SSL
sudo a2ensite sms-manager-ssl.conf
sudo a2dissite sms-manager.conf
sudo apache2ctl configtest
sudo systemctl restart apache2

# پاک کردن کش
php artisan config:clear
php artisan cache:clear
```
