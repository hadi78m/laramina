@extends('errors::minimal')

@section('title', __('خطای 503 - سرویس موقتاً در دسترس نیست'))
@section('code', '503')
{{-- @section('message', __('Service Unavailable')) --}}
{{-- @php
    $message = 'سرویس در دسترس نیست';

    $uri = "$_SERVER[REQUEST_URI]";
    if (strpos($uri, 'admin')) {
        $route = 'logout';
        $app = 'app.logout';
        $method = 'post';
    } else {
        $route = 'client.home';
        $app = 'app.home';
        $method = 'get';
    }
@endphp --}}
@section('message')
    <style>
    .wave {
        animation: wave 3s ease-in-out infinite;
    }
    @keyframes wave {
        0%, 100% { transform: rotate(0deg); }
        25% { transform: rotate(-5deg); }
        50% { transform: rotate(0deg); }
        75% { transform: rotate(5deg); }
    }
    .countdown {
        animation: pulse 1.5s ease-in-out infinite alternate;
    }
    @keyframes pulse {
        from { transform: scale(1); }
        to { transform: scale(1.05); }
    }
    </style>
    <div class="max-w-lg w-full bg-white rounded-xl shadow-2xl overflow-hidden">
        <div class="bg-gradient-to-r from-cyan-500 to-blue-600 p-6 text-center">
            <div class="wave inline-block">
                <svg xmlns="http://www.w3.org/2000/svg" class="h-20 w-20 mx-auto text-white" fill="none" viewBox="0 0 24 24"
                    stroke="currentColor">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                        d="M20 7l-8-4-8 4m16 0l-8 4m8-4v10l-8 4m0-10L4 7m8 4v10M4 7v10l8 4" />
                </svg>
            </div>
            <h1 class="text-2xl font-bold text-white mt-4">503 - سرویس موقتاً در دسترس نیست</h1>
        </div>

        <div class="p-8 text-center">
            <p class="text-gray-700 mb-6">در حال حاضر سرویس در حال نگهداری یا بروزرسانی است.</p>

            <div class="bg-blue-50 border border-blue-200 text-blue-700 px-4 py-3 rounded mb-6">
                <div class="flex items-center justify-center space-x-2">
                    <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
                        <path fill-rule="evenodd"
                            d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7-4a1 1 0 11-2 0 1 1 0 012 0zM9 9a1 1 0 000 2v3a1 1 0 001 1h1a1 1 0 100-2h-1V9z"
                            clip-rule="evenodd" />
                    </svg>
                    <span>سرویس تا <span class="font-bold countdown">دقایقی دیگر</span> دیگر فعال می‌شود</span>
                </div>
            </div>

            <div class="mb-6">
                <div class="w-full bg-gray-200 rounded-full h-2.5">
                    <div class="bg-blue-600 h-2.5 rounded-full" style="width: 65%"></div>
                </div>
                <p class="text-sm text-gray-500 mt-2">پیشرفت بروزرسانی: 65%</p>
            </div>

            <div class="flex flex-col space-y-3">
                <button onclick="window.location.reload()"
                    class="bg-blue-600 hover:bg-blue-700 text-white font-medium py-2 px-4 rounded-lg transition duration-200">
                    تلاش مجدد
                </button>
                <a href="{{ url()->previous() }}"
                    class="text-blue-600 hover:text-blue-800 font-medium py-2 px-4 rounded-lg transition duration-200">
                    بازگشت به صفحه قبل
                </a>
                {{-- <a href="https://t.me/our_channel"
                    class="text-gray-600 hover:text-gray-800 font-medium py-2 px-4 rounded-lg transition duration-200 flex items-center justify-center">
                    <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5 ml-1" viewBox="0 0 20 20" fill="currentColor">
                        <path d="M2 5a2 2 0 012-2h7a2 2 0 012 2v4a2 2 0 01-2 2H9l-3 3v-3H4a2 2 0 01-2-2V5z" />
                        <path
                            d="M15 7v2a4 4 0 01-4 4H9.828l-1.766 1.767c.28.149.599.233.938.233h2l3 3v-3h2a2 2 0 002-2V9a2 2 0 00-2-2h-1z" />
                    </svg>
                    کانال اطلاع‌رسانی
                </a> --}}
            </div>
        </div>
    </div>
@endsection
