<?php

namespace App\Http\Controllers\Sms;

use App\Http\Controllers\Controller;
use App\Jobs\Sms\SendBulkSmsJob;
use App\Jobs\Sms\SendSingleSmsJob;
use App\Models\Sms\Provider;
use App\Models\Sms\Message;
use App\Models\Sms\Credential;
use App\Models\Sms\BlockedWord;
use App\Models\Sms\Social;
use App\Services\Sms\SmsSenderService;
use App\Services\Sms\SocialSenderService;
use Hash;
use Illuminate\Bus\Batch;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Bus;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\DB;

class SmsMessageController extends Controller
{
    /**
     * نمایش صفحه پیام‌های ارسالی
     */
    public function index()
    {
        $credentials = Credential::get();
        return view('sms.messages.messages-index', compact('credentials'));
    }

    /**
     * دریافت لیست پیام‌ها
     */
    public function getMessages(Request $request)
    {
        try {
            $query = Message::with(['credential']);
            // فیلتر بر اساس اعتبارنامه
            if ($request->filled('credential_id')) {
                $query->where('sms_credential_id', $request->credential_id);
            }

            // فیلتر بر اساس وضعیت
            if ($request->filled('status')) {
                $query->where('status', $request->status);
            }

            // فیلتر بر اساس تاریخ
            if ($request->filled('date_from')) {
                $query->whereDate('created_at', '>=', $request->date_from);
            }

            if ($request->filled('date_to')) {
                $query->whereDate('created_at', '<=', $request->date_to);
            }

            $messages = $query->orderBy('created_at', 'desc')->get();

            return response()->json([
                'success' => true,
                'data' => $messages->map(function ($message) {
                    return [
                        'id' => $message->id,
                        'user' => $message->credential->name,
                        'username' => $message->credential->username,
                        'recipient' => $message->recipient,
                        'message' => $message->message,
                        'type' => $message->type,
                        'status' => $message->status,
                        'status_text' => $this->getStatusText($message->status),
                        'blocked_words' => $message->blocked_words,
                        'error_message' => $message->error_message,
                        'created_at' => verta($message->created_at)->format('Y-m-d H:i:s'),
                        'sent_at' => $message->sent_at ? verta($message->sent_at)->format('Y-m-d H:i:s') : null,
                    ];
                }),
            ]);
        } catch (\Exception $e) {
            Log::error('خطا در دریافت لیست پیام‌ها: ' . $e->getMessage());

            return response()->json([
                'success' => false,
                'message' => 'خطا در دریافت لیست پیام‌ها',
            ], 500);
        }
    }

    /**
     * آمار پیام‌ها
     */
    public function getStats(Request $request)
    {
        try {
            $query = Message::query();

            if ($request->filled('credential_id')) {
                $query->where('sms_credential_id', $request->credential_id);
            }

            $stats = [
                'total' => $query->count(),
                'pending' => (clone $query)->where('status', 'pending')->count(),
                'sent' => (clone $query)->where('status', 'sent')->count(),
                'blocked' => (clone $query)->where('status', 'blocked')->count(),
                'failed' => (clone $query)->where('status', 'failed')->count(),
            ];

            return response()->json([
                'success' => true,
                'data' => $stats,
            ]);
        } catch (\Exception $e) {
            Log::error('خطا در دریافت آمار پیام‌ها: ' . $e->getMessage());

            return response()->json([
                'success' => false,
                'message' => 'خطا در دریافت آمار پیام‌ها',
            ], 500);
        }
    }




    /**
     * متن فارسی وضعیت
     */
    private function getStatusText($status)
    {
        $statuses = [
            'pending' => 'در انتظار',
            'sent' => 'ارسال شده',
            'failed' => 'خطا',
            'blocked' => 'مسدود شده',
        ];

        return $statuses[$status] ?? $status;
    }

    /**
     * ارسال پیام با استفاده از نام کاربری و رمز عبور (از طریق HTTP Basic Auth)
     */
    public function sendWithCredentials(Request $request)
    {
        try {
            // کاربر authenticated از middleware
            $credential = $request->user('sms'); // guard 'sms' استفاده می‌شود

            // اعتبارسنجی ورودی‌ها
            $validator = Validator::make($request->all(), [
                'recipient' => 'required|string|regex:/^09[0-9]{9}$/',
                'message' => 'required|string|max:330',
            ], [
                'recipient.required' => 'شماره گیرنده الزامی است',
                'recipient.regex' => 'شماره گیرنده نامعتبر است',
                'message.required' => 'متن پیام الزامی است',
                'message.max' => 'متن پیام نمی‌تواند بیشتر از 330 کاراکتر باشد',
            ]);

            if ($validator->fails()) {
                return response()->json([
                    'success' => false,
                    'message' => $validator->errors()->first(),
                    'errors' => $validator->errors(),
                ], 422);
            }

            // بررسی امکان ارسال
            $canSend = $credential->canSendMessage();
            if (!$canSend['can_send']) {
                return response()->json([
                    'success' => false,
                    'message' => $canSend['reason'],
                ], 403);
            }

            DB::beginTransaction();

            // ایجاد پیام با وضعیت pending
            $message = Message::create([
                'sms_credential_id' => $credential->id,
                'recipient' => $request->recipient,
                'message' => $request->message,
                'status' => 'pending',
            ]);

            // بررسی کلمات غیرمجاز
            $foundWords = BlockedWord::checkMessage($request->message);

            if (count($foundWords) > 0) {
                $message->markAsBlocked('حاوی کلمات غیرمجاز: ' . implode(', ', $foundWords), $foundWords);

                DB::commit();

                return response()->json([
                    'success' => false,
                    'message' => 'پیام حاوی کلمات غیرمجاز است',
                    'blocked_words' => $foundWords,
                    'data' => [
                        'message_id' => $message->id,
                        'status' => 'blocked',
                    ],
                ], 422);
            }

            // افزایش شمارنده
            $credential->incrementDailyCount(); // استفاده از متد موجود

            DB::commit();

            return response()->json([
                'success' => true,
                'message' => 'پیام در صف ارسال قرار گرفت',
                'data' => [
                    'message_id' => $message->id,
                    'status' => 'pending',
                    'recipient' => $message->recipient,
                    'created_at' => $message->created_at->format('Y-m-d H:i:s'),
                ],
            ]);
        } catch (\Exception $e) {
            DB::rollBack();
            Log::error('خطا در ارسال پیام با credentials: ' . $e->getMessage());

            return response()->json([
                'success' => false,
                'message' => 'خطا در ارسال پیام',
            ], 500);
        }
    }






}
