<?php

namespace App\Providers;

use App\Models\User;
use App\Support\AdminRouteExporter;
use Illuminate\Support\Facades\Gate;
use Illuminate\Support\Facades\URL;
use Illuminate\Support\Facades\Blade;
use Illuminate\Support\ServiceProvider;

class AppServiceProvider extends ServiceProvider
{
    /**
     * Register any application services.
     */
    public function register(): void
    {
        // ثبت دستی Telescope در محیط local یا وقتی TELESCOPE_ENABLED=true باشه
        if ($this->app->environment('local') || config('telescope.enabled')) {
            $this->app->register(TelescopeServiceProvider::class);
        }
        // if ($this->app->environment('local') && class_exists(\Laravel\Telescope\TelescopeServiceProvider::class)) {
        //     $this->app->register(\Laravel\Telescope\TelescopeServiceProvider::class);
        //     $this->app->register(TelescopeServiceProvider::class);
        // }
    }

    /**
     * Bootstrap any application services.
     */
    public function boot(): void
    {
        // اجبار لاراول به تولید تمام لینک‌ها با پروتکل HTTPS (فقط production)
        if (app()->environment('production')) {
            URL::forceScheme('https');
        }
        Gate::define('viewPulse', function (User $user) {
            return true; //$user->isAdmin();
        });
        

    }
}
