import ModalPlugin from '/js/admin-platform/plugins/ui/modal/modal-plugin.js'
import FormEngine from '/js/admin-platform/engines/form-engine.js'
import { createForm } from './forms/create-form.js'
import { action } from '/js/admin-platform/core/action.js'



export const providerActions = {

    view: (row) => {
        console.log('view provider', row)
    },

    edit: action({
        icon: 'fas fa-edit',
        color: 'text-blue-600',
        size: 'text-lg',
        tooltip: 'ویرایش',
        roles: ['SuperAdmin'],
    }, (row, table, event) => {
        const url = AppAlert.route(createForm.updateEndpoint, { id: row.id });
        event?.preventDefault()

        ModalPlugin.open({
            title: 'ویرایش پرووایدر',
            width: '500px',

            content: (container) => {

                const config = {
                    ...createForm,
                    endpoint: url,
                    method: 'PUT'
                }

                FormEngine.render(config, container, row)
            }
        })
    }),

    delete: action({
        icon: 'fas fa-trash',
        color: 'text-red-600',
        size: 'text-lg',
        roles: ['SuperAdmin'],
        // permission: ['numbers.delete'], // 'sms.providers.delete',
        tooltip: 'حذف',
    },
        async (row, table, event) => {

            event?.preventDefault()

            const url = AppAlert.route(createForm.deleteEndpoint, { id: row.id });

            // dd()
            const res = await AppAlert.confirmDelete(url, {
                title: 'حذف سرویس‌دهنده',
            })

            if (res) {

                document.dispatchEvent(
                    new CustomEvent('admin:table:remove-row', {
                        detail: { id: row.id }
                    })
                )


            }
        }),

    setToggle(id, table, endpoint) {
        const url = AppAlert.route(endpoint, { id });

        return AppAlert.post(url, {}, {
            loading: true,
            successAlert: true
        }).done((res) => {

            // اگر update شامل 'table' بود، کل جدول را رفرش کن
            if (res.update && res.update == 'table') {
                if (typeof table.loadData === 'function') {
                    table.loadData();  // رفرش با حفظ page/filter
                }
                else {
                    console.warn('table.loadData is not a function');
                }
                return;
            }

            // در غیر اینصورت، فقط همان ردیف را آپدیت کن

            // ۱) اگر سرور ردیف کامل را برگرداند
            if (res.provider && typeof table.updateRow === 'function') {
                table.updateRow(res.provider);
                return;
            }

            // ۲) fallback: ردیف قدیمی را بگیر و patch کن (در مواقعی که فقط چند فیلد ساده برگشتند)

            const oldRow = table.getRowById
                ? table.getRowById(id)
                : (table.currentRows || []).find(r => r.id == id);

            if (!oldRow) {
                console.warn("Row not found:", id);
                return;
            }

            // برای جلوگیری از خراب‌کاری، همه res را merge نکن
            // فقط فیلدهای مجاز را patch کن
            const allowedKeys = ['is_active', 'is_default'];
            const patch = {};
            allowedKeys.forEach(k => {
                if (k in res) patch[k] = res[k];
            });

            const newRow = { ...oldRow, ...patch };

            if (typeof table.updateRow === 'function') {
                table.updateRow(newRow);
            } else {
                console.warn('table.updateRow is not a function');
            }
        });
    },

    // در actions.js
    numbers: {
        icon: 'fas fa-phone',
        color: 'text-green-800',
        size: 'text-lg',
        tooltip: 'لیست شماره ها',
        handler(row, table, event) {
            event?.preventDefault();

            // دریافت آیدی provider از جدول
            const providerId = row.id;

            // تزریق به دکمه و تریگر کلیک
            $('#btn-show-numbers')
                .data('provider-id', providerId)
                .trigger('click');
        }
    },
    testConnection: {
        icon: 'fas fa-plug',
        color: 'text-teal-600',
        size: 'text-lg',
        tooltip: 'تست اتصال',
        handler(row, table, event) {
            event?.preventDefault();

            // دریافت آیدی provider از جدول
            const providerId = row.id;

            
            testConnection(providerId);
        }
    },
    createHelper: {
        icon: 'fas fa-gift',
        color: 'text-yellow-800',
        size: 'text-lg',
        tooltip: 'ساخت هلپر برای پروایدر',
        handler(row, table, event) {
            event?.preventDefault();

            // دریافت آیدی provider از جدول
            const providerId = row.id;

            createHelper(providerId);
        }
    },

}
