@extends('layouts.mclsApp')

@section('content')
    <x-elements.sidebar>
        <x-sidebars.sms />
    </x-elements.sidebar>


    <div class="container mx-auto px-4 py-8">
        <div class="bg-white rounded-lg shadow-lg overflow-hidden">
            <!-- Header -->
            <div
                class="bg-gradient-to-r from-indigo-600 to-purple-600 text-white px-6 py-4 flex justify-between items-center">
                <h3 class="text-xl font-bold">مدیریت پیام رسان ها</h3>
                @role('SuperAdmin')
                <button onclick="openAddModal()"
                    class="bg-white text-indigo-600 px-4 py-2 rounded-lg hover:bg-indigo-50 transition-all duration-200 flex items-center gap-2 font-semibold">
                    <i class="fas fa-plus"></i>
                    افزودن پیام رسان جدید
                </button>
                @endrole
            </div>

            <!-- Body -->
            <div class="p-6">
                <div class="overflow-x-auto">
                    <table id="socialsTable" class="w-full">
                        <thead>
                            <tr class="bg-gray-50">
                                <th class="px-4 py-3 text-right text-sm font-semibold text-gray-700">شناسه</th>
                                <th class="px-4 py-3 text-right text-sm font-semibold text-gray-700">نام پیام رسان</th>
                                {{-- <th class="px-4 py-3 text-right text-sm font-semibold text-gray-700">نام کاربری</th>
                                --}}
                                <th class="px-4 py-3 text-right text-sm font-semibold text-gray-700">آدرس API</th>
                                <th class="px-4 py-3 text-right text-sm font-semibold text-gray-700">وضعیت</th>
                                <th class="px-4 py-3 text-right text-sm font-semibold text-gray-700">پیش‌فرض</th>
                                <th class="px-4 py-3 text-right text-sm font-semibold text-gray-700">تاریخ ایجاد</th>
                                <th class="px-4 py-3 text-right text-sm font-semibold text-gray-700">نرخ ارسال</th>
                                <th class="px-4 py-3 text-right text-sm font-semibold text-gray-700">واحد نرخ</th>
                                <th class="px-4 py-3 text-right text-sm font-semibold text-gray-700">عملیات</th>
                            </tr>
                        </thead>
                        <tbody></tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
    @role('SuperAdmin')
    {{-- Modal افزودن پیام رسان --}}
    <div id="addSocialModal" class="hidden fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center p-4">
        <div class="bg-white rounded-xl shadow-2xl w-full max-w-lg transform transition-all">

            <div
                class="bg-gradient-to-r from-indigo-600 to-purple-600 text-white px-6 py-4 rounded-t-xl flex justify-between items-center">
                <h5 class="text-lg font-bold">افزودن پیام رسان جدید</h5>
                <button onclick="closeAddModal()" class="text-white hover:text-gray-200"><i
                        class="fas fa-times text-xl"></i></button>
            </div>


            <form id="addSocialForm" class="p-6 space-y-5">
                @csrf
                <div>
                    <label class="block text-sm font-semibold text-gray-700 mb-2">نام پیام رسان <span
                            class="text-red-500">*</span></label>
                    <input type="text" name="name" required
                        class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500"
                        placeholder="مثال: کاوه‌نگار، ملی‌پیامک">
                    <div class="text-red-500 text-sm mt-1 hidden error-name"></div>
                </div>

                <div class="grid grid-cols-2 gap-4">
                    <div>
                        <label class="block text-sm font-semibold text-gray-700 mb-2">نام کاربری</label>
                        <input type="text" name="user"
                            class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500">
                    </div>
                    <div>
                        <label class="block text-sm font-semibold text-gray-700 mb-2">رمز عبور</label>
                        <input type="password" name="password"
                            class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500">
                    </div>
                </div>

                <div>
                    <label class="block text-sm font-semibold text-gray-700 mb-2">آدرس API</label>
                    <input type="url" name="url"
                        class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500"
                        placeholder="https://api.example.com/send">
                </div>

                <!-- بعد از فیلد url -->
                <div class="grid grid-cols-2 gap-4">
                    <div>
                        <label class="block text-sm font-semibold text-gray-700 mb-2">نرخ ارسال</label>
                        <input type="number" name="send_rate" id="add_send_rate" min="1"
                            class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-teal-500"
                            placeholder="مثلاً 10">
                    </div>
                    <div>
                        <label class="block text-sm font-semibold text-gray-700 mb-2">واحد نرخ</label>
                        <select name="rate_unit" id="add_rate_unit"
                            class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-teal-500">
                            <option value="per_second">در ثانیه</option>
                            <option value="per_minute" selected>در دقیقه</option>
                            <option value="per_hour">در ساعت</option>
                            <option value="unlimited">نامحدود</option>
                        </select>
                    </div>
                </div>
                <div>
                    <label class="block text-sm font-semibold text-gray-700 mb-2">توکن</label>
                    <input type="text" name="token" id="add_token" min="1"
                        class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-teal-500"
                        placeholder="">
                </div>
                <div class="flex items-center mt-2">
                    <input type="checkbox" name="is_default" id="add_is_default"
                        class="w-5 h-5 text-indigo-600 rounded focus:ring-indigo-500">
                    <label for="add_is_default" class="mr-3 text-sm font-semibold text-gray-700">این پیام رسان را به عنوان
                        پیش‌فرض قرار بده
                    </label>

                </div>
                <div class="flex items-center mt-2">
                    <div class="flex items-center">
                        <input type="checkbox" name="is_active" id="add_is_active"
                            class="w-5 h-5 text-teal-600 rounded focus:ring-teal-500">
                        <label for="add_is_active" class="mr-3 text-sm font-semibold text-gray-700">فعال باشد</label>
                    </div>
                </div>

                <div class="flex gap-3 mt-6">
                    <button type="button" onclick="closeAddModal()"
                        class="flex-1 px-4 py-2 bg-gray-200 text-gray-700 rounded-lg hover:bg-gray-300 font-semibold">انصراف</button>
                    <button type="submit"
                        class="flex-1 px-4 py-2 bg-gradient-to-r from-indigo-600 to-purple-600 text-white rounded-lg hover:from-indigo-700 hover:to-purple-700 font-semibold">ذخیره</button>
                </div>
            </form>
        </div>
    </div>
    @endrole
    {{-- Modal ویرایش پیام رسان --}}
    @role('SuperAdmin')
    <div id="editSocialModal" class="hidden fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center p-4">
        <div class="bg-white rounded-xl shadow-2xl w-full max-w-lg transform transition-all">
            <div
                class="bg-gradient-to-r from-teal-600 to-emerald-600 text-white px-6 py-4 rounded-t-xl flex justify-between items-center">
                <h5 class="text-lg font-bold">ویرایش پیام رسان</h5>
                <button onclick="closeEditModal()" class="text-white hover:text-gray-200"><i
                        class="fas fa-times text-xl"></i></button>
            </div>

            <form id="editSocialForm" class="p-6 space-y-5">
                @csrf
                <input type="hidden" name="id" id="edit_social_id">
                <div>
                    <label class="block text-sm font-semibold text-gray-700 mb-2">نام پیام رسان <span
                            class="text-red-500">*</span></label>
                    <input type="text" name="name" id="edit_name" required
                        class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-teal-500">
                </div>
                <div class="grid grid-cols-2 gap-4">
                    <div>
                        <label class="block text-sm font-semibold text-gray-700 mb-2">نام کاربری</label>
                        <input type="text" name="user" id="edit_user"
                            class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-teal-500">
                    </div>
                    <div>
                        <label class="block text-sm font-semibold text-gray-700 mb-2">رمز عبور جدید</label>
                        <input type="password" name="password"
                            class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-teal-500"
                            placeholder="خالی = بدون تغییر">
                    </div>
                </div>

                <div>
                    <label class="block text-sm font-semibold text-gray-700 mb-2">آدرس API</label>
                    <input type="url" name="url" id="edit_url"
                    class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-teal-500">
                </div>

                <!-- بعد از فیلد url -->
                <div class="grid grid-cols-2 gap-4">
                    <div>
                        <label class="block text-sm font-semibold text-gray-700 mb-2">نرخ ارسال</label>
                        <input type="number" name="send_rate" id="edit_send_rate" min="1"
                            class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-teal-500">
                    </div>
                    <div>
                        <label class="block text-sm font-semibold text-gray-700 mb-2">واحد نرخ</label>
                        <select name="rate_unit" id="edit_rate_unit"
                            class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-teal-500">
                            <option value="per_second">در ثانیه</option>
                            <option value="per_minute">در دقیقه</option>
                            <option value="per_hour">در ساعت</option>
                            <option value="unlimited">نامحدود</option>
                        </select>
                    </div>
                </div>
                <div>
                    <label class="block text-sm font-semibold text-gray-700 mb-2">توکن</label>
                    <input type="text" name="token" id="edit_token" min="1"
                        class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-teal-500"
                        placeholder="">
                </div>
                <div class="flex flex-wrap gap-6">
                    <div class="flex items-center">
                        <input type="checkbox" name="is_default" id="edit_is_default"
                            class="w-5 h-5 text-teal-600 rounded focus:ring-teal-500">
                        <label for="edit_is_default" class="mr-3 text-sm font-semibold text-gray-700">پیش‌فرض باشد</label>
                    </div>
                    <div class="flex items-center">
                        <input type="checkbox" name="is_active" id="edit_is_active"
                            class="w-5 h-5 text-teal-600 rounded focus:ring-teal-500">
                        <label for="edit_is_active" class="mr-3 text-sm font-semibold text-gray-700">فعال باشد</label>
                    </div>
                </div>

                <div class="flex gap-3 mt-6">
                    <button type="button" onclick="closeEditModal()"
                        class="flex-1 px-4 py-2 bg-gray-200 text-gray-700 rounded-lg hover:bg-gray-300 font-semibold">انصراف</button>
                    <button type="submit"
                        class="flex-1 px-4 py-2 bg-gradient-to-r from-teal-600 to-emerald-600 text-white rounded-lg hover:from-teal-700 hover:to-emerald-700 font-semibold">به‌روزرسانی</button>
                </div>
            </form>
        </div>
    </div>
    @endrole
    <div id="manageNumbersModal"
        class="hidden fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center p-4">
        <div class="bg-white rounded-xl shadow-2xl w-full max-w-lg transform transition-all">
            <div
                class="bg-gradient-to-r from-indigo-600 to-purple-600 text-white px-6 py-4 rounded-t-xl flex justify-between items-center">
                <h5 class="text-lg font-bold">مدیریت شماره‌های پیام رسان</h5>
                <button onclick="closeNumbersModal()" class="text-white hover:text-gray-200"><i
                        class="fas fa-times text-xl"></i></button>
            </div>
            <div class="p-6 space-y-5">
                <input type="hidden" id="current_social_id">
                <!-- فرم افزودن شماره جدید -->
                <form id="addNumberForm" class="space-y-4">
                    @csrf
                    <div>
                        <label class="block text-sm font-semibold text-gray-700 mb-2">شماره جدید <span
                                class="text-red-500">*</span></label>
                        <input type="text" name="number" required autocomplate="off"
                            class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500"
                            placeholder="مثال: 50003">
                    </div>
                    <button type="submit"
                        class="w-full px-4 py-2 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 font-semibold">افزودن
                        شماره</button>
                </form>

                {{-- loding --}}
                <div id="numbersLoading" class="text-center py-10 hidden">
                    <div
                        class="inline-block animate-spin rounded-full h-10 w-10 border-4 border-indigo-500 border-t-transparent">
                    </div>
                    <p class="mt-4 text-gray-600 font-medium">در حال بارگذاری شماره‌ها...</p>
                </div>
                <!-- لیست شماره‌ها -->
                <div class="mt-6">
                    <h6 class="text-md font-bold mb-3">شماره‌های موجود</h6>
                    <table id="numbersTable" class="w-full text-sm">
                        <thead>
                            <tr class="bg-gray-50">
                                <th class="px-4 py-2 text-right">شماره</th>
                                <th class="px-4 py-2 text-right">وضعیت</th>
                                <th class="px-4 py-2 text-right">عملیات</th>
                            </tr>
                        </thead>
                        <tbody></tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>


@endsection

@section('scripts')
    @include('sms.socials.script.social-script')
@endsection