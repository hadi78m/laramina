@php

@endphp
<!DOCTYPE html>
<html lang="fa" dir="rtl">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>@yield('title')</title>
    {{-- <script src="{{ asset('js/tailwindcss.js') }}"></script> --}}
    {{-- <link rel="stylesheet" href="{{ asset('css/fonts.css') }}" /> --}}
    @vite(['resources/css/app.css', 'resources/js/app.js'])
</head>
<body class="bg-gradient-to-b from-blue-50 to-purple-100 min-h-screen flex items-center justify-center p-4">
        @yield('message')
</body>
</html>
