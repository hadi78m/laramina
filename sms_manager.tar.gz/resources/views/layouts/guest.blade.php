<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}" dir="rtl">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <title>{{ config('app.name', 'Laravel') }}</title>

    <!-- استایل‌ها -->

    @vite(['resources/css/app.css', 'resources/js/app.js'])



    <style>
        body {
            background: url('./img/backgound.jpg') no-repeat center center fixed;
            background-size: cover;
        }

        .overlay {
            background: rgba(255, 255, 255, 0.322);
        }
    </style>
</head>

{{-- <body class="font-['IRANSans'] bg-gradient-to-b from-blue-50 to-white h-screen"> --}}
    <body class="font-['vazirmatn'] min-h-screen flex items-center justify-center p-5 relative">
    <div class="absolute inset-0 overlay z-0"></div>
    {{ $slot }}
</body>

</html>