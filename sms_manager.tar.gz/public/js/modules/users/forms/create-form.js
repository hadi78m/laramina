const publicLang = AdminLang.getNamespace('common');
const moduleFields = AdminLang.getNamespace('modules.users.fields');
const moduleActions = AdminLang.getNamespace('modules.users.actions');

// ✅ فیلدهای مشترک بین هر دو فرم
const commonFields = [
    {
        type: 'group',  // ✅ اضافه شده
        group: [
            {
                name: 'name',
                label: publicLang.name + ' نمایشی',
                type: 'text',
                required: true,
            },
            {
                name: 'email',
                label: publicLang.email,
                type: 'email',
                required: true,
            },
        ]
    },
    {
        name: 'national_code',
        label: publicLang.national_code,
        type: 'tel',
        pattern: '[0-9]{10}',
        maxlength: '10',
        minlength: '10',
        required: true,
    },
    {
        type: 'group',  // ✅ اضافه شده
        group: [
            {
                name: 'roles',
                label: moduleFields.roles || 'نقش‌ها',
                type: 'select',
                multiple: true,
                optionEndpoint: 'manage.roles.list',
                optionLabel: 'name',
                optionValue: 'name',
                role: ['SuperAdmin'],
                helper: 'نقش مورد نظر در صورت نیاز'
            },
            {
                name: 'permissions',
                label: moduleFields.permissions || 'دسترسی ها',
                type: 'select',
                multiple: true,
                optionEndpoint: 'manage.permissions.list',
                optionLabel: 'name',
                optionValue: 'name',
                role: ['SuperAdmin'],
                helper: 'دسترسی مورد نظر در صورت نیاز'
            },
        ]
    },
];

// ✅ فرم ایجاد (با رمز عبور اجباری)
export const createForm = {
    endpoint: 'manage.users.store',
    updateEndpoint: 'manage.users.update',
    deleteEndpoint: 'manage.users.destroy',

    title: moduleActions.create || publicLang.create,
    fields: [
        ...commonFields,
        {
            name: 'password',
            label: publicLang.password,
            type: 'password',
            required: true,
            min: 6,
            placeholder: 'گذرواژه باید حداقل ۶ کاراکتر باشد',
            helper: 'گذرواژه مناسب باید حداقل ۸ کاراکتر و شامل حروف، اعداد و نمادها باشد',
        },
    ],
    buttons: {
        submit: publicLang.save,
        cancel: publicLang.cancel,
    }
};

// ✅ فرم ویرایش (با رمز عبور اختیاری و placeholder مجزا)
export const editForm = {
    title: moduleActions.edit || publicLang.edit,
    fields: [
        ...commonFields,
        {
            name: 'password',
            label: 'رمز عبور جدید',
            type: 'password',
            placeholder: 'در صورت تمایل تغییر دهید',
            min: 6,
            hideValue: true,
            value: '',
            helper: 'در صورت تمایل رمز عبور جدید وارد کنید در غیر این صورت خالی بگذارید',
        },
    ],
    buttons: {
        submit: publicLang.save,
        cancel: publicLang.cancel,
    }
};