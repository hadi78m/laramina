
# نمایش پیغام خطا

```js
showSystemError(title, message, icon = 'error');
```

## Example

```js
showSystemError('اخطار', response.message, 'error');
```

```js
showSystemError('','خطا در ادامه فرایند');
```
# نمایش پیغام موفقیت

```js
showSystemSuccess(title, message, icon = 'success');
```

## Example

```js
showSystemSuccess('موفق', response.message, 'success');
```

```js
showSystemSuccess('','عملیات موفق بود');
```
# نمایش پیغام خطا Toast

```js
showError(message);
```

## Example

```js
showError('خطا در ادامه فرایند');
```

# نمایش پیغام موفقیت Toast


```js
showSuccess('عملیات موفقیت آمیز بود');
```