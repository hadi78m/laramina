<script>
    let messagesTable;

    $(document).ready(function () {
        // بارگذاری آمار
        loadStats();

        // Initialize DataTable
        messagesTable = $('#messagesTable').DataTable({
            processing: true,
            "dom": 'Blfrtip', // نمایش دکمه‌ها
            "buttons": [{
                extend: 'copy',
                text: 'کپی',
                className: 'bg-gray-500 hover:bg-gray-600 text-white px-4 py-2 rounded-lg text-sm font-medium transition-colors duration-200'
            },
            {
                extend: 'excel',
                text: 'اکسل',
                className: 'bg-green-500 hover:bg-green-600 text-white px-4 py-2 rounded-lg text-sm font-medium transition-colors duration-200'
            },
            {
                extend: 'pdf',
                text: 'PDF',
                className: 'bg-red-500 hover:bg-red-600 text-white px-4 py-2 rounded-lg text-sm font-medium transition-colors duration-200'
            },
            {
                extend: 'print',
                text: 'چاپ',
                className: 'bg-blue-500 hover:bg-blue-600 text-white px-4 py-2 rounded-lg text-sm font-medium transition-colors duration-200'
            }
            ],
            ajax: {
                url: '{{ route("sms.messages.json") }}',
                data: function (d) {
                    d.credential_id = $('#filter-credential').val();
                    d.status = $('#filter-status').val();
                    d.date_from = $('#filter-date-from').val();
                    d.date_to = $('#filter-date-to').val();
                },
                dataSrc: 'data'
            },
            columns: [
                // { data: 'id' },
                {
                    data: 'user',
                    render: function (data) {
                        return `<span class="font-semibold text-gray-900">${data}</span>`;
                    }
                },
                // { data: 'username' },
                {
                    data: 'recipient',
                    render: function (data) {
                        return `<span class="font-mono text-sm">${data}</span>`;
                    }
                },
                {
                    data: 'message',
                    render: function (data) {
                        const short = data.length > 50 ? data.substring(0, 50) + '...' : data;
                        return `<span class="text-gray-700">${short}</span>`;
                    }
                }, 
                {
                    data: 'type',
                    // render: function (data) {
                    //    data => data.toUpperCase();
                    // }
                    // render: data => data.toUpperCase();

                },
                {
                    data: 'status',
                    render: function (data, type, row) {
                        const statusConfig = {
                            'pending': { class: 'yellow-500', bg: 'yellow-100', icon: 'clock' },
                            'sent': { class: 'green-500', bg: 'green-100', icon: 'check-circle' },
                            'blocked': { class: 'red-500', bg: 'red-100', icon: 'ban' },
                            'failed': { class: 'orange-500', bg: 'orange-100', icon: 'times-circle' }
                        };
                        const config = statusConfig[data] || statusConfig['pending'];
                        return `
                            <span class="px-3 py-1 bg-${config.bg} text-${config.class} text-xs font-semibold rounded-full inline-flex items-center gap-1">
                                <i class="fas fa-${config.icon}"></i>
                                ${row.status_text}
                            </span>
                        `;
                    }
                },
                {
                    data: 'blocked_words',
                    render: function (data) {
                        if (!data) {
                            return '<span class="text-gray-400">-</span>';
                        }
                        try {
                            const words = typeof data === 'string' ? JSON.parse(data) : data;
                            if (!Array.isArray(words) || words.length === 0) {
                                return '<span class="text-gray-400">-</span>';
                            }
                            return `<span class="px-2 py-1 bg-red-100 text-red-800 text-xs font-semibold rounded text-center">${words.length} کلمه</span>`;
                        } catch (e) {
                            return '<span class="text-gray-400">-</span>';
                        }
                    }
                },
                { data: 'created_at' },
                {
                    data: 'sent_at',
                    render: function (data) {
                        return data || '<span class="text-gray-400">-</span>';
                    }
                },
                {
                    data: null,
                    render: function (data) {
                        return `
                            <button onclick="showDetails(${data.id})" class="px-3 py-1 bg-indigo-500 text-white rounded hover:bg-indigo-600 transition-colors">
                                <i class="fas fa-eye"></i>
                            </button>
                        `;
                    }
                }
            ],
            order: [[0, 'desc']],
            language: {
                "url": "{{ asset('assets/lang/datatables/fa.json') }}"
            }
        });

        // اعمال فیلتر
        $('#btn-filter').on('click', function () {
            messagesTable.ajax.reload();
            loadStats();
        });

        // تغییر فیلتر اعتبارنامه
        $('#filter-credential').on('change', function () {
            loadStats();
        });
    });

    function loadStats() {
        const credentialId = $('#filter-credential').val();

        $.ajax({
            url: '{{ route("sms.messages.stats") }}',
            method: 'GET',
            data: { credential_id: credentialId },
            success: function (response) {
                if (response.success) {
                    const stats = response.data;
                    $('#stat-total').text(stats.total);
                    $('#stat-pending').text(stats.pending);
                    $('#stat-sent').text(stats.sent);
                    $('#stat-blocked').text(stats.blocked);
                    $('#stat-failed').text(stats.failed);
                }
            }
        });
    }

    function showDetails(id) {
        $.ajax({
            url: '{{ route("sms.messages.json") }}',
            method: 'GET',
            success: function (response) {
                const message = response.data.find(m => m.id === id);
                if (message) {
                    let statusClass = 'blue';
                    let statusIcon = 'info-circle';
                    if (message.status === 'sent') {
                        statusClass = 'green';
                        statusIcon = 'check-circle';
                    }
                    if (message.status === 'blocked') {
                        statusClass = 'red';
                        statusIcon = 'ban';
                    }
                    if (message.status === 'failed') {
                        statusClass = 'gray';
                        statusIcon = 'times-circle';
                    }

                    let html = `
                        <div class="space-y-4">
                            <div class="grid grid-cols-2 gap-4">
                                <div class="bg-gray-50 p-4 rounded-lg">
                                    <p class="text-sm text-gray-600 mb-1">شناسه</p>
                                    <p class="font-bold text-gray-900">${message.id}</p>
                                </div>
                                <div class="bg-gray-50 p-4 rounded-lg">
                                    <p class="text-sm text-gray-600 mb-1">نام</p>
                                    <p class="font-bold text-gray-900">${message.user}</p>
                                </div>
                                <div class="bg-gray-50 p-4 rounded-lg">
                                    <p class="text-sm text-gray-600 mb-1"> Credential</p>
                                    <p class="font-bold text-gray-900">${message.credential_name || '-'}</p>
                                </div>
                                <div class="bg-gray-50 p-4 rounded-lg">
                                    <p class="text-sm text-gray-600 mb-1">گیرنده</p>
                                    <p class="font-bold text-gray-900 font-mono">${message.recipient}</p>
                                </div>
                                <div class="bg-gray-50 p-4 rounded-lg">
                                    <p class="text-sm text-gray-600 mb-1">وضعیت</p>
                                    <p class="font-bold text-${statusClass}-600 flex items-center gap-2">
                                        <i class="fas fa-${statusIcon}"></i>
                                        ${message.status_text}
                                    </p>
                                </div>
                                <div class="bg-gray-50 p-4 rounded-lg">
                                    <p class="text-sm text-gray-600 mb-1">تاریخ ایجاد</p>
                                    <p class="font-bold text-gray-900 " dir="ltr">${message.created_at}</p>
                                </div>
                            </div>

                            <div class="bg-indigo-50 p-4 rounded-lg">
                                <p class="text-sm font-semibold text-indigo-900 mb-2">متن پیام:</p>
                                <div class="bg-white p-4 rounded border border-indigo-200 text-gray-800">${message.message}</div>
                            </div>
                    `;
                    // تبدیل blocked_words به آرایه (اگر JSON string بود)
                    let blockedWords = [];
                    try {
                        blockedWords = typeof message.blocked_words === 'string' 
                            ? JSON.parse(message.blocked_words) 
                            : (Array.isArray(message.blocked_words) ? message.blocked_words : []);
                    } catch (e) {
                        blockedWords = [];
                    }
                    
                    if (blockedWords.length > 0) {
                        html += `
                            <div class="bg-red-50 border-2 border-red-200 rounded-lg p-4">
                                <div class="flex items-start gap-3">
                                    <div class="bg-red-600 text-white w-10 h-10 rounded-full flex items-center justify-center flex-shrink-0">
                                        <i class="fas fa-exclamation-triangle"></i>
                                    </div>
                                    <div>
                                        <p class="font-bold text-red-900 mb-2">کلمات غیرمجاز یافت شده (${blockedWords.length} کلمه):</p>
                                        <div class="flex flex-wrap gap-2">
                                            ${blockedWords.map(word => `
                                                <span class="px-3 py-1 bg-red-600 text-white text-sm font-semibold rounded-full">${word}</span>
                                            `).join('')}
                                        </div>
                                    </div>
                                </div>
                            </div>
                        `;
                    }

                    if (message.error_message) {
                        html += `
                            <div class="bg-yellow-50 border-2 border-yellow-200 rounded-lg p-4">
                                <div class="flex items-start gap-3">
                                    <div class="bg-yellow-600 text-white w-10 h-10 rounded-full flex items-center justify-center flex-shrink-0">
                                        <i class="fas fa-info-circle"></i>
                                    </div>
                                    <div>
                                        <p class="font-bold text-yellow-900 mb-2">پیام خطا:</p>
                                        <p class="text-yellow-800">${message.error_message}</p>
                                    </div>
                                </div>
                            </div>
                        `;
                    }

                    if (message.sent_at) {
                        html += `
                            <div class="bg-green-50 p-4 rounded-lg">
                                <p class="text-sm text-green-600 mb-1">تاریخ ارسال</p>
                                <p class="font-bold text-green-900">${message.sent_at}</p>
                            </div>
                        `;
                    }

                    html += '</div>';

                    $('#message-details-content').html(html);
                    document.getElementById('messageDetailsModal').classList.remove('hidden');
                }
            }
        });
    }

    function closeDetailsModal() {
        document.getElementById('messageDetailsModal').classList.add('hidden');
    }

    // Close modal on ESC
    document.addEventListener('keydown', function (e) {
        if (e.key === 'Escape') {
            closeDetailsModal();
        }
    });

    // Close modal on backdrop click
    document.getElementById('messageDetailsModal').addEventListener('click', function (e) {
        if (e.target === this) {
            closeDetailsModal();
        }
    });
</script>