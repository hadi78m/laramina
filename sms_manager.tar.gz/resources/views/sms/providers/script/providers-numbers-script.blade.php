<script>

    // فرض: jQuery و showalertProduction.js (AppAlert) لود شده

    /* لیست روتهای قابل استفاده  */

    const loadNumberUrl = 'sms.providers.numbers';
    const addNumberUrl = 'sms.providers.numbers.store';
    const toggleNumberUrl = 'sms.providers.numbers.toggle';
    const deleteNumberUrl = 'sms.providers.numbers.destroy';
    const testProviderUrl = 'sms.providers.test-connection';
    const createHelperUrl = 'sms.providers.create-helper';

    /* help */

    loading: true,

        /* 
        * هرجا می‌خواهیم خودمان مودال را بسازیم  و در 
        * error یا .fail 
        * خودمان 
        * AppAlert.showError(...)
        * را صدا بزنیم
        * */

        // errorAlert: true, 
        /* *
        * هرجا می‌خواهیم خودمان مودال را بسازیم  و در 
        * success یا .done 
        * خودمان 
        * AppAlert.showSuccess(...)
        * را صدا بزنیم
        * */
        // successAlert: false  

        // هرجا انتظار مودال موفقیت خودکار داریم
        // successAlert: true در options می‌فرستیم
        /*  */

        $(document).on('click', '#btn-show-numbers', function (e) {
            e.preventDefault()
            const providerId = $(this).data('provider-id')
            $('#current_provider_id').val(providerId);

            if (!providerId) {
                AppAlert.showError('شناسه ارسال‌کننده پیدا نشد.')
                return
            }
            openNumbersModal();
            /* فراخوانی لیست شماره ها */
            loadNumbers(providerId)

        })
    /* فراخوانی لیست شماره ها */
    function loadNumbers(providerId) {

        $.get(AppAlert.route(loadNumberUrl, { provider: providerId }))
            .done(renderNumbers)
            .fail(() => {
                AppAlert.showError('خطا در ارتباط با سرور');
                $('#numbersLoading').addClass('hidden');
                // closeNumbersModal();
            });
    }
    /*
    *
    * ایجاد شماره ها 
    * 
    */
    function renderNumbers(res) {

        if (!res.success) {
            AppAlert.showError('خطا در دریافت شماره‌ها');
            closeNumbersModal();
            return;
        }

        const tbody = $('#numbersTable tbody');
        tbody.empty();

        if (!res.data || res.data.length === 0) {

            tbody.append(`
            <tr>
                <td colspan="3" class="text-center py-4 text-gray-500">
                    هیچ شماره‌ای ثبت نشده است
                </td>
            </tr>
        `);

        } else {

            (res.data || []).forEach(num => {

                const status = num.is_active
                    ? '<span class="status-badge bg-green-100 text-green-800 px-2 py-1 rounded">فعال</span>'
                    : '<span class="status-badge bg-red-100 text-red-800 px-2 py-1 rounded">غیرفعال</span>';

                tbody.append(`
        <tr data-number-id="${num.id}">
            <td class="px-4 py-2">${num.number}</td>
            <td class="px-4 py-2 status-cell">${status}</td>
            <td class="px-4 py-2 flex gap-2">
                <button class="bg-yellow-500 text-white px-2 py-1 rounded toggle-status" data-id="${num.id}">
                    تغییر وضعیت
                </button>
                <button class="bg-red-500 text-white px-2 py-1 rounded delete-number" data-id="${num.id}">
                    حذف
                </button>
            </td>
        </tr>
    `);

            });

        }

        $('#numbersLoading').addClass('hidden');
        $('#numbersTableDiv').removeClass('hidden');

    }


    $(document).on('click', '#closeNumbersModal', function () {
        closeNumbersModal()
    })

    $(document).on('click', '#numbersModal', function (e) {

        if (e.target.id === 'numbersModal') {
            closeNumbersModal()
        }

    })

    /*
    * 
    *  for modal
    * 
    */
    function openNumbersModal() {
        $('.number').val('');
        $('#numbersLoading').removeClass('hidden');
        $('#numbersTableDiv').addClass('hidden');
        $('#numbersTable tbody').empty(); // پاک کردن لیست قبلی

        $('#numbersModal').removeClass('hidden').addClass('flex')

    }
    function closeNumbersModal() {

        $('.number').val('');
        $('#numbersModal').addClass('hidden').removeClass('flex')
        $('#numbersLoading').addClass('hidden');
        $('#numbersTableDiv').addClass('hidden');
        $('#numbersTable tbody').empty(); // پاک کردن لیست قبلی
    }

    /* 
    *
    *
    * حذف شماره پروایدرها
    *
    */
    $('#numbersModal').on('click', '.delete-number', function () {

        const btn = $(this);
        const numberId = btn.data('id');
        const providerId = getProviderId();

        btn.prop('disabled', true);

        AppAlert.confirmDelete(
            AppAlert.route(deleteNumberUrl, {
                provider: providerId,
                number: numberId
            }),
            {
                title: 'حذف شماره',
                text: 'آیا از حذف این شماره مطمئن هستید؟'
            }
        )
            .then(function (res) {

                if (!res) return;

                loadNumbers(providerId);

            })
            .finally(function () {

                btn.prop('disabled', false);

            });

    });

    /* 
    *
    * تغییر وضعیت
    *
    */


    $('#numbersModal').on('click', '.toggle-status', function () {

        const btn = $(this);
        const numberId = btn.data('id');
        const providerId = getProviderId();

        if (!providerId) {
            AppAlert.showError('شناسه ارسال‌کننده پیدا نشد.');
            return;
        }

        btn.prop('disabled', true);

        AppAlert.post(
            AppAlert.route(toggleNumberUrl, {
                provider: providerId,
                number: numberId
            }),
            {},
            {
                loading: true,
                errorAlert: true,
                successAlert: false,
                success: function (res) {

                    if (!res) return;
                    loadNumbers(providerId);
                    if (res.message) {
                        AppAlert.showSuccess(res.message);
                    }
                }
            }
        )
            .always(function () {
                btn.prop('disabled', false);
            });

    });


    /*
    *
    * افزودن شماره جدید 
    * 
    */


    // Submit فرم افزودن شماره
    $('#addNumberForm').on('submit', function (e) {

        e.preventDefault();

        const form = $(this);
        const providerId = getProviderId();

        storeNumber(providerId, form);

    });


    function storeNumber(providerId, form) {

        const data = form.serialize();
        const submitBtn = form.find('button[type=submit]');

        submitBtn.prop('disabled', true);
        AppAlert.showLooading();


        return AppAlert.post(
            AppAlert.route(addNumberUrl, { provider: providerId }),
            data,
            {
                success: handleNumberStored
            }
        )
            // .fail(handleStoreError)
            .always(function () {

                submitBtn.prop('disabled', false);
                AppAlert.hideLooading();

            });
    }




    /* نمایش موفقیت در ثبت شماره جدید */
    function handleNumberStored(res) {

        if (!res.success) {
            AppAlert.showError(res.message || 'خطا در اعمال تغییرات');
            return;
        }

        const form = $('#addNumberForm');
        const providerId = getProviderId();

        form[0].reset();

        loadNumbers(providerId);

        AppAlert.showSuccess(res.message);
    }


    /* نمایش خطای ثبت شماره جدید */
    function handleStoreError(xhr) {

        const message = xhr.responseJSON?.message || 'خطا در اعمال تغییرات';

        AppAlert.showError(message);

    }




    function getProviderId() {
        return $('#current_provider_id').val();
    }



    /*** تست اتصال**/

    async function testConnection(id) {

        const { value: phone } = await Swal.fire({
            title: 'شماره تلفن را وارد کنید',
            input: 'text',
            inputPlaceholder: 'مثلا 09123456789',
            showCancelButton: true,
            confirmButtonText: 'تست اتصال',
            cancelButtonText: 'انصراف',
            inputValidator: (value) => {
                if (!value) {
                    return 'شماره تلفن الزامی است';
                }
                const mobileRegex = /^09\d{9}$/;

                if (!mobileRegex.test(value)) {
                    return 'شماره موبایل معتبر نیست';
                }
            }
        });

        if (!phone) return;

        AppAlert.showLoading('در حال تست اتصال...');

        AppAlert.post(
            AppAlert.route(testProviderUrl, { id }),
            { phone: phone },
            { loading: true, errorAlert: true, successAlert: false }
        )
            .done(function (res) {

                if (!res) return;

                AppAlert.showSuccess(`<div class="text-right text-lg">
                        <p><strong>پروایدر:</strong> ${res.provider}</p>
                        <p><strong>زمان پاسخ:</strong> ${res.response_time}ms</p>
                        ${res.message ? `<p><strong>پیام:</strong> ${res.message}</p>` : ''}
                      </div>`);

            })
            .fail(function (xhr) {

                const message = xhr.responseJSON?.message || 'مشکل در ارتباط با سرور';
                AppAlert.showError(message);

            })
            .always(function () {

                // AppAlert.hideLooading();

            });
    }

    // ایجاد هلپر
    async function createHelper(id) {

        const { value: name } = await Swal.fire({
            title: 'نام هلپر  را وارد کنید',
            input: 'text',
            inputPlaceholder: 'مثال :KaveHelper یا kave',
            showCancelButton: true,
            confirmButtonText: 'ذخیره ',
            cancelButtonText: 'انصراف',
            inputValidator: (value) => {
                if (!value) {
                    return 'نام هلپر  الزامی است';
                }
            }
        });

        if (!name) return;

        AppAlert.showLoading('در حال ارتباط...');

        AppAlert.post(
            AppAlert.route(createHelperUrl, { id }),
            { helper_name: name },
            { loading: true, errorAlert: true, successAlert: false }
        )
            .done(function (res) {

                if (!res) return;

                document.dispatchEvent(new CustomEvent('admin:table:reload', {}))
                AppAlert.showSuccess(res.message);

            })
            .fail(function (xhr) {

                const message = xhr.responseJSON?.message || 'مشکل در ارتباط با سرور';
                AppAlert.showError(message);

            })
            .always(function () {

                // AppAlert.hideLooading();

            });
    }

</script>