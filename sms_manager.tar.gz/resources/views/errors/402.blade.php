@extends('errors::minimal')

@section('title', __('خطای 402 - نیاز به پرداخت'))
@section('code', '402')

@section('message')
<style>
    .pulse {
     animation: pulse 2s cubic-bezier(0.4, 0, 0.6, 1) infinite;
    }
    @keyframes pulse {
     0%, 100% { transform: scale(1); opacity: 1; }
     50% { transform: scale(1.05); opacity: 0.8; }
    }
    .coin-rotate {
     animation: coinRotate 4s ease-in-out infinite;
    }
    @keyframes coinRotate {
     0% { transform: rotateY(0deg); }
     100% { transform: rotateY(360deg); }
    }
</style>
<div class="max-w-lg w-full bg-white rounded-xl shadow-2xl overflow-hidden">
    <div class="bg-gradient-to-r from-emerald-500 to-green-600 p-6 text-center">
        <div class="coin-rotate inline-block">
            <svg xmlns="http://www.w3.org/2000/svg" class="h-20 w-20 mx-auto text-white" fill="none" viewBox="0 0 24 24"
                stroke="currentColor">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                    d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
            </svg>
        </div>
        <h1 class="text-3xl font-bold text-white mt-4">402 - نیاز به تهیه اشتراک</h1>
    </div>

    <div class="p-8 text-center">
        <p class="text-gray-700 mb-6">برای دسترسی به این بخش نیاز به تهیه اشتراک دارید.</p>

        <div class="bg-emerald-50 border border-emerald-200 text-emerald-700 px-4 py-3 rounded mb-6">
            <div class="flex items-center justify-center space-x-2">
                <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
                    <path fill-rule="evenodd"
                        d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7-4a1 1 0 11-2 0 1 1 0 012 0zM9 9a1 1 0 000 2v3a1 1 0 001 1h1a1 1 0 100-2h-1V9z"
                        clip-rule="evenodd" />
                </svg>
                <span>این محتوا فقط برای کاربران ویژه قابل دسترسی است</span>
            </div>
        </div>

        <div class="space-y-3">
            <button
                class="w-full bg-emerald-600 hover:bg-emerald-700 text-white font-bold py-3 px-4 rounded-lg transition duration-200 pulse flex items-center justify-center">
                <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5 ml-1" viewBox="0 0 20 20" fill="currentColor">
                    <path fill-rule="evenodd"
                        d="M4 4a2 2 0 00-2 2v4a2 2 0 002 2V6h10a2 2 0 00-2-2H4zm2 6a2 2 0 012-2h8a2 2 0 012 2v4a2 2 0 01-2 2H8a2 2 0 01-2-2v-4zm6 4a2 2 0 100-4 2 2 0 000 4z"
                        clip-rule="evenodd" />
                </svg>
                پرداخت و ادامه
            </button>
            <a href="/"
                class="block text-emerald-600 hover:text-emerald-800 font-medium py-2 px-4 rounded-lg transition duration-200">
                بازگشت به صفحه اصلی
            </a>
            <a href="{{ url()->previous() }}"
                class="block text-gray-600 hover:text-gray-800 font-medium py-2 px-4 rounded-lg transition duration-200">
                بازگشت به صفحه قبل
            </a>
        </div>
    </div>

    <div class="bg-gray-50 px-6 py-4 text-center text-gray-500 text-sm">
        <p>کد خطا: 402_PAYMENT_REQUIRED</p>
        <p class="mt-1">پشتیبانی از درگاه‌های زرین‌پال، پرداخت ویدیو</p>
    </div>
</div>
@endsection
