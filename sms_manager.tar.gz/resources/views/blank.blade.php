@extends('layouts.mclsApp')

@section('content')
    <div class="bg-white dark:bg-dark-100 p-4 md:p-6 rounded-lg shadow dark:shadow-gray-800/50">
        <div class="flex justify-between items-center mb-4">
            <h2 class="text-lg md:text-xl font-bold text-gray-800 dark:text-gray-200">جدول اطلاعات</h2>
        </div>
        <x-form.table id="" class=" ">
            <x-slot name="thead">
                <tr class="bg-gray-100 dark:bg-dark-300">
                    <th class="py-2 px-3 md:px-4 border-b text-right text-gray-800 dark:text-gray-200">ردیف</th>
                    <th class="py-2 px-3 md:px-4 border-b text-right text-gray-800 dark:text-gray-200">نام</th>
                    <th class="py-2 px-3 md:px-4 border-b text-right text-gray-800 dark:text-gray-200">ایمیل</th>
                    <th class="py-2 px-3 md:px-4 border-b text-right text-gray-800 dark:text-gray-200 hidden sm:table-cell">
                        تاریخ ثبت</th>
                    <th class="py-2 px-3 md:px-4 border-b text-right text-gray-800 dark:text-gray-200">وضعیت</th>
                </tr>
            </x-slot>
            <tbody>
                <tr class="hover:bg-gray-50 dark:hover:bg-dark-200">
                    <td class="py-2 px-3 md:px-4 border-b text-right text-gray-700 dark:text-gray-300">1</td>
                    <td class="py-2 px-3 md:px-4 border-b text-right text-gray-700 dark:text-gray-300">محمد رضایی</td>
                    <td class="py-2 px-3 md:px-4 border-b text-right text-gray-700 dark:text-gray-300">
                        mohammad@example.com</td>
                    <td class="py-2 px-3 md:px-4 border-b text-right text-gray-700 dark:text-gray-300 hidden sm:table-cell">
                        1402/05/15</td>
                    <td class="py-2 px-3 md:px-4 border-b text-right">
                        <span
                            class="bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200 px-2 py-1 rounded text-xs">فعال</span>
                    </td>
                </tr>
                <tr class="hover:bg-gray-50 dark:hover:bg-dark-200">
                    <td class="py-2 px-3 md:px-4 border-b text-right text-gray-700 dark:text-gray-300">2</td>
                    <td class="py-2 px-3 md:px-4 border-b text-right text-gray-700 dark:text-gray-300">فاطمه محمدی</td>
                    <td class="py-2 px-3 md:px-4 border-b text-right text-gray-700 dark:text-gray-300">
                        fatemeh@example.com</td>
                    <td class="py-2 px-3 md:px-4 border-b text-right text-gray-700 dark:text-gray-300 hidden sm:table-cell">
                        1402/06/22</td>
                    <td class="py-2 px-3 md:px-4 border-b text-right">
                        <span
                            class="bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-200 px-2 py-1 rounded text-xs">در
                            حال بررسی</span>
                    </td>
                </tr>
                <tr class="hover:bg-gray-50 dark:hover:bg-dark-200">
                    <td class="py-2 px-3 md:px-4 border-b text-right text-gray-700 dark:text-gray-300">3</td>
                    <td class="py-2 px-3 md:px-4 border-b text-right text-gray-700 dark:text-gray-300">علی حسینی</td>
                    <td class="py-2 px-3 md:px-4 border-b text-right text-gray-700 dark:text-gray-300">ali@example.com
                    </td>
                    <td class="py-2 px-3 md:px-4 border-b text-right text-gray-700 dark:text-gray-300 hidden sm:table-cell">
                        1402/07/10</td>
                    <td class="py-2 px-3 md:px-4 border-b text-right">
                        <span
                            class="bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-200 px-2 py-1 rounded text-xs">غیرفعال</span>
                    </td>
                </tr>
            </tbody>
        </x-form.table>
    </div>
    {{-- if don't need sidebar --}}
    <x-elements.sidebar />
@endsection
