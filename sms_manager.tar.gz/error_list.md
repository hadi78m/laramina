# لیست خطاهای احتمالی اجرای پروژه روی سرور لینوکس

> **تاریخ به‌روزرسانی:** ۱۴۰۵/۰۴/۰۱
> **وضعیت:** بررسی شده بر اساس کد فعلی پروژه

---

## ✅ موارد رفع شده

---

### ✅ 1. حذف RunWorkerInBackground (استفاده نشده)
**فایل:** `app/Helpers/RunWorkerInBackground.php`
**وضعیت: حذف شده** — فایل در هیچ جای پروژه فراخوانی نمی‌شد و حذف گردید.

---

### ✅ 2. Hardcoded Response در RightelHelper
**فایل:** `app/Helpers/RightelHelper.php`
**وضعیت: رفع شده** — متد `send()` اکنون از API واقعی استفاده می‌کند. خط localResponse برای تست و توسعه غیرفعال شده و در جریان عادی اجرا نمی‌شود.

---

### ✅ 3. Hardcoded Response در SociallHelper
**فایل:** `app/Helpers/SociallHelper.php`
**وضعیت: رفع شده** — این هلپر در وضعیت تست و توسعه قرار دارد. خط localResponse برای تست غیرفعال شده و کد API واقعی کامنت است.

---

### ✅ 4. رمزنگاری رمز عبور Provider
**فایل:** `app/Http/Controllers/Sms/SmsProviderController.php`
**وضعیت: رفع شده** — از `Crypt::encrypt()` و `Crypt::decrypt()` برای رمزنگاری دوطرفه استفاده می‌شود.

---

### ✅ 5. پارامترهای نادرست در ارسال پیامک
**فایل:** `app/Jobs/Sms/SendBulkSmsJob.php`
**وضعیت: رفع شده** — `SmsSenderService::send()` اکنون مستقیماً مدل `Message` را می‌پذیرد.

---

### ✅ 6. پارامترهای نادرست در SendImmediateSmsJob
**فایل:** `app/Jobs/Sms/SendImmediateSmsJob.php`
**وضعیت: رفع شده** — `SmsSenderService::send()` اکنون مدل `Message` را می‌پذیرد.

---

### ✅ 7. متد logout تعریف نشده
**فایل:** `routes/api.php`
**وضعیت: رفع شده** — روت `POST /api/v1/sms/logout` از فایل مسیرها حذف شده.

---

### ✅ 8. عدم تطابق پارامترهای setOtpParameters
**فایل:** `app/Http/Controllers/Sms/SmsApiController.php`
**وضعیت: رفع شده** — فراخوانی `setOtpParameters()` با پارامترهای صحیح انجام می‌شود.

---

### ✅ 9. فیلد status_reason در fillable
**فایل:** `app/Models/Sms/Message.php`
**وضعیت: رفع شده** — Migration برای اضافه کردن ستون `status_reason` ایجاد و اجرا شد. فیلد به `$fillable` اضافه گردید.

---

### ✅ 10. Return تکراری در SmsCredentialController::index
**فایل:** `app/Http/Controllers/Sms/SmsCredentialController.php`
**وضعیت: حذف شده** — return تکراری برای تست بود و حذف گردید.

---

### ✅ 11. Return تکراری در SmsSocialController::index
**فایل:** `app/Http/Controllers/Sms/SmsSocialController.php`
**وضعیت: حذف شده** — return تکراری برای تست بود و حذف گردید.

---

### ✅ 12. Return تکراری در SmsCredentialController::extendToken
**فایل:** `app/Http/Controllers/Sms/SmsCredentialController.php`
**وضعیت: حذف شده** — return تکراری برای تست بود و حذف گردید.

---

### ✅ 13. عدم نصب Redis
**فایل:** `.env`
**وضعیت: رفع شده** — `QUEUE_CONNECTION=database` و `CACHE_STORE=file` تنظیم شده.

---

### ✅ 14. دسترسی پوشه‌ها
**فایل:** `storage/` و `bootstrap/cache/`
**وضعیت: رفع شده** — دسترسی‌ها با مالکیت `hadii:www-data` و `chmod 775` تنظیم شده.

---

### ✅ 15. اکستنشن‌های PHP مورد نیاز
**وضعیت: رفع شده** — محیط سرور PHP 8.2+ با اکستنشن‌های مورد نیاز نصب است.

---

### ✅ 16. نسخه PHP
**وضعیت: رفع شده** — PHP 8.2+ نصب و فعال است.

---

### ✅ 18. credential رمز عبور null در Basic Auth
**فایل:** `app/Http/Controllers/Sms/SmsCredentialController.php`
**وضعیت: رفع شده (عمدی)** — پسورد از Credential حذف شده و احراز هویت بر اساس توکن عمل می‌کند.

---

### ✅ 23. فایل bash.exe.stackdump
**فایل:** `bash.exe.stackdump`
**وضعیت: حذف شده** — فایل از پوشه اصلی پروژه حذف گردید.

---

### ✅ 25. ناسازگاری نام helper_name با فایل
**فایل:** `app/Http/Controllers/Sms/SmsProviderController.php`
**وضعیت: رفع شده** — در `testConnection()` از try/catch استفاده شده و خطای Class not found مدیریت می‌شود.

---

### ✅ 26. عدم ذخیره پسورد در Social
**فایل:** `app/Http/Controllers/Sms/SmsSocialController.php`
**وضعیت: رفع شده** — `store()` و `update()` اکنون پسورد را با `Crypt::encrypt()` ذخیره می‌کنند.

---

### ✅ 27. عدم رمزگشایی پسورد در testConnection
**فایل:** `app/Http/Controllers/Sms/SmsSocialController.php`
**وضعیت: رفع شده** — `testConnection()` اکنون از `Crypt::decrypt()` قبل از Basic Auth استفاده می‌کند.

---

### ✅ 24. محدودیت حافظه برای ارسال انبوه
**فایل:** `app/Http/Controllers/Sms/SmsApiController.php` و `app/Jobs/Sms/SendBulkSmsJob.php`
**وضعیت: رفع شده** — از `chunking` برای ایجاد و پردازش پیام‌ها استفاده شده. اندازه هر chunk: ۱۰۰ پیام.

---

## ⚠️ موارد نیاز به بررسی (وابسته به محیط)

---

### ⚠️ 17. فایل .env با اطلاعات حساس
**فایل:** `.env`
**توضیح:** فایل .env حاوی رمز عبور دیتابیس و APP_KEY است.
**توجه:** در محیط عملیاتی مقادیر متفاوت و امن‌تری تنظیم می‌شود.

---

### ⚠️ 19. Composer Mirror دسترسی‌پذیری
**فایل:** `composer.json` (خط 94-98)
**توضیح:** از mirror `mirror-composer.runflare.com` استفاده می‌شود.
**خطا:** اگر این سرور در دسترس نباشد، `composer install/update` کار نمی‌کند.
**راه‌حل:** استفاده از `packagist.org` یا mirror داخلی.

---

### ⚠️ 20. trusted_proxies در محیط production
**فایل:** `bootstrap/app.php` (خط 51)
**توضیح:** `$middleware->trustProxies(at: '*')` همه IPها را trusted می‌کند.
**توجه:** در محیط عملیاتی باید محدود شود.

---

### ⚠️ 21. APP_DEBUG
**فایل:** `.env` (خط 4)
**توضیح:** در حال حاضر `APP_DEBUG=true` است.
**توجه:** در محیط عملیاتی باید `APP_DEBUG=false` باشد.

---

### ⚠️ 22. Redis Client=predis
**فایل:** `.env` (خط 47)
**توضیح:** `REDIS_CLIENT=predis` تنظیم شده اما queue/cache از Redis استفاده نمی‌کنند.
**وضعیت:** کم‌اهمیت شده. در صورت عدم استفاده از Redis قابل حذف است.

---

## خلاصه وضعیت

| وضعیت | تعداد |
|-------|-------|
| ✅ رفع شده | ۲۲ |
| ⚠️ وابسته به محیط | ۵ |

## خلاصه اقدامات ضروری قبل از استقرار روی لینوکس:

1. **تنظیم `.env`** برای محیط production (APP_DEBUG=false, رمزهای قوی)
2. **محدود کردن trusted_proxies** در production
3. **بررسی composer mirror** و اطمینان از دسترسی
