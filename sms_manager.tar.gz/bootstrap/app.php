<?php

use Illuminate\Foundation\Application;
use Illuminate\Foundation\Configuration\Exceptions;
use Illuminate\Foundation\Configuration\Middleware;
use Spatie\Permission\Middleware\RoleMiddleware;
use Spatie\Permission\Middleware\PermissionMiddleware;
use Spatie\Permission\Middleware\RoleOrPermissionMiddleware;

return Application::configure(basePath: dirname(__DIR__))
    ->withRouting(
        web: __DIR__ . '/../routes/web.php',
        api: __DIR__ . '/../routes/api.php',
        commands: __DIR__ . '/../routes/console.php',
        health: '/up',
    )
    // ثبت Alias های میان‌افزار Spatie
    ->withMiddleware(function (Middleware $middleware) {
        $middleware->alias([
            'role' => RoleMiddleware::class,
            'permission' => PermissionMiddleware::class,
            'role_or_permission' => RoleOrPermissionMiddleware::class,
        ]);
    })
    ->withMiddleware(function (Middleware $middleware) {

        // Sanctum برای APIهای stateful (حتی اگر SPA داشته باشید)
        $middleware->api(prepend: [
            \Laravel\Sanctum\Http\Middleware\EnsureFrontendRequestsAreStateful::class,
        ]);

        // ثبت alias برای Sanctum (مهم!)
        $middleware->alias([
            'auth.sanctum' => \Laravel\Sanctum\Http\Middleware\EnsureFrontendRequestsAreStateful::class,
        ]);

        // اگر از Spatie Permission استفاده می‌کنید
        $middleware->alias([
            'role' => \Spatie\Permission\Middleware\RoleMiddleware::class,
            'permission' => \Spatie\Permission\Middleware\PermissionMiddleware::class,
            'role_or_permission' => \Spatie\Permission\Middleware\RoleOrPermissionMiddleware::class,
        ]);

        // فقط برای وب (session و CSRF)
        $middleware->web(append: [
            \Illuminate\Session\Middleware\AuthenticateSession::class,
        ]);

        //  if (app()->environment('production') || true) { // true برای تست اجباری
        //بررسی تنظیمات پروکسی
        $middleware->trustProxies(at: '*');
        //  }
        //#TODO جلوگیری از ورود یک کاربر در دو سیستم لاراول 12
        // $middleware->web(append: [
        //     \Illuminate\Session\Middleware\AuthenticateSession::class,
        // ]);
        // ۱. اگر می‌خواهید به صورت global (همه درخواست‌ها) اجرا شود:
        // $middleware->append(\App\Http\Middleware\RestrictByTokenIp::class);

        // ۲. اگر می‌خواهید alias تعریف کنید (مثل کاری که قبلاً در Kernel می‌کردید)
        $middleware->alias([
            'restrict.token.ip' => \App\Http\Middleware\RestrictByTokenIp::class,
            // می‌توانید aliasهای دیگر را هم اینجا اضافه کنید
            // 'throttle.api'   => \Illuminate\Routing\Middleware\ThrottleRequests::class.':api',
        ]);
    })
    ->withExceptions(function (Exceptions $exceptions) {
        //
    })->create();
