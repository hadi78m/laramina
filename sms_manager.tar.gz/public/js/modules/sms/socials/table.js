import { createForm } from './forms/create-form.js'
import { socialActions } from './actions.js'

const publicLang = AdminLang.getNamespace('common');
const moduleFields = AdminLang.getNamespace('modules.socials.fields');
const moduleActions = AdminLang.getNamespace('modules.socials.actions');

export default {

    endpoint: 'sms.socials.json',
    search: true,

    headerTitle: moduleFields.header_title || (publicLang.manage + ' ' + (moduleFields.title || 'sms.socials')),
    addButtonLabel: moduleActions.create || (publicLang.create + ' ' + (moduleActions.item || publicLang.item)),
    displayButton: true,

    actions: socialActions,

    perPage: 10,

    modalTheme: 'light',


    modals: {
        create: {
            title: moduleActions.create || publicLang.create,
            width: '500px',
            form: createForm,
            roles:['SuperAdmin']
        },
        edit: {
            title: moduleActions.edit || publicLang.edit,
            width: '500px',
            form: createForm
        }
    },



    filters: [
        {
            key: 'is_active',
            label: publicLang.status,
            type: 'select',
            options: {
                1: publicLang.active,
                0: publicLang.inactive
            }
        },
        {
            key: 'is_default',
            label: publicLang.is_default,
            type: 'select',
            options: {
                1: publicLang.is_default,
                0: publicLang.not_default
            }
        }
    ],

    columns: [
        // { key: 'id', label: publicLang.id, sortable: true },
        { key: 'name', label: publicLang.name + ' ' + moduleFields.social, sortable: true },
        // { key: 'user', label: publicLang.user },
        // { key: 'token', label: publicLang.token || moduleFields.token },
        { key: 'url', label: publicLang.url },
        {
            key: 'is_default',
            label: publicLang.is_default,
            type: 'action-toggle',
            confirmTitle: moduleActions.confirm_set_default || publicLang.confirm_set_default,
            endpoint: 'sms.socials.set-default',
            map: {
                true: { label: publicLang.is_default, color: 'green' },
                false: { label: publicLang.not_default || moduleActions.select_default, color: 'gray' }
            }
        },
        {
            key: 'is_active',
            label: publicLang.status,
            type: 'action-toggle',
            endpoint: 'sms.socials.toggle-status',
            confirmTitle: publicLang.confirm_toggle_status || moduleActions.confirm_toggle_status,
            map: {
                true: { label: publicLang.active, color: 'green' },
                false: { label: publicLang.inactive, color: 'gray' }
            },
            icons: {
                true: { html: '<i class="fa-solid fa-toggle-on  text-lg"></i>', color: 'green' },
                false: { html: '<i class="fa-solid fa-toggle-off  text-lg"></i>', color: 'red' }
            }
        },
        { key: 'send_rate', label: publicLang.send_rate || moduleFields.send_rate },
        {
            key: 'rate_unit', label: publicLang.rate_unit || moduleFields.rate_unit,
            type: 'badge',
            map: {
                per_second: { label: 'در ثانیه', color: 'gray' },
                per_minuts: { label: 'در دقیقه', color: 'blue' },
                per_hour: { label: 'در ساعت', color: 'purple' },
                unlimited: { label: 'نامحدود', color: 'green' },
            }
        },
        { key: 'created_at', label: publicLang.created_at, sortable: true },
        {
            label: publicLang.actions,
            type: 'actions',
            actions: ['edit', 'delete']
        }
    ],

}