<?php

namespace App\Models\Sms;

use Illuminate\Database\Eloquent\Model;

class Social extends Model
{
    protected $table = 'socials';

    protected $fillable = [
        'name',
        'user',
        'password',
        'url',
        'is_default',
        'is_active',
        'created_by',
        'send_rate',
        'rate_unit',
        'token'
    ];

    protected $hidden = ['password'];

    protected $casts = [
        'is_default' => 'boolean',
        'is_active' => 'boolean',
    ];

    public function creator()
    {
        return $this->belongsTo(\App\Models\User::class, 'created_by');
    }

    // متدی برای دریافت پیام رسان پیش‌فرض (اگر در دیتابیس ست شده باشد)
    public static function getDefault()
    {
        return self::where('is_default', true)->where('is_active', true)->first();
    }
    // تنظیم پیش‌فرض + فقط پیام رسانهای فعال قابل انتخاب باشند
    public static function setAsDefault($socialId)
    {
        $provider = static::findOrFail($socialId);

        if (!$provider->is_active) {
            throw new \Exception('پیام رسان غیرفعال نمی‌تواند پیش‌فرض باشد.');
        }

        static::query()->update(['is_default' => false]);
        static::where('id', $socialId)->update(['is_default' => true]);
    }

    // تغییر وضعیت فعال/غیرفعال
    public function toggleStatus()
    {
        if ($this->is_default && $this->is_active) {
            // اگر پیش‌فرض بود و فعال است → غیرفعال کردن مجاز نیست
            throw new \Exception('پیام رسان پیش‌فرض را نمی‌توان غیرفعال کرد.');
        }

        $this->is_active = !$this->is_active;
        $this->save();
    }
}
