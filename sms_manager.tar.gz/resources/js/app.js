import "./bootstrap"; // اگر نیازی به این فایل نیست، حذف کنید
import '@fortawesome/fontawesome-free/css/all.min.css';


import Alpine from "alpinejs";
import Swal from "sweetalert2";

window.Swal = Swal; // برای دسترسی جهانی به SweetAlert2

window.Alpine = Alpine;
Alpine.start();

$(document).ready(function () {
    $(".select2").select2({
        tags: true,
        dir: "rtl",
        placeholder: "گزینه ای را انتخاب یا وارد نمایید",
        allowClear: true,
    });
});

