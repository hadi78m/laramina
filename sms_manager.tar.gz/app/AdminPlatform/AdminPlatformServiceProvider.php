<?php

namespace App\AdminPlatform;

use Illuminate\Support\ServiceProvider;

class AdminPlatformServiceProvider extends ServiceProvider
{
    public function register(): void
    {
        $this->mergeConfigFrom(
            config_path('admin-platform.php'),
            'admin-platform'
        );
    }

    public function boot(): void
    {
        //
    }
}
