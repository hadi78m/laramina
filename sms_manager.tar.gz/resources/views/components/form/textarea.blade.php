<div {{ $attributes->class(['mb-4']) }}>
    @isset($label)
        <label class="block text-sm font-bold text-gray-700 mb-2" for="{{ $inputId ?? '' }}">
            {{ $label }}
        </label>
    @endisset
    <textarea
        {{ $attributes->merge([
            'class' => 'w-full border-gray-400 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500 ',
            'id' => $inputId ?? '',
            'name' => $inputName ?? '',
        ])}}></textarea>
</div>
