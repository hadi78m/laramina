@extends('errors::minimal')

@section('title', __('خطای 404 - صفحه یافت نشد'))
@section('code', '404')

@php
    $message = ' صفحه مورد نظر یافت نشد';
@endphp
@section('message')
    <style>
        .ghost {
            animation: float 6s ease-in-out infinite;
        }

        @keyframes float {

            0%,
            100% {
                transform: translateY(0);
            }

            50% {
                transform: translateY(-20px);
            }
        }
    </style>
    <div class="max-w-lg w-full bg-white rounded-xl shadow-2xl overflow-hidden">
        <div class="bg-gradient-to-r from-purple-500 to-indigo-600 p-6 text-center">
            <div class="ghost">
                <svg xmlns="http://www.w3.org/2000/svg" class="h-20 w-20 mx-auto text-white" fill="none" viewBox="0 0 24 24"
                    stroke="currentColor">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                        d="M9.172 16.172a4 4 0 015.656 0M9 10h.01M15 10h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                </svg>
            </div>
            <h1 class="text-3xl font-bold text-white mt-4">404 - صفحه یافت نشد</h1>
        </div>

        <div class="p-8 text-center">
            <p class="text-gray-700 mb-6">اوه! به نظر می‌رسد صفحه‌ای که به دنبال آن هستید وجود ندارد.</p>

            <div class="bg-purple-50 border border-purple-200 text-purple-700 px-4 py-3 rounded mb-6">
                <p>آدرس وارد شده ممکن است اشتباه باشد یا صفحه حذف شده است.</p>
            </div>

            <div class="flex flex-col space-y-3">
                <a href="/"
                    class="bg-indigo-600 hover:bg-indigo-700 text-white font-medium py-2 px-4 rounded-lg transition duration-200">
                    بازگشت به صفحه اصلی
                </a>
                <a href="{{ url()->previous() }}"
                    class="text-indigo-600 hover:text-indigo-800 font-medium py-2 px-4 rounded-lg transition duration-200">
                    بازگشت به صفحه قبل
                </a>
                <a {{-- href="/contact"  --}}
                    class="text-gray-600 hover:text-gray-800 font-medium py-2 px-4 rounded-lg transition duration-200">
                    گزارش مشکل
                </a>
            </div>
        </div>
    </div>
@endsection
