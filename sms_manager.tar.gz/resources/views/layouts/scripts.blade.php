<script src="{{asset('js/jalaali-js/jalaali.min.js')}}"></script>
{{--
<script src="{{ asset('js/petite-vue-ajax.js') }}"></script> --}}
{{-- <script src="{{ asset('js/petite-vue/petite-vue.iife0.4.1.js') }}"></script> --}}

<script src="{{ asset('js/select2/4.1.0/select2.min.js') }}"></script>

{{-- sweetalert2 --}}
<script src="{{ asset('js/sweetalert/sweetalert2@11.14.4.js') }}"></script>



{{-- dataTables --}}
<script src="{{ asset('dist/dataTables/2.3.0/js/dataTables.min.js') }}"></script>

{{-- Buttons --}}
<script type="text/javascript" charset="utf8"
    src="{{ asset('dist/dataTables/buttons/3.2.3/js/dataTables.buttons.min.js') }}"></script>
<script type="text/javascript" charset="utf8"
    src="{{ asset('dist/dataTables/buttons/3.2.3/js/buttons.print.min.js') }}"></script>
<script type="text/javascript" charset="utf8"
    src="{{ asset('dist/dataTables/buttons/3.2.3/js/buttons.html5.min.js') }}"></script>
<script type="text/javascript" charset="utf8" src="{{ asset('dist/dataTables/js/jszip.min.js') }}"></script>

{{-- Responsive --}}
{{--
<script src="https://cdn.datatables.net/responsive/3.0.4/js/dataTables.responsive.min.js"></script> --}}

{{-- RowGroup --}}
<script src="{{ asset('dist/dataTables/rowgroup/1.5.1/js/dataTables.rowGroup.min.js') }}"></script>
{{-- RowsGroup --}}
<script src="{{ asset('dist/dataTables/js/dataTables.rowsGroup.js') }}"></script>

{{-- chartJs --}}
<script src="{{ asset('js/chartJs/4.4.9/chart.js') }}"></script>

{{-- select2 --}}
{{-- install by npm --}}
{{--
<link href="{{ asset('js/select2/4.1.0/select2.min.js') }}" rel="stylesheet" /> --}}

{{-- persianDatepicker --}}
<script src="{{ asset('js/persianDatepicker/persianDatepicker.js') }}"></script>
<script src="{{ asset('js/persianDatepicker/persianDatepicker.blade.js') }}"></script>
