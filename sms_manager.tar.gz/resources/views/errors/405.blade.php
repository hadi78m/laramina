@extends('errors::minimal')

@section('title', __('خطای 405 - متد غیر مجاز'))
@section('code', '405')

@section('message')
<style>
    .shake {
        animation: shake 0.82s cubic-bezier(.36,.07,.19,.97) both;
    }
    @keyframes shake {
        10%, 90% { transform: translateX(-1px); }
        20%, 80% { transform: translateX(2px); }
        30%, 50%, 70% { transform: translateX(-4px); }
        40%, 60% { transform: translateX(4px); }
    }
    .fade-in {
        animation: fadeIn 1s ease-in-out;
    }
    @keyframes fadeIn {
        from { opacity: 0; transform: translateY(10px); }
        to { opacity: 1; transform: translateY(0); }
    }
</style>
    <div class="max-w-lg w-full bg-white rounded-xl shadow-2xl overflow-hidden fade-in">
        <div class="bg-gradient-to-r from-blue-500 to-indigo-600 p-6 text-center">
            <div class="shake inline-block">
                <svg xmlns="http://www.w3.org/2000/svg" class="h-20 w-20 mx-auto text-white" fill="none" viewBox="0 0 24 24"
                    stroke="currentColor">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                        d="M18.364 5.636l-3.536 3.536m0 5.656l3.536 3.536M9.172 9.172L5.636 5.636m3.536 9.192l-3.536 3.536M21 12a9 9 0 11-18 0 9 9 0 0118 0zm-5 0a4 4 0 11-8 0 4 4 0 018 0z" />
                </svg>
            </div>
            <h1 class="text-3xl font-bold text-white mt-4">405 - متد غیر مجاز</h1>
        </div>

        <div class="p-8 text-center">
            <p class="text-gray-700 mb-6">متد درخواستی شما برای این آدرس پشتیبانی نمی‌شود.</p>

            <div class="bg-blue-50 border border-blue-200 text-blue-700 px-4 py-3 rounded mb-6">
                <div class="flex items-center justify-center space-x-2">
                    <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
                        <path fill-rule="evenodd"
                            d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7-4a1 1 0 11-2 0 1 1 0 012 0zM9 9a1 1 0 000 2v3a1 1 0 001 1h1a1 1 0 100-2h-1V9z"
                            clip-rule="evenodd" />
                    </svg>
                    <span>متد مجاز برای این آدرس: <span class="font-bold" id="allowedMethod">GET</span></span>
                </div>
            </div>

            <div class="space-y-4">
                <p class="text-sm text-gray-600">راه‌حل‌های ممکن:</p>
                <ul class="text-sm text-gray-600 text-right space-y-2 list-disc pr-4">
                    <li>بررسی نوع درخواست ارسالی (GET, POST, PUT, DELETE)</li>
                    <li>استفاده از متد صحیح برای این آدرس</li>
                    <li>بررسی مستندات API در صورت استفاده از سرویس‌های وب</li>
                </ul>
            </div>

            <div class="mt-8 flex flex-col space-y-3">
                <a href="/"
                    class="bg-indigo-600 hover:bg-indigo-700 text-white font-medium py-2 px-4 rounded-lg transition duration-200">
                    بازگشت به صفحه اصلی
                </a>
                <a href="javascript:history.back()"
                    class="text-indigo-600 hover:text-indigo-800 font-medium py-2 px-4 rounded-lg transition duration-200">
                    بازگشت به صفحه قبلی
                </a>
            </div>
        </div>

        <div class="bg-gray-50 px-6 py-4 text-center text-gray-500 text-sm">
            <p class="mt-1">آدرس درخواستی: <span id="requestedUrl">/api/v1/users</span></p>
        </div>
    </div>

    <script>
        // Extract info from URL or set defaults
        const urlParams = new URLSearchParams(window.location.search);
        document.getElementById('allowedMethod').textContent = urlParams.get('allowed') || 'GET';
        document.getElementById('requestedUrl').textContent = urlParams.get('url') || window.location.pathname;
    </script>
@endsection
