<script>
    let providersTable;
    const providerJsonUrl = '{{ route('sms.providers.json') }}';
    const providerStoreUrl = '{{ route('sms.providers.store') }}';
    // Note: For edit, delete, etc., it's better to have a base URL.
    // We'll construct them dynamically for now.
    const providersBaseUrl = '{{ url('sms/providers') }}';
   
    function setDefault(id) {

        Swal.fire({
    title: '<div class="text-center">تغییر پیش‌فرض؟</div>',
    html: `<div class="text-center">این پروایدر پیش‌فرض می‌شود</div>`,
    icon: 'question',
    showCancelButton: true,
    confirmButtonText: 'بله',
    cancelButtonText: 'خیر'
}).then(r => {
    if (!r.isConfirmed) return;

    $.ajax({
        url: `${providersBaseUrl}/${id}/set-default`,
        method: 'POST',
        data: {
            _token: $('meta[name="csrf-token"]').attr('content')
        },success: res => res.success ?
                Swal.fire({
                    icon: 'success',
                    html: `<div class="text-right text-sm">
                        <p>${res.message ? `<p><strong>پیام:</strong> ${res.message}</p>` : ''}
                      </div>`
                }) :
                Swal.fire({
                    icon: 'error',
                    title: '<div class="text-center">تغییر پیش‌فرض؟</div>',
                    html: `<div class="text-center text-sm">
                        <p>${res.message ? `<p><strong>پیام:</strong> ${res.message}</p>` : ''}
                      </div>`
                }),
            error: xhr => Swal.fire({
                icon: 'error',
                title: 'خطا',
                html: `<div class="text-center">
                        <p>${xhr.responseJSON?.message ? `<p><strong>پیام:</strong> ${xhr.responseJSON?.message}</p>` : ''}
                      </div>`
                // text: xhr.responseJSON?.message || 'مشکل در ارتباط'
            })
          });

});

    }

    function deleteProvider(id) {
        Swal.fire({
            title: 'حذف؟',
            text: 'قابل بازگشت نیست!',
            icon: 'warning',
            showCancelButton: true,
            confirmButtonText: 'حذف',
            cancelButtonText: 'انصراف',
            confirmButtonColor: '#ef4444'
        })
            .then(r => r.isConfirmed && $.ajax({
                url: `${providersBaseUrl}/${id}`,
                method: 'DELETE',
                data: {
                    _token: $('meta[name="csrf-token"]').attr('content')
                },
                success: res => {
                    providersTable.ajax.reload();
                    showSuccess(res.message);
                }
            }));
    }

    function toggleStatus(id) {
        $.post(`${providersBaseUrl}/${id}/toggle-status`, {
            _token: $('meta[name="csrf-token"]').attr('content')
        }, res => {
            if (res.success) {
                providersTable.ajax.reload();
                showSuccess(res.message);
            } else showError(res.message);
        }).fail(xhr => showError(xhr.responseJSON?.message || 'خطا'));
    }

    /*** تست اتصال**/
    async function testConnection(id) {

        const { value: phone } = await Swal.fire({
            title: 'شماره تلفن را وارد کنید',
            input: 'text',
            inputPlaceholder: 'مثلا 09123456789',
            showCancelButton: true,
            confirmButtonText: 'تست اتصال',
            cancelButtonText: 'انصراف',
            inputValidator: (value) => {
                if (!value) {
                    return 'شماره تلفن الزامی است';
                }
            }
        });

        if (!phone) return;

        Swal.fire({
            title: 'در حال تست...',
            allowOutsideClick: false,
            didOpen: () => Swal.showLoading()
        });

        $.ajax({
            url: `${providersBaseUrl}/${id}/test-connection`,
            method: 'POST',
            data: {
                _token: $('meta[name="csrf-token"]').attr('content'),
                phone: phone
            },
            success: res => res.success ?
                Swal.fire({
                    icon: 'success',
                    title: 'متصل شد!',
                    html: `<div class="text-right text-sm">
                        <p><strong>پروایدر:</strong> ${res.provider}</p>
                        <p><strong>زمان پاسخ:</strong> ${res.response_time}ms</p>
                        ${res.message ? `<p><strong>پیام:</strong> ${res.message}</p>` : ''}
                      </div>`
                }) :
                Swal.fire({
                    icon: 'error',
                    title: 'ناموفق',
                    text: res.message
                }),
            error: xhr => Swal.fire({
                icon: 'error',
                title: 'خطا',
                text: xhr.responseJSON?.message || 'مشکل در ارتباط'
            })
        });
    }

    // / Event Delegation جدید برای دکمه شماره‌ها
    $('#providersTable tbody').on('click', '.action-numbers', function () {
        const row = providersTable.row($(this).closest('tr')).data();
        manageNumbers(row.id);
    });

    function manageNumbers(providerId) {
        $('#current_provider_id').val(providerId);
        loadNumbers(providerId);
        // نمایش مدال + لودینگ
        $('#manageNumbersModal').removeClass('hidden');
        $('#numbersLoading').removeClass('hidden');
        $('#numbersTable').addClass('hidden');           // مخفی کردن جدول تا لود کامل شود
        openNumbersModal();
    }

    function loadNumbers(providerId) {
        $.get(`${providersBaseUrl}/${providerId}/numbers`, res => {
            if (res.success) {
                const tbody = $('#numbersTable tbody');
                tbody.empty();

                if (res.numbers.length === 0) {
                    tbody.append('<tr><td colspan="3" class="text-center py-4 text-gray-500">هیچ شماره‌ای ثبت نشده است</td></tr>');
                } else {
                    res.numbers.forEach(num => {
                        const status = num.is_active
                            ? '<span class="bg-green-100 text-green-800 px-2 py-1 rounded">فعال</span>'
                            : '<span class="bg-red-100 text-red-800 px-2 py-1 rounded">غیرفعال</span>';

                        tbody.append(`
                        <tr>
                            <td class="px-4 py-2">${num.number}</td>
                            <td class="px-4 py-2">${status}</td>
                            <td class="px-4 py-2 flex gap-2">
                                <button class="bg-yellow-500 text-white px-2 py-1 rounded toggle-status" data-id="${num.id}">تغییر وضعیت</button>
                                <button class="bg-red-500 text-white px-2 py-1 rounded delete-number" data-id="${num.id}">حذف</button>
                            </td>
                        </tr>
                    `);
                    });
                }

                // پایان لودینگ → نمایش جدول
                $('#numbersLoading').addClass('hidden');
                $('#numbersTable').removeClass('hidden');
            } else {
                showError('خطا در دریافت شماره‌ها');
                closeNumbersModal(); // یا مدیریت خطا به شکل دیگری
            }
        }).fail(() => {
            showError('خطا در ارتباط با سرور');
            $('#numbersLoading').addClass('hidden');
            closeNumbersModal();
        });
    }

    // هنگام بستن مدال (اختیاری - برای ریست کردن وضعیت)
    function closeNumbersModal() {
        $('#manageNumbersModal').addClass('hidden');
        $('#numbersLoading').addClass('hidden');
        $('#numbersTable').addClass('hidden');
        $('#numbersTable tbody').empty(); // پاک کردن لیست قبلی
    }
    // Submit فرم افزودن شماره
    $('#addNumberForm').on('submit', function (e) {
        e.preventDefault();
        const providerId = $('#current_provider_id').val();
        $.ajax({
            url: `${providersBaseUrl}/${providerId}/numbers`,
            method: 'POST',
            data: $(this).serialize(),
            success: res => {
                if (res.success) {
                    this.reset();
                    loadNumbers(providerId);
                    showSuccess(res.message);
                }
            },
            error: xhr => showError(xhr.responseJSON?.message || 'خطا در ذخیره شماره')
        });
    });

    // Toggle وضعیت
    $('#manageNumbersModal').on('click', '.toggle-status', function () {
        const numberId = $(this).data('id');
        const providerId = $('#current_provider_id').val();
        $.post(`${providersBaseUrl}/${providerId}/numbers/${numberId}/toggle`, { _token: $('meta[name="csrf-token"]').attr('content') }, res => {
            if (res.success) {
                loadNumbers(providerId);
                showSuccess(res.message);
            }
        });
    });

    // حذف شماره
    $('#manageNumbersModal').on('click', '.delete-number', function () {
        const numberId = $(this).data('id');
        const providerId = $('#current_provider_id').val();
        Swal.fire({
            title: 'حذف شماره؟',
            text: 'قابل بازگشت نیست!',
            icon: 'warning',
            showCancelButton: true,
            confirmButtonText: 'حذف',
            cancelButtonText: 'انصراف'
        }).then(r => r.isConfirmed && $.ajax({
            url: `${providersBaseUrl}/${providerId}/numbers/${numberId}`,
            method: 'DELETE',
            data: { _token: $('meta[name="csrf-token"]').attr('content') },
            success: res => {
                loadNumbers(providerId);
                showSuccess(res.message);
            }
        }));
    });

    function openNumbersModal() { $('#manageNumbersModal').removeClass('hidden'); }

    $('#addProviderModal, #editProviderModal').on('click', function (e) {
        if (e.target === this) {
            $(this).addClass('hidden');
        }
    });
    $(document).on('keydown', function (e) {
        if (e.key === 'Escape') {
            closeAddModal();
            closeEditModal();
        }
    });
</script>