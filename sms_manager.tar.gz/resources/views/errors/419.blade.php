@extends('errors::minimal')

@section('title', __('خطای 419 - اعتبار صفحه منقضی شده'))
@section('code', '419')

@section('message')
<style>
    .hourglass {
        animation: flip 4s ease-in-out infinite;
    }
    @keyframes flip {
        0%, 100% { transform: rotate(0deg); }
        50% { transform: rotate(180deg); }
    }
    .fade-in {
        animation: fadeIn 1.5s ease-in-out;
    }
    @keyframes fadeIn {
        from { opacity: 0; }
        to { opacity: 1; }
    }
</style>
<div class="max-w-lg w-full bg-white rounded-xl shadow-2xl overflow-hidden fade-in">
    <div class="bg-gradient-to-r from-pink-500 to-purple-600 p-6 text-center">
        <div class="hourglass inline-block">
            <svg xmlns="http://www.w3.org/2000/svg" class="h-20 w-20 mx-auto text-white" fill="none" viewBox="0 0 24 24"
                stroke="currentColor">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                    d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                    d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
            </svg>
        </div>
        <h1 class="text-3xl font-bold text-white mt-4">419 - اعتبار صفحه منقضی شده</h1>
    </div>

    <div class="p-8 text-center">
        <p class="text-gray-700 mb-6">زمان اعتبار این صفحه به پایان رسیده است.</p>

        <div class="bg-pink-50 border border-pink-200 text-pink-700 px-4 py-3 rounded mb-6">
            <div class="flex items-center justify-center space-x-2">
                <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
                    <path fill-rule="evenodd"
                        d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7-4a1 1 0 11-2 0 1 1 0 012 0zM9 9a1 1 0 000 2v3a1 1 0 001 1h1a1 1 0 100-2h-1V9z"
                        clip-rule="evenodd" />
                </svg>
                <span>لطفاً صفحه را رفرش کرده و مجدداً تلاش کنید</span>
            </div>
        </div>

        <div class="space-y-4">
            <p class="text-sm text-gray-600">علت احتمالی این خطا:</p>
            <ul class="text-sm text-gray-600 text-right space-y-2 list-disc pr-4">
                <li>مدت زمان طولانی عدم فعالیت در صفحه</li>
                <li>ارسال فرم پس از انقضای زمان مجاز</li>
                <li>مشکل در توکن امنیتی صفحه</li>
            </ul>
        </div>

        <div class="mt-8 flex flex-col space-y-3">
            <button onclick="window.location.reload()"
                class="bg-purple-600 hover:bg-purple-700 text-white font-medium py-2 px-4 rounded-lg transition duration-200">
                رفرش صفحه
            </button>
            <a href="/login"
                class="text-purple-600 hover:text-purple-800 font-medium py-2 px-4 rounded-lg transition duration-200">
                ورود مجدد به سیستم
            </a>
            <a 
            {{-- href="/contact" --}}
                class="text-gray-600 hover:text-gray-800 font-medium py-2 px-4 rounded-lg transition duration-200">
                گزارش مشکل
            </a>
        </div>
    </div>
</div>
@endsection
