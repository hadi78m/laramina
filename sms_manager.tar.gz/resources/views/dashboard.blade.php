@extends('layouts.mclsApp')

@section('content')
    <div class="min-h-screen ">
        <style>
            body {
                font-family: 'Vazirmatn', sans-serif
            }

            .card-hover {
                transition: all .3s cubic-bezier(.4, 0, .2, 1)
            }

            .card-hover:hover {
                transform: translateY(-8px) scale(1.02)
            }

            .floating {
                animation: floating 3s ease-in-out infinite
            }

            @keyframes floating {

                0%,
                100% {
                    transform: translateY(0)
                }

                50% {
                    transform: translateY(-10px)
                }
            }
        </style>

        <header class="text-center py-8">
            <h1 class="text-4xl md:text-6xl font-bold text-white floating">
                <span class="bg-gradient-to-r from-pink-400 to-purple-400 bg-clip-text text-transparent">
                    {{ $title }}
                </span>
            </h1>
            <p class="text-gray-600 text-lg mt-2">{{ $subtitle }}</p>
        </header>

        <main class="container mx-auto px-4 py-8 max-w-7xl ">
            <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                @foreach ($services as $card)
                    <a href="{{ route($card['route']) }}"
                        class="card-hover group relative overflow-hidden rounded-3xl shadow-2xl block"
                        style="background:{{ $card['color'] ?? 'linear-gradient(135deg, 667eea 0%, #764ba2 100%)' }};">
                        <div class="p-8 h-64 flex flex-col justify-between text-white">
                            <div>
                                <div
                                    class="w-16 h-16 {{ $card['iconColor'] ?? 'bg-gray-500' }}  rounded-2xl flex items-center justify-center mb-4">
                                    @isset($card['icon'])
                                        {{ svg($card['icon'], ' h-6 w-6') }}
                                    @endisset
                                </div>
                                <h3 class="text-2xl font-bold mb-2">{{ $card['title'] ?? $card['title'] }}</h3>
                                <p class="text-white text-opacity-90">{{ $card['description'] }}</p>
                            </div>
                            <div class="flex justify-between items-center">
                                <span class="font-semibold text-gray-800">ورود به بخش</span>
                                <div class="transform group-hover:translate-x-2 transition-transform">
                                    <x-bi-arrow-left class="w-6 h-6" />
                                </div>
                            </div>
                        </div>
                    </a>
                @endforeach
            </div>
            <!-- کارت ویژه پروفایل -->
            <div class="mt-12 max-w-4xl mx-auto bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900">
                <div class="card-hover group relative overflow-hidden rounded-3xl shadow-2xl cursor-pointer">
                    <div class="glass-effect p-8 flex flex-col md:flex-row items-center justify-between">
                        <div class="flex items-center mb-6 md:mb-0">
                            <img src="{{asset('img/100.jpg')}}" alt="پروفایل"
                                class="w-20 h-20 rounded-full border-4 border-white shadow-lg">
                            <div class="mr-4">
                                <h4 class="text-2xl font-bold text-white">{{ Auth()->user()->name }}</h4>
                                <p class="text-gray-300">مدیر سیستم</p>
                            </div>
                        </div>
                        <div class="flex flex-wrap gap-4">
                            <a href="{{ route('logout') }}">
                                <button
                                    class=" flex justify-center px-6 py-3 bg-gradient-to-r from-pink-500 to-purple-600 text-white rounded-xl hover:from-pink-600 hover:to-purple-700 transition-all duration-300">
                                    <x-bi-box-arrow-left class='h6 w-6' />
                                    خروج از سیستم
                                </button>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </main>

    </div>
@endsection
