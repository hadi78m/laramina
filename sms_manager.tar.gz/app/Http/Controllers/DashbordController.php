<?php

namespace App\Http\Controllers;

use App\Models\Sms\BlockedWord;
use App\Models\Sms\Message;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class DashbordController extends Controller
{
    /**
     * index
     *
     * @return mixed
     */
    public function _index()
    {
        $user = auth()->user();
        // if ($user->hasRole(['Admin','SuperAdmin']) || $user->can('it user')) {

        if ($user->hasAnyRole(['SuperAdmin'])) {
            $services[] =
                [
                    'id' => 9,
                    'title' => 'واسط پیامکی',
                    'description' => 'پنل واسط پیامکی رایتل، مگفا ، 4040',
                    'icon' => 'bi-send-arrow-up',
                    'iconColor' => 'bg-indigo-600',
                    'route' => 'sms.messages.index',
                    'color'    => 'linear-gradient(135deg, #56C3EE 0%, #278ee7 100%)',
                ];
        } else {
            return response()->json('شما دسترسی لازم را ندارید ', 503);
        }

        $title     = 'داشبورد هوشمند';
        $subtitle  = 'مدیریت یکپارچه تمام بخش‌های فناوری اطلاعات';
        return view('dashboard', compact(
            'services',
            'title',
            'subtitle',
        ));
    }

    public function index()
    {
        return view('sms.dashboard');
    }

    public function getDashboardStats(Request $request)
    {
        try {
            // تعداد کل کاربران
            $totalUsers = User::count();

            // تعداد پیام‌های ارسالی
            $totalMessages = Message::count();

            // تعداد پیام‌های مسدود شده
            $blockedMessages = Message::where('status', 'blocked')->count();

            // تعداد کلمات غیرمجاز
            $blockedWordsCount = BlockedWord::where('is_active', true)->count();

            // کاربر با بیشترین ارسال پیامک
            $topSender = Message::select(
                'sms_credential_id',
                DB::raw('COUNT(*) as message_count')
            )
                ->with('credential')
                ->groupBy('sms_credential_id')
                ->orderByDesc('message_count')
                ->first();

            $topSenderData = null;
            if ($topSender && $topSender->credential) {
                $topSenderData = [
                    'name' => $topSender->credential->name,
                    'username' => $topSender->credential->username,
                    'message_count' => $topSender->message_count
                ];
            }

            // آمار هفتگی پیام‌ها
            $weeklyStats = Message::select(
                DB::raw('DATE(created_at) as date'),
                DB::raw('COUNT(*) as total'),
                DB::raw('SUM(CASE WHEN status = "sent" THEN 1 ELSE 0 END) as sent'),
                DB::raw('SUM(CASE WHEN status = "blocked" THEN 1 ELSE 0 END) as blocked')
            )
                ->where('created_at', '>=', now()->subDays(7))
                ->groupBy('date')
                ->orderBy('date')
                ->get();

            return response()->json([
                'success' => true,
                'data' => [
                    'total_users' => $totalUsers,
                    'total_messages' => $totalMessages,
                    'blocked_messages' => $blockedMessages,
                    'blocked_words_count' => $blockedWordsCount,
                    'top_sender' => $topSenderData,
                    'weekly_stats' => $weeklyStats
                ]
            ]);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'خطا در دریافت آمار'
            ], 500);
        }
    }
}
