// petite-vue-ajax.js
const FormHandler = {
    // تنظیمات پیش‌فرض
    config: {
        loadingText: 'در حال ارسال...',
        successDuration: 5000,
        errorDuration: 5000,
        resetForm: true,
        reloadDataTables: true,
        resetEditors: true
    },

    // وضعیت global
    state: {
        isLoading: false,
        originalSubmitText: '',
        currentForm: null
    },

    // مقداردهی اولیه
    init() {
        this.setupGlobalHandlers();
    },

    // تنظیم هندلرهای global
    setupGlobalHandlers() {
        // هندلر برای تمام فرم‌های دارای کلاس vue_form
        document.addEventListener('submit', (e) => {
            if (e.target.classList.contains('vue_form')) {
                e.preventDefault();
                this.handleSubmit(e.target);
            }
        });

        // هندلر برای دکمه بستن پیام‌ها
        document.addEventListener('click', (e) => {
            if (e.target.classList.contains('close_btn')) {
                this.hideMessages();
            }
        });
    },

    // مدیریت ارسال فرم
    async handleSubmit(form) {
        // جلوگیری از ارسال همزمان
        if (this.state.isLoading) return;

        this.state.currentForm = form;
        this.state.isLoading = true;
        
        // ذخیره متن اصلی دکمه
        const submitBtn = form.querySelector('.submit, #submit');
        this.state.originalSubmitText = submitBtn?.textContent || 'ارسال';

        // نمایش حالت loading
        this.setLoadingState(true);

        try {
            const response = await this.sendRequest(form);
            await this.handleResponse(response, form);
        } catch (error) {
            this.handleError(error);
        } finally {
            this.setLoadingState(false);
        }
    },

    // ارسال درخواست AJAX
    async sendRequest(form) {
        const formData = new FormData(form);
        
        const response = await fetch(form.action, {
            method: form.method,
            body: formData,
            headers: {
                'X-Requested-With': 'XMLHttpRequest',
                'X-CSRF-TOKEN': this.getCSRFToken()
            }
        });

        return await response.json();
    },

    // مدیریت پاسخ سرور
    async handleResponse(response, form) {
        // پاک کردن خطاهای قبلی
        this.clearErrors();

        if (response.status === false) {
            await this.handleErrorResponse(response);
        } else {
            await this.handleSuccessResponse(response, form);
        }
    },

    // مدیریت پاسخ خطا
    async handleErrorResponse(response) {
        // نمایش خطاهای فیلدها
        if (response.errors) {
            this.showFieldErrors(response.errors);
        }

        // نمایش پیام خطای عمومی
        if (response.message && !response.errors) {
            this.showSystemError(response.message);
        }

        // ریدایرکت اگر وجود دارد
        if (response.url) {
            window.location.replace(response.url);
        }

        // بستن خودکار پیام‌ها
        setTimeout(() => {
            this.hideMessages();
        }, this.config.errorDuration);
    },

    // مدیریت پاسخ موفق
    async handleSuccessResponse(response, form) {
        // نمایش پیام موفقیت
        this.showSystemSuccess(response.message);

        // ریست فرم
        if (this.config.resetForm) {
            this.resetForm(form);
        }

        // ریلود DataTables
        if (this.config.reloadDataTables) {
            this.reloadDataTables();
        }

        // ریست ادیتورها
        if (this.config.resetEditors) {
            this.resetEditors();
        }
    },

    // مدیریت خطاهای سیستمی
    handleError(error) {
        console.error('Ajax Error:', error);
        this.showSystemError('خطا در ارتباط با سرور');
        this.setLoadingState(false);
    },

    // نمایش خطاهای فیلدها
    showFieldErrors(errors) {
        Object.entries(errors).forEach(([field, messages]) => {
            const errorElement = document.querySelector(`[data-error="${field}"]`) || 
                               document.querySelector(`.error-${field}`);
            
            if (errorElement) {
                errorElement.textContent = messages[0];
                errorElement.style.display = 'block';
            }
        });
    },

    // پاک کردن تمام خطاها
    clearErrors() {
        document.querySelectorAll('[data-error], .error-text').forEach(element => {
            element.textContent = '';
            element.style.display = 'none';
        });
    },

    // نمایش پیام خطا
    showSystemError(title = '', message) {
        this.showMessage('error', title, message, this.config.errorDuration);
    },

    // نمایش پیام موفقیت
    showSystemSuccess(title = '', message) {
        this.showMessage('success', title, message, this.config.successDuration);
    },

    // نمایش پیام
    showMessage(type, title, message, duration) {
        // ایجاد یا استفاده از المان موجود
        let messageElement = document.getElementById('system-message');
        
        if (!messageElement) {
            messageElement = document.createElement('div');
            messageElement.id = 'system-message';
            messageElement.innerHTML = `
                <div class="message-content">
                    <span class="message-title"></span>
                    <span class="message-text"></span>
                    <button class="close-btn" onclick="this.parentElement.parentElement.remove()">×</button>
                </div>
            `;
            document.body.appendChild(messageElement);
        }

        // تنظیم استایل بر اساس نوع
        const styles = {
            success: {
                background: '#d4edda',
                color: '#155724',
                border: '1px solid #c3e6cb'
            },
            error: {
                background: '#f8d7da',
                color: '#721c24',
                border: '1px solid #f5c6cb'
            }
        };

        Object.assign(messageElement.style, {
            position: 'fixed',
            top: '20px',
            right: '20px',
            padding: '15px',
            borderRadius: '5px',
            zIndex: '10000',
            minWidth: '300px',
            boxShadow: '0 4px 6px rgba(0,0,0,0.1)',
            ...styles[type]
        });

        // تنظیم محتوا
        messageElement.querySelector('.message-title').textContent = title;
        messageElement.querySelector('.message-text').textContent = message;

        // نمایش المان
        messageElement.style.display = 'block';

        // بستن خودکار
        if (duration > 0) {
            setTimeout(() => {
                messageElement.remove();
            }, duration);
        }
    },

    // مخفی کردن پیام‌ها
    hideMessages() {
        const messageElement = document.getElementById('system-message');
        if (messageElement) {
            messageElement.remove();
        }
    },

    // تنظیم حالت loading
    setLoadingState(isLoading) {
        this.state.isLoading = isLoading;
        
        const submitBtn = this.state.currentForm?.querySelector('.submit, #submit');
        if (submitBtn) {
            if (isLoading) {
                submitBtn.textContent = this.config.loadingText;
                submitBtn.disabled = true;
            } else {
                submitBtn.textContent = this.state.originalSubmitText;
                submitBtn.disabled = false;
            }
        }
    },

    // ریست فرم
    resetForm(form) {
        form.reset();
        
        // ریست select2 اگر وجود دارد
        const selects = form.querySelectorAll('select');
        selects.forEach(select => {
            if (select.hasAttribute('data-select2')) {
                $(select).val('').trigger('change');
            }
        });
    },

    // ریلود DataTables
    reloadDataTables() {
        if (typeof $ !== 'undefined' && $.fn.DataTable) {
            $('body #table, body .table').DataTable().ajax.reload();
        }
    },

    // ریست ادیتورها
    resetEditors() {
        setTimeout(() => {
            if (typeof editor !== 'undefined') editor.setData("");
            if (typeof editor1 !== 'undefined') editor1.setData("");
            if (typeof editorid !== 'undefined') editorid.setData("");
            
            // پریویو تصاویر
            const previewContainer = document.getElementById('preview-container');
            if (previewContainer) previewContainer.innerHTML = '';
        }, 1000);
    },

    // دریافت توکن CSRF
    getCSRFToken() {
        return document.querySelector('meta[name="csrf-token"]')?.getAttribute('content') || 
               document.querySelector('input[name="_token"]')?.value;
    }
};

// مقداردهی اولیه هنگام لود صفحه
document.addEventListener('DOMContentLoaded', () => {
    FormHandler.init();
});

// در دسترس قرار دادن global
window.FormHandler = FormHandler;