<?php
return [

    // sms 
    'sms' => [
        'sms' => 'پیامک',
        '' => '',
        'provider' => 'پروایدر',
        'providers' => 'پروایدرها',
    ],
    // socials
    'social' => [
        'social' => 'پیام رسان',
        'socials' => 'پیام رسان ها',
    ],

    // A

    'account' => 'اکانت',
    'accounts' => 'اکانت ها',


    // B


    // C



    // D
    'dashboard' => 'داشبورد',


    // E


    // F
    'filter' => 'فیلتر',
    'first-page' => 'صفحه اول',

    // G
    'gradient'=>'ترکیب رنگ ها',

    // H


    // I

    'icons'=>'آیکن ها',


    // J


    // K


    // L
    'login_title' => 'ورود به سامانه اعلان ها',
    'login_to_account' => 'ورود به حساب کاربری',


    // M


    // N


    // O


    /* P */
    'postCode' => 'کدپستی',
    'panel' => 'پنل',
    'phone' => 'تلفن',
    'part' => 'چکیده',
    'project' => 'پروژه',
    'postal_email' => 'پست الکترونیک',
    'password' => 'رمز عبور',
    'payment' => 'پرداخت',
    'permissions' => 'دسترسی ها',



    // Q



    // R
    'roles' => 'نقش ها',


    // S


    // T


    /* U */
    'users' => 'کاربران',
    'university' => 'دانشگاه',
    'update' => 'به روز رسانی',
    'unitCount' => 'تعداد واحد',


    // V


    // W 
    'words' => 'کلمات',
    'word' => 'کلمه',
    'workTable' => 'میزکار',

    // X


    // Y


    // Z 




    'connect_me' => 'Connect',
    'number' => 'شماره',
    'home' => 'خانه',
    'manage' => 'مدیریت',
    'manager' => 'مدیر',
    'sharing' => 'اشتراک',
    'required' => 'ضرورت',
    'chat' => 'گفت و گوها',
    'and' => 'و',
    'inquiry' => 'استعلام',
    'moshtarak' => 'مشترک',
    'contact' => 'تماس با ما',
    'address' => 'آدرس',
    'target' => 'محل نمایش',
    'aboutme' => 'درباره ما',
    'about' => 'درباره',
    'last' => 'آخرین',
    'captcha' => 'کد امنیتی',
    'edit' => 'ویرایش',
    'read' => 'مطالعه',
    'credentials' => 'مدارک تحصیلی',
    'logout' => 'خروج',
    'from' => 'از',
    'service_description' => 'شرح خدمات',
    'for' => 'برای',
    'able' => 'قابل',
    'toString' => 'به حروف',
    'reading' => 'مطالعه',
    'cancle' => 'انصراف',
    'delete' => 'حذف',
    'show' => 'نمایش',
    'other' => 'سایر',
    'offer' => 'پیشنهاد',
    'id' => 'شناسه',
    'save' => 'ذخیره',
    'subject' => 'موضوع',
    'search' => 'جستجو',
    'Based_on' => 'براساس',
    'bill' => 'قبض',
    'bills' => 'قبض ها',
    'requests' => 'درخواست ها',
    'link' => 'لینک',
    'add' => 'افزودن',
    'cycle' => 'دوره',
    'amount' => 'مبلغ',
    'year' => 'سال',
    'download' => 'دانلود',
    'list' => 'لیست',
    'message' => 'متن',
    'title' => 'سامانه مدیریت اعلان های',
    'caption' => 'عنوان',
    'back' => 'برگشت',
    'login' => 'ورود',
    'email_address' => 'آدرس ایمیل',
    'email' => 'ایمیل',

    'editor' => 'ادیتور',
    'slider' => 'اسلایدر',
    'category' => 'دسته بندی',
    'name' => 'نام',
    'family' => 'نام خانوادگی',
    'leveldegree_title' => 'مقطع',
    'level_title' => 'مدرک تحصیلی',
    'field_title' => 'رشته',
    'status' => 'وضعیت',
    'nationalCode' => 'کدملی',
    'deadline' => 'مهلت',

    'date' => 'تاریخ',


    'Thank you for your payment' => 'با تشکر از پرداخت تان',
    'economic_code' => 'کد اقتصادی',

    'movingAmount' => 'بدهی / بستانکاری',
    'levyDutyValue' => 'مالیات بر ارزش افزوده و عوارش شهرداری',
    'capacity' => 'ظرفیت',
    'online_support' => 'پشتیبانی آنلاین',

];
