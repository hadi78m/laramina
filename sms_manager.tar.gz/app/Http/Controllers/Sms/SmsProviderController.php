<?php
// app/Http/Controllers/Sms/SmsProviderController.php

namespace App\Http\Controllers\Sms;

use App\Http\Controllers\Controller;
use App\Models\Sms\Provider;
use App\Models\Sms\ProviderNumber;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Crypt;
use Illuminate\Support\Str;

class SmsProviderController extends Controller
{
    public function index()
    {

        // return view('sms.providers.providers-index');
        return view('sms.providers.index');
    }



    public function json(Request $request)
    {
        $providers =  Provider::adminTable($request, [
            'search' => ['name', 'url'],
            'filters' => ['is_active', 'is_default'],
        ]);

        return $providers;
    }



    public function store(Request $request)
    {
        $request->validate([
            'name' => 'required|string|max:255|unique:providers,name',
            'user' => 'nullable|string|max:255',
            'password' => 'nullable|string|min:4',
            'url' => 'nullable|url',
            'helper_name' => 'nullable|string|regex:/^[a-zA-Z]+$/',
            'rate_unit' => 'required|in:per_second,per_minute,per_hour,unlimited',
            'send_rate' => 'required_unless:rate_unit,unlimited|nullable|integer', // اگر unlimited باشه، send_rate لازم نیست
        ], [
            'url.url' => 'فرمت آدرس url نادرست',
            'rate_unit.required' => 'نرخ ارسال الزامی است.',
            'name.required' => 'نام الزامی است.',
            'name.unique' => 'نام قبلاً استفاده شده است.',
            'user.max' => 'حداکثر 255 کلمه قابل قبول است',
            'password.min' => 'رمز عبور باید حداقل ۴ کاراکتر باشد ',
            'helper_name.regex' => 'فقط از کلمات انگلیسی استفاده کنید مانند NewHelper',
            'send_rate.required_unless' => 'نرخ ارسال الزامی است',
            // 'send_rate.min' => 'نرخ ارسال باید حداقل 1',
        ]);

        // بزرگ کردن اولین کلمه نام هلپر
        $helper_name = $request->helper_name ? $formattedValue = Str::ucfirst($request->helper_name) : '';



        $data = $request->only(['name', 'user', 'url', 'token']);
        $data['created_by'] = Auth::id();
        $data['send_rate'] = $request->rate_unit !== 'unlimited' ? $request->send_rate : 0;
        $data['rate_unit'] = $request->rate_unit;
        $data['is_default'] = $request->is_default ? true : false;
        $data['is_active'] = $request->is_active ? true : false;

        // بررسی داشتن کلمه هلپر یا اضافه کردن آن 
        if ($request->helper_name && !Str::endsWith(strtolower($helper_name), 'helper')) {
            $helper_name = $helper_name . "Helper";
            $data['helper_name'] = $helper_name;
        }


        // جلوگیری از پیش فرض کردن پروایدری که هلپر ندارد
        if ($helper_name == '' && $request->is_default) {
            return response()->json(['success' => false, 'message' => 'پروایدری که هلپر نداشته باشد نمی تواند  پیش‌فرض باشد.'], 400);
        }

        if ($request->filled('password')) {
            $data['password'] = Crypt::encrypt($request->password);
        }

        $provider = Provider::create($data);

        if ($request->has('is_default')) {
            Provider::setAsDefault($provider->id);
        }


        return response()->json([
            'success' => true,
            'message' => 'پروایدر با موفقیت اضافه شد.',
        ]);
    }

    /**
     * edit
     *
     * @param  mixed $id
     * 
     */
    public function edit($id)
    {
        $provider = Provider::findOrFail($id);

        // decrypt پسورد برای نمایش در فرم
        if ($provider->password) {
            $provider->password = Crypt::decrypt($provider->password);
        }

        return response()->json([
            'success' => true,
            'provider' => $provider
        ]);
    }
    public function update(Request $request, $id)
    {

        $provider = Provider::findOrFail($id);

        $request->validate([
            'name' => 'required|string|max:255|unique:providers,name,' . $id,
            'user' => 'nullable|string|max:255',
            'password' => 'nullable|string|min:4',
            'url' => 'nullable|url',
            'helper_name' => 'nullable|string|regex:/^[a-zA-Z]+$/',
            'rate_unit' => 'required|in:per_second,per_minute,per_hour,unlimited',
            'send_rate' => 'required_unless:rate_unit,unlimited|nullable|integer', // اگر unlimited باشه، send_rate لازم نیست
        ], [
            'url.url' => 'فرمت آدرس url نادرست',
            'rate_unit.required' => 'نرخ ارسال الزامی است.',
            'name.required' => 'نام الزامی است.',
            'name.unique' => 'نام قبلاً استفاده شده است.',
            'user.max' => 'حداکثر 255 کلمه قابل قبول است',
            'password.min' => 'رمز عبور باید حداقل ۴ کاراکتر باشد ',
            'helper_name.regex' => 'فقط از کلمات انگلیسی استفاده کنید و در انتهاHelper قرار دهید',
            'send_rate.required_unless' => 'نرخ ارسال الزامی است',
            // 'send_rate.min' => 'نرخ ارسال باید حداقل 1',
        ]);

        // بزرگ کردن اولین کلمه نام هلپر
        $helper_name = $request->helper_name ? $formattedValue = Str::ucfirst($request->helper_name) : '';

        $data = $request->only(['name', 'user', 'url', 'token']);
        $data['send_rate'] = $request->rate_unit !== 'unlimited' ? $request->send_rate : 0;
        $data['rate_unit'] = $request->rate_unit;
        $data['is_default'] = $request->is_default ? true : false;
        // بررسی داشتن کلمه هلپر یا اضافه کردن آن 
        if ($request->helper_name && !Str::endsWith(strtolower($helper_name), 'helper')) {
            $helper_name = $helper_name . "Helper";
            $data['helper_name'] = $helper_name;
        }


        if ($request->filled('password')) {
            $data['password'] = Crypt::encrypt($request->password);
        }

        // جلوگیری از پیش فرض کردن پروایدری که هلپر نداشته باشد
        if (!$provider->helper_name  && $helper_name == '' &&  $request->is_default) {
            return response()->json(['success' => false, 'message' => 'پروایدری که هلپر نداشته باشد نمی تواند  پیش‌فرض باشد.'], 400);
        }

        $provider->update($data);

        // اصلاح مهم: حفظ وضعیت قبلی اگر چک‌باکس ارسال نشده باشد
        $provider->is_active = $request->has('is_active');

        // جلوگیری از غیرفعال کردن پیش‌فرض
        if (!$provider->is_active && $provider->is_default) {
            return response()->json(['success' => false, 'message' => 'پروایدر پیش‌فرض را نمی‌توان غیرفعال باشد.'], 400);
        }

        $provider->save();

        if ($request->has('is_default') && $provider->is_active) {
            Provider::setAsDefault($provider->id);
        }

        return response()->json(['success' => true, 'message' => 'پروایدر با موفقیت به‌روزرسانی شد.']);
    }

    /**
     * createHelper
     * ایجاد هلپر
     * @param  mixed $request
     * @param  mixed $id
     */
    public function createHelper(Request $request, $id)
    {

        $provider = Provider::findOrFail($id);

        $request->validate([
            'helper_name' => 'required|string|regex:/^[a-zA-Z]+$/',
        ], [
            'helper_name.required' => 'نام هلپر الزامی است.',
            'helper_name.string' => 'نام هلپر یاید حروف باشد.',
            'helper_name.regex' => 'فقط از کلمات انگلیسی استفاده کنید و در انتهاHelper قرار دهید',

        ]);

        try {
            // بزرگ کردن اولین کلمه نام هلپر
            $helper_name = $request->helper_name ? Str::ucfirst($request->helper_name) : '';


            // بررسی داشتن کلمه هلپر یا اضافه کردن آن 
            if ($request->helper_name && !Str::endsWith(strtolower($helper_name), 'helper')) {
                $helper_name = $helper_name . "Helper";
            }
            $data['helper_name'] = $helper_name;

            if ($data) {

                $provider->update($data);

                $provider->save();


                return response()->json(['success' => true, 'message' => 'پروایدر با موفقیت به‌روزرسانی شد.']);
            } else {
                return response()->json(['success' => false, 'message' => 'خطا در بروزرسانی.']);
            }
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => $e->getMessage()
            ], 400);
        }
    }
    public function destroy($id)
    {
        $provider = Provider::findOrFail($id);

        if ($provider->is_default) {
            return response()->json([
                'success' => false,
                'message' => 'پروایدر پیش‌فرض قابل حذف نیست. ابتدا پروایدر دیگری را پیش‌فرض کنید.'
            ], 400);
        }

        $provider->delete();

        // اگر بعد از حذف هیچ پیش‌فرضی نبود، اولین فعال رو پیش‌فرض کن
        if (!Provider::where('is_default', true)->exists()) {
            Provider::where('is_active', true)->first()?->update(['is_default' => true]);
        }

        return response()->json([
            'success' => true,
            'message' => 'پروایدر با موفقیت حذف شد.'
        ]);
    }

    public function setDefault($id)
    {

        $provider = Provider::find($id);
        try {
            if (!$provider->helper_name) {
                return response()->json([
                    'success' => false,
                    'message' => "پروایدر «{$provider->name}» به دلیل نداشتن هلپر نمی تواند پیش فرض باشد",
                    // 'is_default' => $provider->is_default,
                ], 400);
            } else {
                $data =    $provider->setAsDefault($id);
                return response()->json([
                    'success' => true,
                    'message' => "پروایدر «{$provider->name}» به عنوان پیش‌فرض تنظیم شد.",
                    // 'is_default' => $data,
                    'update' => $data ? 'table' : null,
                ]);
            }
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => $e->getMessage()
            ], 400);
        }
    }

    // تغییر وضعیت فعال/غیرفعال
    public function toggleStatus($id)
    {
        $provider = Provider::findOrFail($id);

        try {
            $provider->toggleStatus();
            return response()->json([
                'success' => true,
                'message' => $provider->is_active ? 'پروایدر فعال شد.' : 'پروایدر غیرفعال شد.',
                'is_active' => $provider->is_active,
            ], 200);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => $e->getMessage()
            ], 400);
        }
    }
    /**
     * Summary of testConnection
     * تست اتصال به پروایدرها
     * @param mixed $id
     * @return \Illuminate\Http\JsonResponse
     */
    public function testConnection(Request $request, $id)
    {

        $provider = Provider::findOrFail($id);


        if (!$provider->url) {
            return response()->json([
                'success' => false,
                'message' => 'آدرس API تنظیم نشده است.'
            ], 400);
        }
        if (!$provider->helper_name) {
            return response()->json([
                'success' => false,
                'message' => 'هلپری برای این پرووایدر تعریف نشده است'
            ], 400);
        }

        if (!$provider->is_active) {
            return response()->json([
                'success' => false,
                'message' => 'این پروایدر غیرفعال است.'
            ], 400);
        }

        $start = microtime(true);

        try {

            // پیدا کردن هلپر 

            $helper = $provider->helper_name;
            $helper = "\App\Helpers\\$helper";


            // ارسال otp به هلپر پرووایدر  و دریافت نتیجه
            $response = $helper::send($request->phone, rand(1000, 9000), $provider, $isOtp = true);

            $time = round((microtime(true) - $start) * 1000, 2);


            if ($response['status'] === 'success') {
                return response()->json([
                    'success'    => $response['status'] === 'success',
                    'provider' => $provider->name,
                    'response_time' => $time,
                    'message' => $response['description'],
                ]);
            } else {
                return response()->json([
                    'success' => false,
                    'message' => $response['status'] === 'error' ? $response['description'] : null,
                ], 400);
            }
        } catch (\GuzzleHttp\Exception\ConnectException $e) {
            return response()->json([
                'success' => false,
                'message' => 'عدم اتصال به سرور پروایدر. آدرس یا پورت اشتباه است.'
            ], 400);
        } catch (\GuzzleHttp\Exception\RequestException $e) {
            return response()->json([
                'success' => false,
                'message' => 'خطا در درخواست: ' . $e->getMessage()
            ], 400);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'خطای غیرمنتظره: ' . $e->getMessage()
            ], 400);
        }
    }

    /**
     * extractMessageFromResponse
     * کمک برای استخراج پیام از پاسخ JSON    
     * تست اتصال از طریق API
     * @param  mixed $body
     * @return mixed
     */
    private function extractMessageFromResponse($body)
    {
        if (empty($body))
            return null;

        $data = json_decode($body, true);
        if (json_last_error() !== JSON_ERROR_NONE)
            return null;

        // پیام‌های رایج در پنل‌های ایرانی
        return $data['message'] ?? $data['msg'] ?? $data['text'] ?? $data['status'] ?? null;
    }



    // متد جدید: لیست شماره‌های یک پروایدر
    public function numbers($providerId)
    {
        $numbers = ProviderNumber::where('provider_id', $providerId)->get();
        return response()->json(['success' => true, 'data' => $numbers]);
    }

    // متد جدید: ذخیره شماره جدید
    public function storeNumber(Request $request, $providerId)
    {
        $request->validate([
            'number' => 'required|string|max:255|unique:provider_numbers,number,NULL,id,provider_id,' . $providerId,
        ]);

        $number = ProviderNumber::create([
            'provider_id' => $providerId,
            'number' => $request->number,
            'is_active' => true,
        ]);

        return response()->json(['success' => true, 'message' => 'شماره با موفقیت اضافه شد.']);
    }

    // متد جدید: بروزرسانی وضعیت فعال/غیرفعال
    public function toggleNumberStatus($providerId, $numberId)
    {
        $number = ProviderNumber::where('provider_id', $providerId)->findOrFail($numberId);
        $number->is_active = !$number->is_active;
        $number->save();

        return response()->json(['success' => true, 'active' => true, 'message' => $number->is_active ? 'شماره فعال شد.' : 'شماره غیرفعال شد.']);
    }

    // متد جدید: حذف شماره
    public function destroyNumber($providerId, $numberId)
    {
        $number = ProviderNumber::where('provider_id', $providerId)->findOrFail($numberId);
        $number->delete();

        return response()->json(['success' => true, 'message' => 'شماره با موفقیت حذف شد.']);
    }
}
