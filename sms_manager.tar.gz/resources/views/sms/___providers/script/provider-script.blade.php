<script>

    (function () {
        window.ProviderSchema = {
            entity: "providers",
            container: "#providersModule",
            title: "مدیریت سرویس‌دهندگان پیامک",
            routes: {
                base: "/sms/providers",
                json: "/sms/providers/json"
            },

            search: true,
            pagination: true,

            fields: [
                { name: "name", label: "نام", type: "text", required: true },
                { name: "helper_name", label: "Helper", type: "text" },
                {
                    name: "gateway_id", label: "Gateway", type: "relation",
                    relation: {
                        url: "/sms/gateways/json",
                        value: "id",
                        label: "name"
                    }
                },
                { name: "send_rate", label: "نرخ ارسال", type: "number" },
                {
                    name: "is_active",
                    label: "فعال",
                    type: "toggle"
                }
            ],

            actions: {
                add: true,
                edit: true,
                delete: true
            },

            hooks: {
                beforeSubmit(data) {
                    console.log("before submit", data)
                },
                onSuccess() {
                    console.log("saved")
                }
            }
        }
    })();

</script>