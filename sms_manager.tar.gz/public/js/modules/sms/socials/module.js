import tableConfig from './table.js'

export default {
    name: 'sms.socials',

    table: tableConfig,

    init() {
        console.log('sms.socials module loaded')
    }
}