    <script>
        let wordsTable;

        $(document).ready(function() {
            // Initialize DataTable
            wordsTable = $('#wordsTable').DataTable({
                processing: true,
                "dom": 'Blfrtip', // نمایش دکمه‌ها
                "buttons": [{
                        extend: 'copy',
                        text: 'کپی',
                        className: 'bg-gray-500 hover:bg-gray-600 text-white px-4 py-2 rounded-lg text-sm font-medium transition-colors duration-200'
                    },
                    {
                        extend: 'excel',
                        text: 'اکسل',
                        className: 'bg-green-500 hover:bg-green-600 text-white px-4 py-2 rounded-lg text-sm font-medium transition-colors duration-200'
                    },
                    {
                        extend: 'pdf',
                        text: 'PDF',
                        className: 'bg-red-500 hover:bg-red-600 text-white px-4 py-2 rounded-lg text-sm font-medium transition-colors duration-200'
                    },
                    {
                        extend: 'print',
                        text: 'چاپ',
                        className: 'bg-blue-500 hover:bg-blue-600 text-white px-4 py-2 rounded-lg text-sm font-medium transition-colors duration-200'
                    }
                ],
                ajax: {
                    url: "{{ route('sms.blocked-words.json') }}",
                    dataSrc: 'data'
                },
                columns: [
                    // {
                    //     data: 'id'
                    // },
                    {
                        data: 'word',
                        render: function(data) {
                            return `<div class="text-center font-bold text-red-600 text-lg">${data}</div>`;
                        }
                    },
                    {
                        data: 'description',
                        render: function(data) {
                            if(data) {
                            return `<div class="text-center">${data}</div>`;
                            }
                             return '<div class="text-center text-gray-400 italic">بدون توضیحات</div>';
                        }
                    },
                    {
                        data: 'is_active',
                        render: function(data) {
                            if (data) {
                                return '<div class="text-center px-3 py-1 bg-green-100 text-green-800 text-xs font-semibold rounded-full">فعال</div>';
                            }
                            return '<div class="text-center px-3 py-1 bg-gray-100 text-gray-800 text-xs font-semibold rounded-full">غیرفعال</div>';
                        }
                    },
                    {
                        data: 'created_by',
                             render: function(data) {
                            if (data) {
                                return `<div dir="ltr" class="text-center">${data}</div>`;
                            }
                        }
                    },
                    {
                        data: 'created_at',
                         render: function(data) {
                            if (data) {
                                return `<div dir="ltr" class="text-center">${data}</div>`;
                            }
                        }
                    },
                    {
                        data: null,
                        render: function(data) {
                            const statusBtn = data.is_active ?
                                `<button onclick="toggleStatus(${data.id})" class="px-3 py-1 bg-orange-500 text-white rounded hover:bg-orange-600 transition-colors" title="غیرفعال کردن">
                                <i class="fas fa-ban"></i>
                               </button>` :
                                `<button onclick="toggleStatus(${data.id})" class="px-3 py-1 bg-green-500 text-white rounded hover:bg-green-600 transition-colors" title="فعال کردن">
                                <i class="fas fa-check"></i>
                               </button>`;

                            return `
                            <div class="text-center gap-1">
                                <button onclick="editWord(${data.id})" class="px-3 py-1 bg-blue-500 text-white rounded hover:bg-blue-600 transition-colors" title="ویرایش">
                                    <i class="fas fa-edit"></i>
                                </button>
                                ${statusBtn}
                                <button onclick="deleteWord(${data.id})" class="px-3 py-1 bg-red-500 text-white rounded hover:bg-red-600 transition-colors" title="حذف">
                                    <i class="fas fa-trash"></i>
                                </button>
                            </div>
                        `;
                        }
                    }
                ],
                order: [
                    [0, 'desc']
                ],
                language: {
                    "url": "{{ asset('assets/lang/datatables/fa.json') }}"
                }
            });
            // Check Text Form
            $('#checkTextForm').on('submit', function(e) {
                e.preventDefault();

                const text = $(this).find('textarea[name="text"]').val();

                $.ajax({
                    url: '{{ route('sms.blocked-words.check-text') }}',
                    method: 'POST',
                    data: {
                        text: text
                    },
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    },
                    success: function(response) {
                        if (response.success) {
                            const result = response.data;
                            const resultDiv = $('#checkResult');

                            if (result.has_blocked_words) {
                                const words = result.blocked_words.join('، ');
                                resultDiv.html(`
                                <div class="bg-red-50 border-2 border-red-200 rounded-lg p-4">
                                    <div class="flex items-start gap-3">
                                        <div class="bg-red-600 text-white w-10 h-10 rounded-full flex items-center justify-center flex-shrink-0">
                                            <i class="fas fa-exclamation-triangle"></i>
                                        </div>
                                        <div class="flex-1">
                                            <h6 class="font-bold text-red-900 mb-2">متن حاوی کلمات غیرمجاز است!</h6>
                                            <p class="text-red-800"><strong>کلمات یافت شده:</strong> <span class="font-bold">${words}</span></p>
                                        </div>
                                    </div>
                                </div>
                            `);
                            } else {
                                resultDiv.html(`
                                <div class="bg-green-50 border-2 border-green-200 rounded-lg p-4">
                                    <div class="flex items-center gap-3">
                                        <div class="bg-green-600 text-white w-10 h-10 rounded-full flex items-center justify-center">
                                            <i class="fas fa-check-circle"></i>
                                        </div>
                                        <p class="font-bold text-green-900">متن مشکلی ندارد و آماده ارسال است</p>
                                    </div>
                                </div>
                            `);
                            }

                            resultDiv.removeClass('hidden');
                        }
                    }
                });
            });

            // Add Word Form
            $('#addWordForm').on('submit', function(e) {
                e.preventDefault();

                const formData = $(this).serialize();

                $.ajax({
                    url: '{{ route('sms.blocked-words.store') }}',
                    method: 'POST',
                    data: formData,
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    },
                    success: function(response) {
                        if (response.success) {
                            closeAddModal();
                            $('#addWordForm')[0].reset();
                            wordsTable.ajax.reload();

                            showSuccess(response.message);

                        }
                    },
                    error: function(xhr) {
                        const response = xhr.responseJSON;
                        showError(response.message || 'خطایی رخ داده است');

                    }
                });
            });

            // Edit Word Form
            $('#editWordForm').on('submit', function(e) {
                e.preventDefault();

                const wordId = $('#edit_word_id').val();
                const formData = $(this).serialize();

                $.ajax({
                    url: `/sms/blocked-words/${wordId}`,
                    method: 'PUT',
                    data: formData,
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    },
                    success: function(response) {
                        if (response.success) {
                            closeEditModal();
                            wordsTable.ajax.reload();
                            showSuccess(response.message);

                        }
                    },
                    error: function(xhr) {
                        const response = xhr.responseJSON;
                        showError(response.message || 'خطایی رخ داده است');

                    }
                });
            });
        });

        function openAddModal() {
            document.getElementById('addWordModal').classList.remove('hidden');
        }

        function closeAddModal() {
            document.getElementById('addWordModal').classList.add('hidden');
            $('#addWordForm')[0].reset();
        }

        function openEditModal() {
            document.getElementById('editWordModal').classList.remove('hidden');
        }

        function closeEditModal() {
            document.getElementById('editWordModal').classList.add('hidden');
            $('#editWordForm')[0].reset();
        }

        function editWord(id) {
            $.ajax({
                url: '{{ route('sms.blocked-words.json') }}',
                method: 'GET',
                success: function(response) {
                    const word = response.data.find(w => w.id === id);
                    if (word) {
                        $('#edit_word_id').val(word.id);
                        $('#edit_word').val(word.word);
                        $('#edit_description').val(word.description);
                        $('#edit_is_active').val(word.is_active ? '1' : '0');
                        openEditModal();
                    }
                }
            });
        }

        function toggleStatus(id) {
            $.ajax({
                url: `/sms/blocked-words/${id}/toggle-status`,
                method: 'POST',
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                },
                success: function(response) {
                    if (response.success) {
                        wordsTable.ajax.reload();

                        showSuccess(response.message);

                    }
                }
            });
        }

        function deleteWord(id) {
            Swal.fire({
                title: 'اطمینان دارید؟',
                text: 'این کلمه از لیست حذف خواهد شد',
                icon: 'warning',
                showCancelButton: true,
                confirmButtonText: 'بله، حذف کن',
                cancelButtonText: 'انصراف',
                confirmButtonColor: '#ef4444'
            }).then((result) => {
                if (result.isConfirmed) {
                    $.ajax({
                        url: `/sms/blocked-words/${id}`,
                        method: 'DELETE',
                        headers: {
                            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                        },
                        success: function(response) {
                            if (response.success) {
                                wordsTable.ajax.reload();
                                showSuccess(response.message);

                            }
                        }
                    });
                }
            });
        }

        // Close modals on ESC
        document.addEventListener('keydown', function(e) {
            if (e.key === 'Escape') {
                closeAddModal();
                closeEditModal();
            }
        });

        // Close modals on backdrop click
        document.getElementById('addWordModal').addEventListener('click', function(e) {
            if (e.target === this) closeAddModal();
        });

        document.getElementById('editWordModal').addEventListener('click', function(e) {
            if (e.target === this) closeEditModal();
        });
    </script>