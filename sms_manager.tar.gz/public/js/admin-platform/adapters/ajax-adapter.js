export default{
 post(url,data){
  if(window.AppAlert?.post) return AppAlert.post(url,data)
  return fetch(url,{method:'POST',body:data}).then(r=>r.json())
 },
 get(url,data){
  if(window.AppAlert?.post) return AppAlert.post(url,data)
  return fetch(url,{method:'GET',body:data}).then(r=>r.json())
 },
 delete(url){
  if(window.AppAlert?.delete) return AppAlert.delete(url)
  return fetch(url,{method:'DELETE'}).then(r=>r.json())
 }
}