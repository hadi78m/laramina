<?php

namespace App\Models;

use App\AdminPlatform\Traits\AdminTableTrait;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Role extends Model
{
    use HasFactory;
    use AdminTableTrait;

    /**
     * The attributes that are mass assignable.
     *
     * @var array<int, string>
     */
    protected $fillable = [
        'name',
        'guard_name',
    ];

    /**
     * رابطه چند به چند با کاربران
     *
     * @return \Illuminate\Database\Eloquent\Relations\BelongsToMany
     */
    public function users()
    {
        return $this->belongsToMany(User::class, 'model_has_roles');
    }

    /**
     * رابطه چند به چند با مجوزها
     *
     * @return \Illuminate\Database\Eloquent\Relations\BelongsToMany
     */
    public function permissions()
    {
        return $this->belongsToMany(Permission::class, 'role_has_permissions');
    }

    /**
     * بررسی اینکه آیا نقش دارای مجوز مشخصی است یا خیر
     *
     * @param string|array $permissions
     * @return bool
     */
    public function hasPermission($permissions)
    {
        if (is_string($permissions)) {
            return $this->permissions->contains('name', $permissions);
        }

        return (bool) $this->permissions->whereIn('name', (array) $permissions)->count();
    }

    public static function adminTransform($cred)
    {
        return [
            'id'                  => $cred->id,
            'name'                => $cred->name,
            'created_at'          => "<div dir='ltr' class='text-center'>"
                . verta($cred->created_at)->format('Y/m/d H:i')
                . "</div>",
        ];
    }
}
