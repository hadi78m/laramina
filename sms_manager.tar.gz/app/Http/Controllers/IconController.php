<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;

class IconController extends Controller
{
    /**
     * نمایش صفحه اصلی آیکون‌ها
     */
    public function index()
    {
        return view('manager.icons');
    }


    /**
     * استخراج آیکون‌ها از فایل CSS
     */
    public function extractIcons()
    {
        $cssPath = public_path('css/fontawesome/all.css');
        $icons = [];

        if (!file_exists($cssPath)) {
            return response()->json([
                'success' => false,
                'message' => 'فایل CSS یافت نشد',
                'icons' => $this->getSampleIcons(),
                'count' => count($this->getSampleIcons())
            ]);
        }

        try {
            $cssContent = file_get_contents($cssPath);

            if (!$cssContent) {
                throw new \Exception('فایل CSS خالی است');
            }

            // الگوهای مختلف برای استخراج
            $patterns = [
                // ساختار جدید با CSS Variables
                '/\.fa-([a-zA-Z0-9-]+)\s*\{\s*--fa:\s*["\']\\\\([a-fA-F0-9]+)["\']\s*\}/',

                // ساختار قدیمی
                '/\.fa-([a-zA-Z0-9-]+):before\s*\{\s*content:\s*["\']\\\\([a-fA-F0-9]+)["\']\s*\}/',

                '/\.fa-\w*[-]\w*/',

                '/\.fa-\w*/',

            ];

            $foundIcons = false;

            foreach ($patterns as $pattern) {
                if (preg_match_all($pattern, $cssContent, $matches, PREG_SET_ORDER)) {
                    $foundIcons = true;

                    foreach ($matches as $index => $match) {
                        $iconName = str_replace('.fa-', '', $match);

                        $icons[] = [
                            'id' => $index + 1,
                            'name' => $iconName[0],
                            'class' => ' fa fa-' . $iconName[0],
                        ];
                    }
                }
            }

            if (!$foundIcons || empty($icons)) {
                throw new \Exception('هیچ آیکونی در فایل CSS یافت نشد');
            }

            return response()->json([
                'success' => true,
                'count' => count($icons),
                'icons' => $icons
            ]);
        } catch (\Exception $e) {
            Log::error('خطا در استخراج آیکون‌ها: ' . $e->getMessage());

            return response()->json([
                'success' => false,
                'message' => $e->getMessage(),
                'icons' => $this->getSampleIcons(),
                'count' => count($this->getSampleIcons())
            ]);
        }
    }
    private function getSampleIcons()
    {
        return [
            [
                'id' => 1,
                'name' => 'home',
                'unicode' => 'f015',
                'class' => 'fas fa-home',
                'category' => 'خانه',
                'type' => 'solid',
                'popularity' => 5
            ],
            [
                'id' => 2,
                'name' => 'user',
                'unicode' => 'f007',
                'class' => 'fas fa-user',
                'category' => 'کاربر',
                'type' => 'solid',
                'popularity' => 5
            ],
            [
                'id' => 3,
                'name' => 'cog',
                'unicode' => 'f013',
                'class' => 'fas fa-cog',
                'category' => 'تنظیمات',
                'type' => 'solid',
                'popularity' => 5
            ],
            [
                'id' => 4,
                'name' => 'search',
                'unicode' => 'f002',
                'class' => 'fas fa-search',
                'category' => 'عمومی',
                'type' => 'solid',
                'popularity' => 5
            ],
            [
                'id' => 5,
                'name' => 'envelope',
                'unicode' => 'f0e0',
                'class' => 'fas fa-envelope',
                'category' => 'ارتباطات',
                'type' => 'solid',
                'popularity' => 5
            ],
            [
                'id' => 6,
                'name' => 'heart',
                'unicode' => 'f004',
                'class' => 'fas fa-heart',
                'category' => 'سلامت',
                'type' => 'solid',
                'popularity' => 5
            ],
            [
                'id' => 7,
                'name' => 'star',
                'unicode' => 'f005',
                'class' => 'fas fa-star',
                'category' => 'عمومی',
                'type' => 'solid',
                'popularity' => 5
            ],
            [
                'id' => 8,
                'name' => 'facebook',
                'unicode' => 'f09a',
                'class' => 'fab fa-facebook',
                'category' => 'شبکه‌های اجتماعی',
                'type' => 'brand',
                'popularity' => 4
            ],
            [
                'id' => 9,
                'name' => 'twitter',
                'unicode' => 'f099',
                'class' => 'fab fa-twitter',
                'category' => 'شبکه‌های اجتماعی',
                'type' => 'brand',
                'popularity' => 4
            ],
            [
                'id' => 10,
                'name' => 'instagram',
                'unicode' => 'f16d',
                'class' => 'fab fa-instagram',
                'category' => 'شبکه‌های اجتماعی',
                'type' => 'brand',
                'popularity' => 4
            ]
        ];
    }
}
