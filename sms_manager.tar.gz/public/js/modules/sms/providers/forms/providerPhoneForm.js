export const createPhone = {

    endpoint: 'sms.providers.numbers.store',

    fields: [
        {
            name: 'phone',
            label: 'شماره پرووایدر',
            type: 'text',
            required: true
        },

    ]
}
