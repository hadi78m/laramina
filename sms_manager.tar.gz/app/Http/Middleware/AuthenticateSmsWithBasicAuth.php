<?php

namespace App\Http\Middleware;

use App\Models\Sms\Credential;
use Closure;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Symfony\Component\HttpFoundation\Response;

class AuthenticateSmsWithBasicAuth
{
    /**
     * ⚠️ غیرفعال شده — از static_token استفاده کنید
     */
    public function handle(Request $request, Closure $next): Response
    {
        // غیرفعال شده — سیستم احراز هویت بر اساس username/password کار نمی‌کند
        // از Bearer Token (static_token) استفاده کنید
        return $next($request);

        /*
        // خواندن header Authorization
        $authorization = $request->header('Authorization');

        if (!$authorization || !str_starts_with($authorization, 'Basic ')) {
            return response()->json([
                'success' => false,
                'message' => 'هدر Authorization Basic الزامی است',
            ], 401);
        }

        // استخراج username و password از header
        $base64Credentials = substr($authorization, 6); // حذف "Basic "
        $decodedCredentials = base64_decode($base64Credentials);
        [$username, $password] = explode(':', $decodedCredentials, 2);

        // احراز هویت با استفاده از مدل Credential
        $credential = Credential::where('username', $username)
            ->where('is_active', true)
            ->first();

        if (!$credential || !Hash::check($password, $credential->password)) {
            return response()->json([
                'success' => false,
                'message' => 'نام کاربری یا رمز عبور نامعتبر است',
            ], 401);
        }

        // تنظیم کاربر در Auth برای guard 'sms'
        Auth::guard('sms')->setUser($credential);
        */
    }
}