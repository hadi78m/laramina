ساختار کلی معماری پروژه

پروژه از چند لایه اصلی تشکیل شده است:

    Layout (Blade)
    Bootstrap Loader
    Core Infrastructure
    Engines
    UI Renderers
    Services
    Modules

جریان کار از Blade → Bootstrap → Core → Module → Engines → UI است.
1. لایه Layout (Laravel Blade)

فایل اصلی:

                                                                    text
layouts/mclsApp.blade.php

وظیفه:

    ساختار HTML پایه
    فراهم کردن container اصلی صفحه
    قرار دادن modal
    قرار دادن CSRF
    لود اسکریپت‌های مشترک

عناصر مهم:

                                                                    text
meta csrf-token
#adminModal
.modal-body
@yield(content)
@yield(scripts)

این‌ها توسط JS استفاده می‌شوند:

    api-client.js → CSRF
    modal.js → adminModal
    صفحات → inject scripts

2. صفحه ماژول

مثال:

                                                                    text
providers-index.blade.php

وظیفه:

    لود bootstrap سیستم
    شروع Admin Platform

                                                                    text
<script src="/js/admin-platform/admin-platform.js"></script>

DOMContentLoaded
     ↓
AdminPlatform.boot()

3. Bootstrap Layer

فایل:

                                                                    text
admin-platform.js

این فایل entry point سیستم JS است.

خروجی:

                                                                    text
window.AdminPlatform

متدها:

                                                                    text
boot()
loadModule(name)

کارهایی که انجام می‌دهد:

    تشخیص نام ماژول از URL

                                                                    text
/sms/providers
        ↓
providers

    لود فایل‌های ماژول

                                                                    text
modules/{name}/
    name.table.js
    name.form.js
    name.actions.js
    name.module.js

    فعال کردن ماژول

                                                                    text
ModuleRegistry.activate(name)

4. Core Infrastructure

این بخش ستون فقرات سیستم است.
Module Registry

                                                                    text
module-registry.js

مسئول:

    ثبت ماژول‌ها
    فعال سازی ماژول‌ها

خروجی:

                                                                    text
window.ModuleRegistry

Event System

                                                                    text
event-bus.js

مسئول:

                                                                    text
publish / subscribe

برای ارتباط بین ماژول‌ها و engine ها.
State Management

                                                                    text
state-manager.js

نگهداری:

                                                                    text
currentModule
selectedRow
formState

5. Engines (Business Logic)

Engine ها منطق اصلی CRUD و فرم را اجرا می‌کنند.
CRUD Engine

                                                                    text
crud-engine.js

عملیات:

                                                                    text
create
update
delete
list
custom actions

از این‌ها استفاده می‌کند:

                                                                    text
ApiClient
Helpers
EventBus

Form Engine

                                                                    text
form-engine.js

مسئول:

    مدیریت فرم‌ها
    submit
    validation اولیه
    ارتباط با CRUD

Table Engine

                                                                    text
table-engine.js

قرار است:

                                                                    text
table config
filters
pagination
sorting

را مدیریت کند.

اما در نسخه فعلی تقریباً خالی است.
6. UI Renderers

این بخش فقط UI را render می‌کند.
Table Renderer

                                                                    text
table-renderer.js

وظیفه:

                                                                    text
render table
render columns
render actions

وابسته به:

                                                                    text
table config
module actions

Form Renderer

                                                                    text
form-renderer.js

وظیفه:

                                                                    text
render form fields
generate inputs

Modal

                                                                    text
modal.js

کار:

                                                                    text
Modal.open()
Modal.close()

از:

                                                                    text
#adminModal
.modal-body

در layout استفاده می‌کند.
Alert

                                                                    text
alert.js

نمایش پیام:

                                                                    text
success
error
warning

7. Services
API Client

                                                                    text
api-client.js

مسئول:

                                                                    text
HTTP requests
csrf
fetch

Helpers

                                                                    text
helpers.js

متد مهم:

                                                                    text
Helpers.interpolate(url, params)

مثال:

                                                                    text
/providers/{id}
      ↓
/providers/10

8. Modules

ماژول‌ها featureهای سیستم هستند.

مثال:

                                                                    text
modules/providers/

ساختار:

                                                                    text
providers.table.js
providers.form.js
providers.actions.js
providers.module.js

providers.table.js

تعریف:

                                                                    text
columns
table config

providers.form.js

تعریف:

                                                                    text
form fields
form layout

providers.actions.js

تعریف:

                                                                    text
create
edit
delete
custom actions

providers.module.js

ثبت ماژول در registry

مثلاً:

                                                                    text
ModuleRegistry.register('providers', config)

9. جریان کامل اجرای سیستم

Boot Flow:

                                                                    text
Laravel Blade
     ↓
mclsApp.blade.php
     ↓
providers-index.blade.php
     ↓
admin-platform.js
     ↓
AdminPlatform.boot()
     ↓
detectModuleFromRoute()
     ↓
loadModule("providers")
     ↓
load scripts
     ↓
ModuleRegistry.activate("providers")
     ↓
Engines + Renderers
     ↓
UI Render

ساختار پوشه‌ها (تقریبی)

                                                                    text
js/admin-platform/

core/
    module-registry.js
    event-bus.js
    state-manager.js
    platform.js

engines/
    crud-engine.js
    form-engine.js
    table-engine.js

ui/
    table-renderer.js
    form-renderer.js
    modal.js
    alert.js

services/
    api-client.js

utils/
    helpers.js

modules/
    providers/
        providers.module.js
        providers.actions.js
        providers.table.js
        providers.form.js

bootstrap/
    admin-platform.js

✅ وضعیت فعلی معماری

معماری طراحی شده ولی چند مشکل دارد:

    wiring ناقص بین core و engines
    ناسازگاری naming
    table-engine ناقص
    renderer ها برخی config ها را نادیده می‌گیرند
    وابستگی شدید به URL structure


### نسخه نهایی 

js/admin-platform
│
├─ core
│  ├─ admin-route.js
│  ├─ module-registry.js
│  ├─ module-loader.js
│  ├─ state-manager.js
│  ├─ platform.js
│  └─ event-bus.js
│
├─ engines
│  ├─ crud-engine.js
│  ├─ table-engine.js
│  └─ form-engine.js
│
├─ utils
│  └─ helpers.js
├─ services
│  └─ api-client.js
├─ ui
│  ├─ table-renderer.js
│  ├─ form-renderer.js
│  ├─ action-renderer.js
│  ├─ modal.js
│  └─ alert.js
│
├─ modules
│  └─ providers
│     ├─ providers.module.js
│     ├─ providers.actions.js
│     ├─ providers.table.js
│     └─ providers.form.js
│
└─ admin-platform.js

js/custom
└─ showalertProduction.js

app/Support
└─ AdminRouteExporter.php

views
├─ sms
│   └─ providers
│      └─ providers-index.blade.php
└─ layouts
    └─ mclsApp.blade.php