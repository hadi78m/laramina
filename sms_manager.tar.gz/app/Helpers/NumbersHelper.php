<?php

namespace App\Helpers;

class NumbersHelper
{
    /**
     * تبدیل اعداد فارسی و عربی به انگلیسی
     */
    public static function persianToEnglish($string)
    {
        $persianDigits = ['۰', '۱', '۲', '۳', '۴', '۵', '۶', '۷', '۸', '۹'];
        $arabicDigits = ['٠', '١', '٢', '٣', '٤', '٥', '٦', '٧', '٨', '٩'];
        $englishDigits = ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9'];

        $string = str_replace($persianDigits, $englishDigits, $string);
        $string = str_replace($arabicDigits, $englishDigits, $string);

        return $string;
    }

    /**
     * بررسی آیا رشته شامل عدد فارسی/عربی است
     */
    public static function containsPersianNumbers($string)
    {
        return preg_match('/[۰-۹٠-٩]/u', $string);
    }



    public static function persianToEnglishNumbers($string)
    {
        $translation = [
            '۰' => '0',
            '۱' => '1',
            '۲' => '2',
            '۳' => '3',
            '۴' => '4',
            '۵' => '5',
            '۶' => '6',
            '۷' => '7',
            '۸' => '8',
            '۹' => '9',
            '٠' => '0',
            '١' => '1',
            '٢' => '2',
            '٣' => '3',
            '٤' => '4',
            '٥' => '5',
            '٦' => '6',
            '٧' => '7',
            '٨' => '8',
            '٩' => '9',
        ];

        return strtr($string, $translation);
    }


    public static function normalizeMobile($number)
    {
        return preg_replace('/^(\+98|98|\+980|0098|980|0)/', '', $number);
    }
}
