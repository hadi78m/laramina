@extends('errors::minimal')

@section('title', __('خطای 401 - دسترسی غیرمجاز'))
@section('code', '401')

@section('message')
<style>
    .lock-bounce {
        animation: lockBounce 2s infinite;
    }

    @keyframes lockBounce {
        0%, 20%, 50%, 80%, 100% {transform: translateY(0);}
        40% {transform: translateY(-10px);}
        60% {transform: translateY(-5px);}
    }
    .glow {
        animation: glow 2s ease-in-out infinite alternate;
    }
    @keyframes glow {
        from { box-shadow: 0 0 5px rgba(220, 38, 38, 0.5); }
        to { box-shadow: 0 0 15px rgba(220, 38, 38, 0.8); }
    }
</style>
<div class="max-w-lg w-full bg-white rounded-xl shadow-2xl overflow-hidden">
    <div class="bg-gradient-to-r from-red-500 to-rose-600 p-6 text-center">
        <div class="lock-bounce inline-block">
            <svg xmlns="http://www.w3.org/2000/svg" class="h-20 w-20 mx-auto text-white" fill="none" viewBox="0 0 24 24"
                stroke="currentColor">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                    d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z" />
            </svg>
        </div>
        <h1 class="text-3xl font-bold text-white mt-4">401 - دسترسی غیرمجاز</h1>
    </div>

    <div class="p-8 text-center">
        <p class="text-gray-700 mb-6">برای دسترسی به این صفحه نیاز به احراز هویت دارید.</p>

        <div class="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded mb-6 glow">
            <div class="flex items-center justify-center space-x-2">
                <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
                    <path fill-rule="evenodd"
                        d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7-4a1 1 0 11-2 0 1 1 0 012 0zM9 9a1 1 0 000 2v3a1 1 0 001 1h1a1 1 0 100-2h-1V9z"
                        clip-rule="evenodd" />
                </svg>
                <span>لطفاً وارد حساب کاربری خود شوید</span>
            </div>
        </div>

        <div class="space-y-3">
            <a href="/login?redirect={{ urlencode(request()->fullUrl()) }}"
                class="block bg-red-600 hover:bg-red-700 text-white font-bold py-3 px-4 rounded-lg transition duration-200">
                ورود به حساب کاربری
            </a>
           
            {{-- <a href="/password/reset"
                class="block text-gray-600 hover:text-gray-800 font-medium py-2 px-4 rounded-lg transition duration-200">
                بازیابی رمز عبور
            </a> --}}
        </div>

        <div class="mt-6 pt-4 border-t border-gray-100">
            <p class="text-sm text-gray-600">در صورتی که قبلاً وارد شده‌اید:</p>
            <ul class="text-sm text-gray-600 text-right space-y-1 list-disc pr-4 mt-2">
                <li>ممکن است نشست شما منقضی شده باشد</li>
                <li>احراز هویت دو مرحله‌ای انجام نشده باشد</li>
                <li>دسترسی لازم را نداشته باشید</li>
            </ul>
        </div>
    </div>
</div>
@endsection
