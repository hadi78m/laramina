<?php

use Illuminate\Foundation\Inspiring;
use Illuminate\Support\Facades\Artisan;
use Illuminate\Support\Facades\Schedule;

Artisan::command('inspire', function () {
    $this->comment(Inspiring::quote());
})->purpose('Display an inspiring quote');

// 🚀 دستور مورد نیاز برای فعال سازی Worker
Schedule::command('queue:work --stop-when-empty')
    ->everyMinute() // یا هر بازه زمانی دیگری که نیاز دارید
    ->withoutOverlapping() // جلوگیری از اجرای موازی
    ->onOneServer();