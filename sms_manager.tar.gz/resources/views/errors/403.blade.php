@extends('errors::minimal')
@php
    $message = $exception->getMessage();
    if (strpos($exception->getMessage(), 'logged')) {
        $message = 'کاربر وارد نشده یا مدت زمان مجازش به اتمام رسیده';
    }
    if (strpos($exception->getMessage(), 'permissions')) {
        $message = 'دسترسی به این منبع برای حساب کاربری شما محدود شده است.';
    }
    if (strpos($exception->getMessage(), 'roles')) {
        $message = 'دسترسی به این منبع برای حساب کاربری شما محدود شده است.';
    }
    if (strpos($exception->getMessage(), 'signature')) {
        $message = 'شما مجوز دسترسی مستقیم ندارید';
    }
@endphp
@section('title', __('خطای دسترسی 403'))
@section('code', '403 -')
@section('message')
    <div class="max-w-lg w-full bg-white rounded-xl shadow-2xl overflow-hidden">
        <div class="bg-gradient-to-r from-red-500 to-pink-600 p-6 text-center">
            <svg xmlns="http://www.w3.org/2000/svg" class="h-20 w-20 mx-auto text-white" fill="none" viewBox="0 0 24 24"
                stroke="currentColor">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                    d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" />
            </svg>
            <h1 class="text-3xl font-bold text-white mt-4">
                @yield('code') دسترسی ممنوع
            </h1>
        </div>
        <div class="p-8 text-center">
            <p class="text-gray-700 mb-6">
                متأسفیم! شما مجوز دسترسی به این صفحه را ندارید.
            </p>

            <div class="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded mb-6">
                <p>
                    @isset($message)
                        {{ $message }}
                    @else
                        خطای دسترسی
                    @endisset
                </p>
            </div>

            <div class="flex flex-col space-y-3">
                <a href="/"
                    class="bg-blue-600 hover:bg-blue-700 text-white font-medium py-2 px-4 rounded-lg transition duration-200">
                    بازگشت به صفحه اصلی
                </a>
                <a href="{{ route('logout') }}"
                    class="text-blue-600 hover:text-blue-800 font-medium py-2 px-4 rounded-lg transition duration-200">
                    ورود با حساب دیگر
                </a>
                <a href="{{ url()->previous() }}"
                    class="text-indigo-600 hover:text-indigo-800 font-medium py-2 px-4 rounded-lg transition duration-200">
                    بازگشت به صفحه قبل
                </a>
                <a {{-- href="/contact" --}}
                    class="text-gray-600 hover:text-gray-800 font-medium py-2 px-4 rounded-lg transition duration-200">
                    تماس با پشتیبانی
                </a>
            </div>
        </div>
    </div>
@endsection
