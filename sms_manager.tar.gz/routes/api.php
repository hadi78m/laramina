<?php


use App\Http\Controllers\Sms\SmsApiController;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;


Route::prefix('v1/sms')->group(function () {

    // دریافت توکن — غیرفعال شده (از static_token استفاده کنید)
    // Route::post('/token', [SmsApiController::class, 'getApiToken']);

    // همه درخواست‌های ارسال — فقط با Bearer Token
    Route::middleware(['auth:sanctum', 'restrict.token.ip'])->group(function () {
        Route::post('/send', [SmsApiController::class, 'send']);
        Route::post('/sendOtp', [SmsApiController::class, 'sendOtp']);
    });
    // بازگشت آی پی کاربر
    Route::get('/GetIp', function (Request $request) {
        $ip = $request->header('X-Forwarded-For') ?? $request->ip();
        return response()->json(['ip' => $ip]);
    })->name('GetIp');
});
