const publicLang   = AdminLang.getNamespace('common');
const moduleFields = AdminLang.getNamespace('modules.roles.fields');
const moduleActions = AdminLang.getNamespace('modules.roles.actions');

export const createForm = {

    endpoint: 'manage.roles.store',
    updateEndpoint: 'manage.roles.update',
    deleteEndpoint: 'manage.roles.destroy',

    title: moduleActions.create || publicLang.create,

    fields: [
        {
            name: 'name',
            label: publicLang.name,
            type: 'text'
        },
    ],

    buttons: {
        submit: publicLang.save,
        cancel: publicLang.cancel,
    }
};