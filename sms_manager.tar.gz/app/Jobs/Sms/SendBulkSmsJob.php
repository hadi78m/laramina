<?php

namespace App\Jobs\Sms;

use App\Models\Sms\Provider;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Queue\SerializesModels;
use App\Models\Sms\Message;
use App\Services\Sms\SmsSenderService;

class SendBulkSmsJob implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    protected $messageIds; // آرایه IDهای پیام‌ها (به جای داده خام)

    public function __construct(array $messageIds)
    {
        $this->messageIds = $messageIds;
    }

    public function handle(SmsSenderService $smsSender)
    {
        // تفکیک پیام‌ها بر اساس نوع با chunking
        $newsMessageIds = [];
        $otherMessageIds = [];

        Message::whereIn('id', $this->messageIds)
            ->select('id', 'type')
            ->chunk(100, function ($messages) use (&$newsMessageIds, &$otherMessageIds) {
                foreach ($messages as $message) {
                    if ($message->type === 'news') {
                        $newsMessageIds[] = $message->id;
                    } else {
                        $otherMessageIds[] = $message->id;
                    }
                }
            });

        // ارسال فوری پیام‌های غیرخبری
        if (!empty($otherMessageIds)) {
            $defaultProvider = Provider::where('is_active', true)->where('is_default', true)->firstOrFail();
            $smsSender->setProvider($defaultProvider);

            Message::whereIn('id', $otherMessageIds)->chunk(50, function ($messages) use ($smsSender) {
                foreach ($messages as $message) {
                    $smsSender->send($message);
                    $message->update(['status' => 'sent']);
                }
            });
        }

        // زمان‌بندی پیام‌های خبری با تأخیر
        if (!empty($newsMessageIds)) {
            $delayInSeconds = rand(86400, 172800);
            foreach ($newsMessageIds as $messageId) {
                SendSingleSmsJob::dispatch($messageId)->onQueue('sms-news')->delay(now()->addSeconds($delayInSeconds));
            }
        }
    }
}
